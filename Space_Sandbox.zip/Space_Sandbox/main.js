/* ==========================================================================
   Space Sandbox — ОСНОВНОЙ ФАЙЛ
   Здесь: сцена и камера, фон-космос, сетка, физика (N тел), частицы, столкновения,
   осколки, гравитационная линза, общие слои планет (атмосфера, лава, снег, океан,
   растительность, облака, кольца), экология, интерфейс, ввод, игровой цикл.

   Всё, что относится к КОНКРЕТНОМУ объекту, лежит отдельно:
     objects/planets/      — каменная планета, Супер-Земля, газовый гигант
     objects/stars/        — звезда (Солнце), красный карлик
     objects/black_holes/  — чёрная дыра
     objects/my_planets/   — твои сохранённые тела
     planet_maps/          — карты поверхностей (+ свои карты и редактор)

   Порядок загрузки (см. index.html): three.js → main.js → planet_maps → objects → startGame().
   Файлы — обычные скрипты с общей глобальной областью, поэтому игра открывается
   двойным кликом по index.html, без сервера.
   ========================================================================== */

var el=document.getElementById('c');
var renderer=new THREE.WebGLRenderer({canvas:el,antialias:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
var scene=new THREE.Scene();
var camera=new THREE.PerspectiveCamera(50,1,0.005,12000);
var SUN_R=6;/* радиус Солнца в единицах сцены: от него считаются размеры всех тел */
/* реестры, которые заполняют файлы из objects/ */
var ICON={},KR={},GEO={},MAT={};
var MY_PLANETS=[];/* сюда добавляют себя файлы из objects/my_planets/ */
/* ---- Фон: настоящий космос вокруг сцены (skybox), а не картинка на камере ---- */
var sky;
(function(){
  var W=2048,H=1024,c=document.createElement('canvas');c.width=W;c.height=H;var g=c.getContext('2d');
  g.fillStyle='#03040a';g.fillRect(0,0,W,H);
  var s=7;function rnd(){s=(s*16807)%2147483647;return s/2147483647;}
  function hs(x,y,z){var h=Math.sin(x*127.1+y*311.7+z*74.7)*43758.5453;return h-Math.floor(h);}
  function vn(x,y,z){var xi=Math.floor(x),yi=Math.floor(y),zi=Math.floor(z),fx=x-xi,fy=y-yi,fz=z-zi;fx=fx*fx*(3-2*fx);fy=fy*fy*(3-2*fy);fz=fz*fz*(3-2*fz);
    function L(a,b,t){return a+(b-a)*t;}
    return L(L(L(hs(xi,yi,zi),hs(xi+1,yi,zi),fx),L(hs(xi,yi+1,zi),hs(xi+1,yi+1,zi),fx),fy),L(L(hs(xi,yi,zi+1),hs(xi+1,yi,zi+1),fx),L(hs(xi,yi+1,zi+1),hs(xi+1,yi+1,zi+1),fx),fy),fz);}
  function fbm(x,y,z){var v=0,a=.5;for(var i=0;i<5;i++){v+=a*vn(x,y,z);x=x*2.03+1.7;y=y*2.03+9.2;z=z*2.03+3.1;a*=.5;}return v;}
  var ax=.35,ay=.8,az=.5,al=Math.sqrt(ax*ax+ay*ay+az*az);ax/=al;ay/=al;az/=al;
  function band(dx,dy,dz){var q=(dx*ax+dy*ay+dz*az)/.28;return Math.exp(-q*q);}
  var NW=512,NH=256,nc=document.createElement('canvas');nc.width=NW;nc.height=NH;var ng=nc.getContext('2d'),im=ng.createImageData(NW,NH),d=im.data,x,y;
  for(y=0;y<NH;y++)for(x=0;x<NW;x++){
    var lon=(x+.5)/NW*6.28319,lat=(.5-(y+.5)/NH)*3.14159,dx=Math.cos(lat)*Math.cos(lon),dy=Math.sin(lat),dz=Math.cos(lat)*Math.sin(lon),
      b=band(dx,dy,dz),f=fbm(dx*2.2+3,dy*2.2,dz*2.2),f2=fbm(dx*5+9,dy*5+4,dz*5+1),
      neb=Math.max(0,f-.4)*2.4*(.3+1.15*b),dust=Math.min(.85,Math.max(0,fbm(dx*4+20,dy*4,dz*4)-.48)*3.2*b),
      bg=b*.2*(.6+.8*f2),o=(y*NW+x)*4;
    var r=neb*(60+120*f2)+bg*125+3,gg=neb*(36+55*(1-f2)*f)+bg*105+4,bb=neb*(115+85*(1-f2))+bg*100+9,k=1-dust;
    d[o]=Math.min(255,r*k);d[o+1]=Math.min(255,gg*k);d[o+2]=Math.min(255,bb*k);d[o+3]=255;}
  ng.putImageData(im,0,0);g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(nc,0,0,W,H);
  var cols=[[170,200,255],[210,225,255],[255,248,235],[255,225,170],[255,190,140]],n=0;
  while(n<6500){
    var lo=rnd()*6.28319,la=Math.asin(2*rnd()-1),bd=band(Math.cos(la)*Math.cos(lo),Math.sin(la),Math.cos(la)*Math.sin(lo));
    if(rnd()>.3+.7*bd)continue;n++;
    var sx=lo/6.28319*W,sy=(.5-la/3.14159)*H,mag=Math.pow(rnd(),6),rad=.45+mag*1.7,st=Math.min(6,1/Math.max(.15,Math.cos(la))),k2=cols[(rnd()*cols.length)|0],a=.3+.7*Math.min(1,mag*1.5+.15);
    g.save();g.translate(sx,sy);g.scale(st,1);
    if(mag>.35){var hr=rad*4,gr=g.createRadialGradient(0,0,0,0,0,hr);gr.addColorStop(0,'rgba('+k2[0]+','+k2[1]+','+k2[2]+','+(.35*a)+')');gr.addColorStop(1,'rgba('+k2[0]+','+k2[1]+','+k2[2]+',0)');g.fillStyle=gr;g.beginPath();g.arc(0,0,hr,0,6.283);g.fill();}
    g.fillStyle='rgba('+k2[0]+','+k2[1]+','+k2[2]+','+a+')';g.beginPath();g.arc(0,0,rad,0,6.283);g.fill();g.restore();}
  var tex=new THREE.CanvasTexture(c);tex.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());
  sky=new THREE.Mesh(new THREE.SphereGeometry(5000,48,32),new THREE.MeshBasicMaterial({map:tex,side:THREE.BackSide,depthWrite:false,depthTest:false,fog:false}));
  sky.renderOrder=-1000;sky.frustumCulled=false;scene.add(sky);
})();

/* ---- Бесконечная сетка: считается в шейдере, следует за камерой, масштаб подстраивается под зум ---- */
var gridMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,extensions:{derivatives:true},
  uniforms:{uC:{value:new THREE.Vector2()},uK:{value:1},uF:{value:0},uR:{value:500}},
  vertexShader:'varying vec3 vW;void main(){vec4 w=modelMatrix*vec4(position,1.);vW=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}',
  fragmentShader:
    'precision highp float;varying vec3 vW;uniform vec2 uC;uniform float uK,uF,uR;\n'+
    'float gl(vec2 c){vec2 d=fwidth(c);vec2 g=abs(fract(c-.5)-.5)/max(d,vec2(1e-4));float l=1.-min(min(g.x,g.y),1.);return l*(1.-smoothstep(.3,.7,max(d.x,d.y)));}\n'+
    'void main(){vec2 p=vW.xz;float l0=gl(p/(6.*uK)),l1=gl(p/(60.*uK)),l2=gl(p/(600.*uK));\n'+
    ' float a=l0*.45*(1.-uF)+l1*mix(.6,.45,uF)+l2*.6*uF;\n'+
    ' float mj=clamp(l1*(1.-uF)+l2*uF,0.,1.);\n'+
    ' float fade=1.-smoothstep(uR*.2,uR,length(p-uC));\n'+
    ' gl_FragColor=vec4(mix(vec3(.82,.62,.62),vec3(1.,.82,.75),mj),clamp(a,0.,1.)*fade);}'});
var grid=new THREE.Mesh(new THREE.PlaneGeometry(1,1),gridMat);grid.rotation.x=-Math.PI/2;grid.frustumCulled=false;scene.add(grid);
function updGrid(){var L=Math.log(dist/62)/Math.LN10,fl=Math.floor(L),R=dist*8+60,u=gridMat.uniforms;
  u.uK.value=Math.pow(10,fl);u.uF.value=L-fl;u.uR.value=R;u.uC.value.set(cx,cz);
  grid.position.set(cx,0,cz);grid.scale.set(R*2.2,R*2.2,1);}
var glowTex=(function(){var c=document.createElement('canvas');c.width=c.height=128;var g=c.getContext('2d');
  var gr=g.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,'rgba(255,235,60,1)');gr.addColorStop(.45,'rgba(255,215,40,.8)');
  gr.addColorStop(.7,'rgba(255,190,30,.25)');gr.addColorStop(1,'rgba(255,170,20,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);
  return new THREE.CanvasTexture(c);})();
function makeGlow(){var glow=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,opacity:.4}));
glow.scale.set(SUN_R*2.4,SUN_R*2.4,1);scene.add(glow);return glow;}
var LPOOL=[];(function(){for(var i=0;i<4;i++){var l=new THREE.PointLight(0xfff0c8,0,0,0);l._pool=true;l._used=false;scene.add(l);LPOOL.push(l);}})();
function makeLight(){for(var i=0;i<LPOOL.length;i++)if(!LPOOL[i]._used){var l=LPOOL[i];l._used=true;l.intensity=1.9;return l;}var x=new THREE.PointLight(0xfff0c8,1.9,0,0);scene.add(x);return x;}
function freeLight(l){if(l._pool){l.intensity=0;l._used=false;}else scene.remove(l);}
scene.add(new THREE.AmbientLight(0x2c2626));
/* ---- Редкие частицы ---- */
var parts=[];for(var pi=0;pi<20;pi++){
  var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,opacity:0}));
  sp.visible=false;scene.add(sp);parts.push({s:sp,life:0,max:1,v:new THREE.Vector3(),sz:1});}
var nextP=1;
function spawnP(){var st=bodies.filter(function(b){return b.star&&!b.bh;});if(!st.length)return;var sb=st[(Math.random()*st.length)|0];for(var i=0;i<parts.length;i++){var p=parts[i];if(p.life>0)continue;
  var u=new THREE.Vector3(Math.random()-.5,Math.random()-.5,Math.random()-.5).normalize();
  p.s.position.copy(u).multiplyScalar(sb.r*1.02).add(sb.mesh.position);p.v.copy(u).multiplyScalar(1.2+Math.random()*1.8);
  p.max=p.life=2.5+Math.random()*1.5;p.sz=(0.9+Math.random()*1.1)*sb.r/SUN_R;p.s.visible=true;return;}}
/* ---- Контейнеры карт и общие функции карт ---- */
var SM={},HIGHS={},RLOW={};
/* сдвиг шума маски суши для каждой из 7 карт каменной планеты: океаны и континенты у каждой карты свои */
var RLAND=[[0,0,0],[13.7,4.3,9.1],[27.1,18.6,3.4],[5.2,31.7,22.9],[41.3,9.8,16.5],[19.4,26.2,37.8],[33.9,45.1,11.7]];
function setLandSeed(b){if(!b.waterMat)return;var id=b.mapId|0,v=RLAND[id]||RLAND[0],P=RMAP[id],cu=P&&P.custom,wu=b.waterMat.uniforms,vu=b.vegMat.uniforms;wu.uSd.value.set(v[0],v[1],v[2]);vu.uSd.value.set(v[0],v[1],v[2]);
  wu.uUL.value=vu.uUL.value=cu?1:0;if(cu){var tx=maskTex(cu);wu.uLM.value=tx;vu.uLM.value=tx;}}
/* освобождаем карты, которыми никто не пользуется */
function releaseMaps(){var id,su={},ru={},i,b,r,t;
  for(i=0;i<bodies.length;i++){b=bodies[i];if(b.star||b.kind==='gas')continue;if(b.kind==='super')su[b.mapId|0]=1;else ru[b.mapId|0]=1;}
  for(id in SM){if(!su[id]){r=SM[id];r.dead=true;[r.map,r.spec,r.bump].forEach(function(t){if(t&&t.dispose)t.dispose();});delete SM[id];}}
  for(id in HIGHS){if(!ru[id]){t=HIGHS[id];if(t.map)t.map.dispose();if(t.normalMap)t.normalMap.dispose();t.dispose();delete HIGHS[id];}}}
var atmoMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{uA:{value:1},uC:{value:new THREE.Vector3(.25,.6,1.)}},
  vertexShader:'varying vec3 vN;varying vec3 vV;void main(){vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.);vV=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}',
  fragmentShader:'varying vec3 vN;varying vec3 vV;uniform float uA;uniform vec3 uC;void main(){float f=1.-max(dot(normalize(vN),normalize(vV)),0.);f=pow(f,2.2);gl_FragColor=vec4(uC*f*1.15*uA,1.);}'});
/* ---- Зоны вокруг звезды: 4 — выжженная, 3 — жара, 2 — обитаемая, 1 — холод ---- */
var zoneGeo=new THREE.PlaneGeometry(1,1);
var zoneMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,extensions:{derivatives:true},
  uniforms:{uT:{value:0}},
  vertexShader:'varying vec2 vP;void main(){vP=position.xy;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:
    'precision highp float;varying vec2 vP;uniform float uT;\n'+
    'float edge(float d,float b){float w=max(fwidth(d)*1.2,.05);return 1.-smoothstep(0.,w,abs(d-b));}\n'+
    'void main(){float d=length(vP)*673.2,w=4.8;\n'+
    ' float s1=smoothstep(78.-w,78.+w,d),s2=smoothstep(120.-w,120.+w,d),s3=smoothstep(186.-w,186.+w,d);\n'+
    ' float z4=1.-s1,z3=s1*(1.-s2),z2=s2*(1.-s3),z1=s3*(1.-smoothstep(210.,330.,d));\n'+
    ' float heat=1.-smoothstep(6.,78.,d);float wave=.5+.5*sin(d*.27-uT*4.);\n'+
    ' vec3 c4=mix(vec3(1.,.08,.02),vec3(1.,.8,.4),heat*heat);\n'+
    ' vec3 col=z1*vec3(.25,.55,1.)*.3+z2*vec3(.3,1.,.45)*.28+z3*vec3(1.,.6,.12)*.32+z4*c4*(.38+.3*heat+.14*wave);\n'+
    ' float l=(edge(d,78.)+edge(d,120.)+edge(d,186.))*step(d,300.);\n'+
    ' col+=vec3(.9,.95,1.)*l*.4;gl_FragColor=vec4(col,1.);}'});
/* ---- Лава: покрытие планеты в выжженной зоне (30 с на 1×) ---- */
var LAVA_VS='varying vec3 vP;varying vec3 vNw;varying vec3 vN;varying vec3 vV;\n'+
  'void main(){vP=normalize(position);vNw=normalize(mat3(modelMatrix)*normal);vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.);vV=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}';
var LAVA_FS='precision highp float;varying vec3 vP;varying vec3 vNw;varying vec3 vN;varying vec3 vV;uniform float uP,uT;uniform vec3 uL;\n'+
  'float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\n'+
  'float noise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);\n'+
  ' return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),\n'+
  '            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}\n'+
  'float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}\n'+
  'void main(){float t=uT*.03;vec3 p=vP*2.2;\n'+
  ' vec3 w=vec3(fbm(p+3.1),fbm(p+7.7),fbm(p+1.3));\n'+
  ' float n=clamp((fbm(p+1.2*w)-.2)/.6,0.,1.);\n'+
  ' float d=uP*1.08-n;if(d<=0.)discard;\n'+
  ' float a=smoothstep(0.,.04,d);\n'+
  ' float fl=fbm(vP*5.5+vec3(t,-t*.7,t*.5)+2.*w);float fl2=fbm(vP*11.+vec3(-t*1.5,t,3.));\n'+
  ' float nf=fbm(vP*4.2+vec3(7.,2.,5.)+w);float th=.56+uP*.05;\n'+
  ' float floe=smoothstep(th,th+.07,nf);float fe=smoothstep(th-.07,th,nf)*(1.-smoothstep(th,th+.05,nf));\n'+
  ' float dif=clamp(dot(normalize(vNw),normalize(uL)),0.,1.)*.9+.12;\n'+
  ' vec3 crust=vec3(.1,.05,.035)*(.6+.8*fl2)*dif;\n'+
  ' vec3 lv=mix(vec3(.45,.03,0.),vec3(.95,.2,0.),smoothstep(.02,.2,d));\n'+
  ' lv=mix(lv,vec3(1.,.55,.05),smoothstep(.12,.45,d)*(.35+.9*fl));\n'+
  ' lv=mix(lv,vec3(1.,.9,.45),smoothstep(.5,.95,d)*smoothstep(.45,.7,fl));\n'+
  ' lv*=.8+.5*fl2;\n'+
  ' float cool=1.-smoothstep(0.,.11,d);\n'+
  ' vec3 col=mix(lv,crust,cool*.9);col=mix(col,crust,floe*.9);col+=vec3(1.,.4,.05)*fe*.9;\n'+
  ' col+=vec3(1.,.3,0.)*pow(1.-max(dot(normalize(vN),normalize(vV)),0.),3.)*.35*uP;\n'+
  ' gl_FragColor=vec4(col,a);}';
function makeLavaMat(){return new THREE.ShaderMaterial({transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-4,
  uniforms:{uP:{value:0},uT:{value:0},uL:{value:new THREE.Vector3(1,0,0)}},vertexShader:LAVA_VS,fragmentShader:LAVA_FS});}
/* ---- Снежная корка: зона холода и за пределами зон, только для планет с атмосферой ---- */
var SNOW_FS='precision highp float;varying vec3 vP;varying vec3 vNw;varying vec3 vN;varying vec3 vV;uniform float uP,uK;uniform vec3 uL;\n'+
  'float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\n'+
  'float noise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);\n'+
  ' return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),\n'+
  '            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}\n'+
  'float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}\n'+
  'void main(){vec3 p=vP*2.2;vec3 w=vec3(fbm(p+3.1),fbm(p+7.7),fbm(p+1.3));\n'+
  ' float n=clamp((fbm(p+1.2*w)-.2)/.6,0.,1.);float lat=1.-abs(vP.y);\n'+
  ' float d=uP*1.12-(lat*.55+n*.45);if(d<=0.)discard;\n'+
  ' float a=smoothstep(0.,.07,d)*.92;\n'+
  ' float fl=fbm(vP*7.+w);float nf=fbm(vP*3.6+vec3(4.,9.,2.)+w);float ice=smoothstep(.5,.68,nf);\n'+
  ' float cr=1.-smoothstep(0.,.05,abs(fbm(vP*8.+3.*w)-.5));\n'+
  ' vec3 snow=mix(vec3(.97,.99,1.),vec3(.78,.88,.98),fl*.7);vec3 glac=mix(vec3(.66,.83,.97),vec3(.5,.7,.9),fl);\n'+
  ' vec3 col=mix(snow,glac,ice*.8);col=mix(col,vec3(.42,.62,.85),cr*ice*.7);\n'+
  ' col=mix(vec3(.75,.88,1.),col,smoothstep(0.,.14,d));\n'+
  ' float dif=.14+.88*uK*clamp(dot(normalize(vNw),normalize(uL)),0.,1.);col*=dif;\n'+
  ' col+=vec3(.35,.55,.95)*pow(1.-max(dot(normalize(vN),normalize(vV)),0.),3.)*.3*uP*(.3+dif);\n'+
  ' gl_FragColor=vec4(col,a);}';
function makeSnowMat(){return new THREE.ShaderMaterial({transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-2,
  uniforms:{uP:{value:0},uK:{value:1},uL:{value:new THREE.Vector3(1,0,0)}},vertexShader:LAVA_VS,fragmentShader:SNOW_FS});}
function snowUpd(b,dt){if(!b.snowMesh)return;var cold=true,near=null,nd=1e9,j,s,d;
  for(j=0;j<bodies.length;j++){s=bodies[j];if(!s.star||s.bh)continue;d=Math.hypot(b.x-s.x,b.y-s.y,b.z-s.z);if(d<nd){nd=d;near=s;}if(!s.gm&&d/s.zs<=186)cold=false;}
  for(j=0;j<EM.length;j++)if(Math.hypot(b.x-EM[j].x,b.y-EM[j].y,b.z-EM[j].z)/EM[j].zs<=186)cold=false;
  if(cold&&b.atmOn&&b.lava<.02)b.snow=Math.min(1,b.snow+dt/30);else if(b.snow>0)b.snow=Math.max(0,b.snow-dt/30);
  if(b.lava>0)b.snow=Math.min(b.snow,1-b.lava);
  if(b.snow>.002){b.snowMesh.visible=true;var u=b.snowMat.uniforms;u.uP.value=b.snow;u.uK.value=near?1:0;if(near&&nd>1e-6)u.uL.value.set(near.x-b.x,near.y-b.y,near.z-b.z).normalize();}else b.snowMesh.visible=false;}
/* ---- Океан на каменной планете (процедурный) ---- */
var DUMMY_LM=new THREE.DataTexture(new Uint8Array([0,0,0,255]),1,1,THREE.RGBAFormat);DUMMY_LM.needsUpdate=true;
var WATER_FS='precision highp float;varying vec3 vP;varying vec3 vNw;varying vec3 vN;varying vec3 vV;uniform float uOc,uK;uniform vec3 uL,uCol,uSd;uniform sampler2D uLM;uniform float uUL;\n'+
  'float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\n'+
  'float noise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);\n'+
  ' return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),\n'+
  '            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}\n'+
  'float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}\n'+
  'void main(){float a,dp;\n'+
  ' if(uUL>.5){vec4 lm=texture2D(uLM,vec2(fract(atan(vP.z,-vP.x)/6.2831853),.5+asin(clamp(vP.y,-1.,1.))/3.1415927));float ws=1.-smoothstep(.09,.14,lm.r);float x=uOc-(1.-lm.g)*.92;a=ws*smoothstep(0.,.05,x)*step(.001,uOc);if(a<.01)discard;dp=lm.g;}\n'+
  ' else{vec3 p=vP*2.4+uSd;vec3 w=vec3(fbm(p+3.1),fbm(p+7.7),fbm(p+1.3));float n=fbm(p*1.1+1.4*w);\n'+
  '  float thr=mix(.2,.51,uOc);if(n>=thr)discard;a=1.-smoothstep(thr-.025,thr,n);dp=clamp((thr-n)/.3,0.,1.);}\n'+
  ' vec3 col=mix(uCol*1.5+vec3(.06,.12,.1),uCol*.5,dp);\n'+
  ' float dif=.14+.88*uK*clamp(dot(normalize(vNw),normalize(uL)),0.,1.);col*=dif;\n'+
  ' col+=uCol*pow(1.-max(dot(normalize(vN),normalize(vV)),0.),3.)*.35*uK;\n'+
  ' gl_FragColor=vec4(col,a);}';
function makeWaterMat(){return new THREE.ShaderMaterial({transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1,
  uniforms:{uOc:{value:0},uK:{value:1},uL:{value:new THREE.Vector3(1,0,0)},uCol:{value:new THREE.Vector3(.1,.35,.7)},uSd:{value:new THREE.Vector3(0,0,0)},uLM:{value:DUMMY_LM},uUL:{value:0}},vertexShader:LAVA_VS,fragmentShader:WATER_FS});}
/* ---- Растительность на каменных планетах: зелень там, где умеренно; песок там, где жарко ---- */
var VEG_FS='precision highp float;varying vec3 vP;varying vec3 vNw;varying vec3 vN;varying vec3 vV;uniform float uV,uB,uOc,uTe,uEq,uK;uniform vec3 uL,uSd;uniform sampler2D uLM;uniform float uUL;\n'+
  'float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\n'+
  'float noise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);\n'+
  ' return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),\n'+
  '            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}\n'+
  'float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}\n'+
  'void main(){vec3 p=vP*2.4+uSd;vec3 w=vec3(fbm(p+3.1),fbm(p+7.7),fbm(p+1.3));float n=fbm(p*1.1+1.4*w);\n'+
  ' float land;\n'+
  ' if(uUL>.5){vec4 lm=texture2D(uLM,vec2(fract(atan(vP.z,-vP.x)/6.2831853),.5+asin(clamp(vP.y,-1.,1.))/3.1415927));float ws=1.-smoothstep(.09,.14,lm.r);float x=uOc-(1.-lm.g)*.92;float wet=ws*smoothstep(0.,.05,x)*step(.001,uOc);land=(1.-wet)*(1.-.85*smoothstep(.55,.85,lm.r));}\n'+
  ' else{float thr=mix(.2,.51,uOc);land=smoothstep(thr,thr+.03,n);}\n'+
  ' if(land<=.01)discard;\n'+
  ' float cl=sqrt(max(0.,1.-vP.y*vP.y));float tl=uTe+uEq*(2.*cl*cl-1.);\n'+
  ' float vg=smoothstep(245.,268.,tl)*(1.-smoothstep(330.,370.,tl));float hot=smoothstep(325.,365.,tl);\n'+
  ' float nv=fbm(vP*5.5+w*1.5+vec3(3.,1.,7.));float nv2=fbm(vP*9.+vec3(5.,2.,8.));\n'+
  ' float gg=smoothstep(0.,.14,uV*vg*1.3-(1.-nv)*1.1);\n'+
  ' float ss=smoothstep(0.,.14,hot*uB*1.3-(1.-fbm(vP*4.+w+vec3(9.,4.,1.)))*1.1)*(1.-gg);\n'+
  ' float a=clamp(gg+ss,0.,1.)*land*.93;if(a<.01)discard;\n'+
  ' float moist=fbm(vP*3.1+vec3(2.,8.,5.)+w);float warm=smoothstep(270.,300.,tl),dryz=smoothstep(305.,335.,tl);\n'+
  ' vec3 cool=mix(vec3(.38,.5,.4),vec3(.12,.32,.22),smoothstep(250.,272.,tl));\n'+
  ' vec3 tem=mix(vec3(.3,.55,.16),vec3(.07,.3,.09),smoothstep(.3,.65,moist));\n'+
  ' vec3 sav=mix(vec3(.62,.58,.25),vec3(.45,.5,.2),smoothstep(.3,.65,moist));\n'+
  ' vec3 gc=mix(mix(cool,tem,warm),sav,dryz)*(.78+.42*nv2);vec3 sc=mix(vec3(.74,.6,.36),vec3(.88,.75,.5),nv2);\n'+
  ' vec3 col=(gc*gg+sc*ss)/(gg+ss+1e-4);\n'+
  ' float dif=.14+.88*uK*clamp(dot(normalize(vNw),normalize(uL)),0.,1.);col*=dif;\n'+
  ' col+=vec3(.2,.5,.3)*pow(1.-max(dot(normalize(vN),normalize(vV)),0.),3.)*.15*uK*gg;\n'+
  ' gl_FragColor=vec4(col,a);}';
function makeVegMat(){return new THREE.ShaderMaterial({transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1.5,
  uniforms:{uV:{value:0},uB:{value:0},uOc:{value:0},uTe:{value:288},uEq:{value:50},uK:{value:1},uL:{value:new THREE.Vector3(1,0,0)},uSd:{value:new THREE.Vector3(0,0,0)},uLM:{value:DUMMY_LM},uUL:{value:0}},vertexShader:LAVA_VS,fragmentShader:VEG_FS});}
/* ---- Облака: цвет и густота зависят от состава атмосферы и океана ---- */
var CLOUD_FS='precision highp float;varying vec3 vP;varying vec3 vNw;varying vec3 vN;varying vec3 vV;uniform float uCov,uTh,uBand,uK;uniform vec3 uL,uCol;\n'+
  'float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\n'+
  'float noise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);\n'+
  ' return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),\n'+
  '            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}\n'+
  'float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}\n'+
  'void main(){vec3 p=vP*2.3;vec3 w=vec3(fbm(p+3.1),fbm(p+7.7),fbm(p+1.3));\n'+
  ' float n=fbm(p*1.25+2.4*w);\n'+
  ' float bd=sin(vP.y*16.+(fbm(p*.6)-.5)*5.)*.5+.5;n=mix(n,n*.55+bd*.6,uBand);\n'+
  ' float th=mix(.84,.06,uCov);float a=smoothstep(th,th+.2,n);\n'+
  ' float det=fbm(p*5.+w*1.5);vec3 col=uCol*(.72+.4*det);\n'+
  ' col=mix(col,col*.78+vec3(.04),smoothstep(.3,.7,fbm(p*2.+w))*.4);\n'+
  ' float dif=.12+.95*uK*clamp(dot(normalize(vNw),normalize(uL)),0.,1.);col*=dif;\n'+
  ' a*=uTh;if(a<.01)discard;\n'+
  ' gl_FragColor=vec4(col,a);}';
function makeCloudMat(){return new THREE.ShaderMaterial({transparent:true,depthWrite:false,
  uniforms:{uCov:{value:0},uTh:{value:.7},uBand:{value:0},uK:{value:1},uL:{value:new THREE.Vector3(1,0,0)},uCol:{value:new THREE.Vector3(1,1,1)}},vertexShader:LAVA_VS,fragmentShader:CLOUD_FS});}
/* вклад каждого вещества: [сила, r,g,b] — вода белая, CO₂/SO₂ жёлтые (Венера), NH₃ кремовые, CH₄ голубые, H₂S жёлто-зелёные; H₂/He дают полосы */
function cloudParams(b){var A=b.atmo0,R={cov:0,col:[1,1,1],band:0};if(!b.atmOn)return R;
  var wo=b.hasOcean?b.oc*Math.min(1,b.wq*3):0,
    W=[[Math.min(1,(A.H2O||0)/4+wo*.55),.97,.98,1],[ss(30,90,A.CO2||0),.93,.82,.5],[Math.min(1,(A.SO2||0)/1.5),.95,.85,.45],
       [Math.min(1,(A.NH3||0)/3),.93,.86,.74],[Math.min(1,(A.CH4||0)/2),.62,.82,.92],[Math.min(1,(A.H2S||0)/2),.85,.86,.5]],
    t=0,r=0,g=0,bl=0,i;
  for(i=0;i<W.length;i++){t+=W[i][0];r+=W[i][0]*W[i][1];g+=W[i][0]*W[i][2];bl+=W[i][0]*W[i][3];}
  if(t>.001){R.col=[r/t,g/t,bl/t];R.cov=Math.min(1,t);}
  R.band=ss(30,80,(A.H2||0)+(A.He||0));
  if(R.band>0){var bc=R.band*.9;if(bc>R.cov){if(t<.001)R.col=[.9,.8,.65];R.cov=bc;}}
  return R;}
/* ---- Кольца: 5 типов; профиль по радиусу рисуется в 1D-текстуру, тень планеты считается в шейдере ---- */
var RING_IN=1.1,RING_SP=1.7,RING_DEF=[['H2O',4],['NH3',3],['S',2],['NH3',5],['C2H6',2]];
var RING_VS='varying vec3 vP;varying vec3 vW;varying vec3 vNr;void main(){vP=position;vW=(modelMatrix*vec4(position,1.)).xyz;vNr=(modelMatrix*vec4(0.,0.,1.,0.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(vW,1.);}';
var RING_FS=['precision highp float;varying vec3 vP;varying vec3 vW;varying vec3 vNr;uniform sampler2D uTex;uniform float uKr,uK,uRp;uniform vec3 uL,uC;',
'void main(){float t=(length(vP.xy)/uKr-1.1)/1.7;if(t<0.||t>1.)discard;vec4 c=texture2D(uTex,vec2(t,.5));if(c.a<.01)discard;',
' vec3 n=normalize(vNr),d=normalize(uL),V=normalize(cameraPosition-vW);',
' float mv=dot(n,V),ml=dot(n,d);',
' float tau=-log(1.-min(c.a,.995));',
' float az=atan(vP.y,vP.x);tau*=1.+.07*sin(az*9.+t*40.)*sin(az*4.-t*23.);',
' float al=1.-exp(-tau/max(abs(mv),.12));',
' vec3 oc=vW-uC;float b=dot(oc,d),pd=sqrt(max(0.,dot(oc,oc)-b*b));',
' float sh=b<0.?1.-smoothstep(uRp*.92,uRp*1.04,pd):0.;',
' float el=smoothstep(0.,.3,abs(ml));',
' float side=mv*ml>0.?1.:(.14+.86*exp(-tau*1.3));',
' float lit=uK*el*side*(1.-.93*sh);',
' float ph=.78+.22*pow(max(dot(-V,d),0.),3.)*uK;',
' gl_FragColor=vec4(c.rgb*(.1+lit*ph),al);}'].join('\n');
function ringProfile(b){var N=2048,d=new Uint8Array(N*4),ty=b.ring,i,j,r,a,c,B,sum=0;
  function sm(p,q,v){v=Math.max(0,Math.min(1,(v-p)/(q-p)));return v*v*(3-2*v);}
  function seg(r,p,q,f){return sm(p,p+f,r)*(1-sm(q-f,q,r));}
  function h1(i){var s=Math.sin(i*127.1)*43758.5453;return s-Math.floor(s);}
  function n1(x){var i=Math.floor(x),f=x-i;f=f*f*(3-2*f);return h1(i)*(1-f)+h1(i+1)*f;}
  if(ty===5){B=b.rbands;for(j=0;j<B.length;j++)sum+=B[j].w;}
  for(i=0;i<N;i++){r=RING_IN+RING_SP*i/(N-1);a=0;c=[1,1,1];var st=.6+.8*(.45*n1(r*45)+.3*n1(r*170+7)+.25*n1(r*640+13));
    if(ty===1){a=.08*seg(r,1.1,1.24,.05)+.28*seg(r,1.24,1.52,.04)+.92*seg(r,1.52,1.95,.03)+.06*seg(r,1.95,2.03,.02)+.72*seg(r,2.03,2.27,.02)+.55*seg(r,2.33,2.35,.008);
      a*=1-.9*seg(r,2.205,2.22,.004);c=r<1.52?[.55,.5,.45]:r<2?[.93,.88,.78]:[.84,.79,.7];}
    else if(ty===2){a=.6*seg(r,1.3,2.05,.08)*(.6+.4*Math.sin(r*90)*Math.sin(r*23));c=[.46,.41,.36];}
    else if(ty===3){a=.3*seg(r,1.1,2.8,.35)*(1-.5*sm(1.1,2.8,r));c=[.76,.56,.36];}
    else if(ty===4){var cs=[1.55,1.68,1.77,1.9,2.02,2.14];for(j=0;j<6;j++)a=Math.max(a,.85*seg(r,cs[j]-.012,cs[j]+.012,.006));a=Math.max(a,.05*seg(r,1.4,2.3,.1));c=[.5,.52,.56];st=1;}
    else if(ty===5){a=.88*seg(r,1.2,2.5,.03);var u=(r-1.2)/1.3,e=0,k;c=GASB[B[0].g][2].slice();
      for(j=1;j<B.length;j++){e+=B[j-1].w;var f=sm(e/sum-.01,e/sum+.01,u),cc=GASB[B[j].g][2];for(k=0;k<3;k++)c[k]+=(cc[k]-c[k])*f;}}
    var tn=.93+.14*n1(r*22+3);c=[c[0]*tn,c[1]*tn,c[2]*tn*(.97+.06*n1(r*11+5))];
    a=Math.max(0,Math.min(1,a*Math.max(0,st)));var br=.9+.1*st;
    d[i*4]=Math.min(255,c[0]*br*255);d[i*4+1]=Math.min(255,c[1]*br*255);d[i*4+2]=Math.min(255,c[2]*br*255);d[i*4+3]=a*255;}
  return d;}
function ringUpd(b){if(!b.ring){if(b.ringMesh)b.ringMesh.visible=false;return;}
  if(!b.ringMesh){var tx=new THREE.DataTexture(new Uint8Array(8192),2048,1,THREE.RGBAFormat),kr=KR[b.kind];tx.minFilter=THREE.LinearMipmapLinearFilter;tx.magFilter=THREE.LinearFilter;tx.generateMipmaps=true;tx.wrapS=tx.wrapT=THREE.ClampToEdgeWrapping;
    b.ringMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,vertexShader:RING_VS,fragmentShader:RING_FS,
      uniforms:{uTex:{value:tx},uKr:{value:kr},uK:{value:1},uRp:{value:b.r},uC:{value:new THREE.Vector3()},uL:{value:new THREE.Vector3(1,0,0)}}});
    b.ringMesh=new THREE.Mesh(new THREE.RingGeometry(RING_IN*kr,(RING_IN+RING_SP)*kr,128,1),b.ringMat);b.ringMesh.rotation.x=-Math.PI/2;b.ringMesh.renderOrder=5;b.mesh.add(b.ringMesh);}
  var tx2=b.ringMat.uniforms.uTex.value;tx2.image.data.set(ringProfile(b));tx2.needsUpdate=true;b.ringMesh.visible=true;}
function ringSet(b,ty){b.ring=ty;if(ty===5&&!b.rbands)b.rbands=RING_DEF.map(function(x){return {g:x[0],w:x[1]};});ringUpd(b);}
/* ---- Масса, температура, вероятность жизни, потеря атмосферы ---- */
var TH_M=.5,LOSS_T=0,MDEF={planet:.055,super:1.5,gas:317.8},MJ=317.8;/* масса в массах Земли (M⊕); порог удержания атмосферы 0,5 M⊕; 1200 с игрового времени = 20 мин на 1× */
var MW={H2:2,He:4,CH4:16,NH3:17,H2O:18,Ne:20,N2:28,CO:28,O2:32,H2S:34,Ar:40,CO2:44,N2O:44,O3:48,SO2:64,Kr:84,Xe:131};
function ss(a,b,v){v=Math.max(0,Math.min(1,(v-a)/(b-a)));return v*v*(3-2*v);}
var RKM={planet:2439.7,super:7344,gas:69911},ZMIN=.3,ZMAX=3,szDrag=false;
function setSize(b,z){z=Math.max(ZMIN,Math.min(ZMAX,z));b.sz=z;var z3=z*z*z;b.M=MDEF[b.kind]*z3;b.m=KM[b.kind]*z3;b.r=KR[b.kind]*z;b.mesh.scale.setScalar(z);}
function setMass(b,v){if(!(v>0))return;setSize(b,Math.cbrt(v/MDEF[b.kind]));}
function atmoEmpty(b){var s=0;for(var i=0;i<GASES.length;i++)s+=b.atmo0[GASES[i][0]]||0;return s<1e-6;}

function lifeProb(b){if(b.star)return 0;var T=b.tAvg;if(isNaN(T))return 0;
  var ts=Math.exp(-Math.pow((T-290)/22,2)),liq=0,k;
  for(k in SOLV)liq+=b.water[k]||0;
  var a=b.atmo0,wf=Math.min(1,liq/15)*Math.min(1,b.wq*3),pres=b.atmOn?Math.min(1.5,b.atmDens*b.aq):0,
    af=ss(.15,.6,pres)*(1-.5*ss(1.2,1.8,pres)),
    tox=1-Math.min(.95,(a.SO2||0)*.12+(a.H2S||0)*.25+(a.NH3||0)*.08+(a.CO||0)*.15+(a.CH4||0)*.015+Math.max(0,(a.CO2||0)-5)*.012),
    ox=.75+.25*Math.min(1,(a.O2||0)/15),mf=ss(.3,.6,b.M)*(1-.5*ss(8,25,b.M));
  return Math.max(0,Math.min(.99,ts*wf*af*tox*ox*mf*(1-Math.min(1,b.lava*1.5))*(1-ss(.12,.55,b.rad||0))));}
/* испарение: вода из океана уходит в атмосферу паром (H2O, а также NH3 и CH4, если они в составе жидкости) */
function addVapor(b,amt){var ws=b.water,sh={H2O:ws.H2O||0,NH3:ws.NH3||0,CH4:ws.CH4||0},ab={},tot=0,i,k;
  if(sh.H2O+sh.NH3+sh.CH4<=0)return;
  for(i=0;i<GASES.length;i++){k=GASES[i][0];ab[k]=(b.atmo0[k]||0)*b.aq/100;}
  for(k in sh)ab[k]+=amt*sh[k]/100;
  for(k in ab)tot+=ab[k];
  if(tot<=1e-6)return;tot=Math.min(8,tot);var f=0;for(k in ab)f+=ab[k];
  for(k in ab)b.atmo0[k]=ab[k]/f*100;b.aq=tot;recompute(b);}
/* малая масса → ядро остыло, нет магнитного поля → ветер сдувает лёгкие газы, тяжёлые остаются */
function thM(b){return b.ring?.3:.5;}
function lossUpd(b,sdt){var th=thM(b),low=b.M<th;if(b.atmOn)b.lostAtm=false;b.losing=false;b.lossI=0;
  if(!low||!b.atmOn||b.aq<=0)return;
  var sc=Math.min(6,Math.pow(th/Math.max(b.M,.01),2)),s0=0,rel=0,ab={},i,k,v,r,aq0=b.aq;
  for(i=0;i<GASES.length;i++){k=GASES[i][0];v=(b.atmo0[k]||0)*aq0/100;r=(.25+.75*Math.max(0,1-Math.pow(MW[k]/46,1.5)))*sc/200;rel+=v*r;v*=Math.exp(-r*sdt);ab[k]=v;s0+=v;}
  var s1=Math.max(0,s0-sdt*.002*sc);
  if(s1<=.01||s0<=1e-6){b.aq=0;for(k in b.atmo0)b.atmo0[k]=0;b.lostAtm=true;}
  else{for(k in ab)b.atmo0[k]=ab[k]/s0*100;b.aq=s1;}
  b.lossI=Math.min(1,Math.max(rel/Math.max(aq0,1e-6)*80,.25*Math.min(1,sc)));b.losing=true;
  recompute(b);}
/* вид атмосферы, океана, растительности и суши — из состава */
function ecoUpd(b,sdt,rdt){if(b.star)return;var k=Math.min(1,rdt*3),i;
  lossUpd(b,sdt);
  if(b.ringMesh&&b.ring){var ru=b.ringMat.uniforms;ru.uK.value=b.near?1:0;ru.uRp.value=b.r;ru.uC.value.set(b.x,b.y,b.z);if(b.near&&b.nd>1e-6)ru.uL.value.set(b.near.x-b.x,b.near.y-b.y,b.near.z-b.z).normalize();}
  if(b.gasMat){var gu=b.gasMat.uniforms;gu.uT.value=simT;gu.uK.value=b.near?1:0;if(b.near&&b.nd>1e-6)gu.uL.value.set(b.near.x-b.x,b.near.y-b.y,b.near.z-b.z).normalize();}
  var tA=b.atmOn?Math.min(2.2,b.atmDens*b.aq)*(1-b.lava):0;b.vA+=(tA-b.vA)*k;
  for(i=0;i<3;i++){b.vC[i]+=(b.atmCol[i]-b.vC[i])*k;b.vO[i]+=(b.ocCol[i]-b.vO[i])*k;}b.vS+=(b.ocShift-b.vS)*k;
  var u=b.atmoMat.uniforms;u.uA.value=b.vA;u.uC.value.set(b.vC[0],b.vC[1],b.vC[2]);
  b.atmoMesh.scale.setScalar(1+Math.max(-.5,Math.min(.6,b.atmDens-1))*.08);
  /* средняя температура: равновесная от звёзд + парниковый эффект */
  var pres=b.atmOn?Math.min(1.5,b.atmDens*b.aq):0,A=b.atmo0,
    ghg=(A.CO2||0)+(A.CH4||0)*25+Math.min(A.H2O||0,2)+(A.SO2||0)*3+(A.NH3||0)*5+(A.N2O||0)*10,
    gh=Math.min(1,pres)*(22+11*Math.min(1,ghg/.05)+450*Math.pow(Math.min(1,ghg/100),.7)),
    tT=b.flux>0?Math.min(1500,255*Math.pow(b.flux*2601,.25)+gh):3;
  if(isNaN(b.tAvg))b.tAvg=tT;else b.tAvg+=(tT-b.tAvg)*Math.min(1,rdt*1.5);
  b.eq=25+55*(1-Math.min(1,pres));
  /* при ≥100 °C вода испаряется; 150 °C — весь океан за 3600 с (час на 1×), чем горячее — тем быстрее */
  b.evap=0;
  if(b.hasOcean&&b.wq>0&&b.tAvg>373.15){var er=Math.min(10,Math.pow((b.tAvg-373.15)/50,1.5))/3600,dw=Math.min(b.wq,er*sdt);b.evap=er;
    if(dw>0){b.wq-=dw;if(b.wq<1e-4)b.wq=0;addVapor(b,dw*3);}}/* разница экватор–полюс: без атмосферы больше */
  /* растительность: нужны вода, атмосфера и умеренная температура */
  var wet=b.h2o>=1&&b.wq>.02&&b.atmOn&&b.lava<.3,lp=lifeProb(b);if(!b.alive&&lp>=.4)b.alive=true;else if(b.alive&&lp<.2)b.alive=false;b.vegOk=b.alive;
  if(b.kind==='super'){if(b.h2o<1||b.wq<=.02)b.dry=Math.min(1,b.dry+sdt/600);else b.dry=Math.max(0,b.dry-sdt/600);}
  if(b.alive)b.veg=Math.min(1,b.veg+sdt/(b.kind==='super'?600:300));
  else if(b.veg>0)b.veg=Math.max(0,b.veg-sdt/600);
  b.bio+=((wet?1:0)-b.bio)*Math.min(1,sdt/30);
  if(b.hasOcean&&b.wq>.02){if(b.oc<b.wq)b.oc=Math.min(b.wq,b.oc+sdt/60);else b.oc=b.wq;}else b.oc=b.hasOcean?0:Math.max(0,b.oc-sdt/600);
  var cp=cloudParams(b);b.cCov+=(cp.cov-b.cCov)*k;b.cBand+=(cp.band-b.cBand)*k;for(i=0;i<3;i++)b.cCol[i]+=(cp.col[i]-b.cCol[i])*k;
  if(b.cloudMesh){var cv=b.cCov*ss(.05,.5,b.vA);b.cloudMesh.visible=cv>.012;
    if(cv>.012){var cu=b.cloudMat.uniforms;cu.uCov.value=Math.min(1,cv);cu.uTh.value=.5+.45*Math.min(1,cv);cu.uBand.value=b.cBand;cu.uCol.value.set(b.cCol[0],b.cCol[1],b.cCol[2]);cu.uK.value=b.near?1:0;
      if(b.near&&b.nd>1e-6)cu.uL.value.set(b.near.x-b.x,b.near.y-b.y,b.near.z-b.z).normalize();}}
  var S=b.SU;if(S){S.uOS.value=b.vS;S.uOc.value=b.oc;S.uDry.value=b.dry;S.uVeg.value=b.veg;S.uOcean.value.setRGB(b.vO[0],b.vO[1],b.vO[2]);S.uTe.value=b.tAvg;S.uEq.value=b.eq;}
  if(b.vegMesh){var vo=b.veg>.003||b.bio>.003;b.vegMesh.visible=vo;
    if(vo){var vu=b.vegMat.uniforms;vu.uV.value=b.veg;vu.uB.value=b.bio;vu.uOc.value=b.oc;vu.uTe.value=b.tAvg;vu.uEq.value=b.eq;vu.uK.value=b.near?1:0;
      if(b.near&&b.nd>1e-6)vu.uL.value.set(b.near.x-b.x,b.near.y-b.y,b.near.z-b.z).normalize();}}
  if(b.waterMesh){var on=b.oc>.003;b.waterMesh.visible=on;
    if(on){var wu=b.waterMat.uniforms,s=b.vS;wu.uOc.value=b.oc;
      wu.uCol.value.set(.1*(1-s)+b.vO[0]*s,.35*(1-s)+b.vO[1]*s,.7*(1-s)+b.vO[2]*s);
      wu.uK.value=b.near?1:0;if(b.near&&b.nd>1e-6)wu.uL.value.set(b.near.x-b.x,b.near.y-b.y,b.near.z-b.z).normalize();}}}
/* ---- Уходящая атмосфера: частицы ---- */
var whiteTex=(function(){var c=document.createElement('canvas');c.width=c.height=64;var g=c.getContext('2d'),gr=g.createRadialGradient(32,32,0,32,32,32);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.4,'rgba(255,255,255,.55)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,64,64);return new THREE.CanvasTexture(c);})();
var aparts=[];(function(){for(var i=0;i<180;i++){var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:whiteTex,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,opacity:0}));sp.visible=false;scene.add(sp);aparts.push({s:sp,life:0,max:1,v:new THREE.Vector3(),sz:1});}})();
function emitAtmo(b,dt,ax,az){var f=1-b.lava,rate=(b.hot?Math.min(1,b.lava*5)*Math.min(1,f*4):0)+(b.losing?b.lossI:0);if(!b.atmOn||f<=.0005||rate<=.001)return;
  b.pAcc+=dt*34*rate;
  while(b.pAcc>=1){b.pAcc-=1;var p=null,i;for(i=0;i<aparts.length;i++)if(aparts[i].life<=0){p=aparts[i];break;}if(!p){b.pAcc=0;break;}
    var ux=Math.random()-.5,uy=(Math.random()-.5)*.8,uz=Math.random()-.5,ul=Math.sqrt(ux*ux+uy*uy+uz*uz)||1;ux/=ul;uy/=ul;uz/=ul;
    var r=b.r,sp=r*(.8+Math.random()*1.2),aw=r*(1.5+Math.random()*2.5);
    p.s.position.set(b.mesh.position.x+ux*r*1.06,b.mesh.position.y+uy*r*1.06,b.mesh.position.z+uz*r*1.06);
    p.v.set(ux*sp+ax*aw,uy*sp,uz*sp+az*aw);
    p.max=p.life=2.5+Math.random()*2;p.sz=r*(.8+Math.random()*1.1);
    var h=Math.min(1,b.lava*1.4);if(h>.02)p.s.material.color.setRGB(.45+.55*h,.75-.25*h,1-.85*h);else p.s.material.color.setRGB(.4+.6*b.vC[0],.4+.6*b.vC[1],.4+.6*b.vC[2]);p.s.visible=true;}}
function updAParts(sdt){for(var i=0;i<aparts.length;i++){var p=aparts[i];if(p.life<=0)continue;p.life-=sdt;
  if(p.life<=0){p.s.visible=false;continue;}
  p.s.position.addScaledVector(p.v,sdt);var f=p.life/p.max;p.s.material.opacity=f*.75;p.s.scale.setScalar(p.sz*(1.4-.6*f));}}
function lavaUpd(b,dt,vdt){if(b.star||(!b.lavaMesh&&b.kind!=='gas'))return;var hot=false,near=null,nd=1e9,j,s,d,F=0;
  for(j=0;j<bodies.length;j++){s=bodies[j];if(!s.star||s.bh)continue;d=Math.hypot(b.x-s.x,b.y-s.y,b.z-s.z);if(d<nd){nd=d;near=s;}if(!s.gm){if(d<78*s.zs)hot=true;var de=d/(3*s.zs);F+=1/Math.max(de*de,1);}/* расстояния ×3: 1 а.е. = 153 ед. */}
  for(j=0;j<EM.length;j++){d=Math.hypot(b.x-EM[j].x,b.y-EM[j].y,b.z-EM[j].z);if(d<78*EM[j].zs)hot=true;var de2=d/(3*EM[j].zs);F+=1/Math.max(de2*de2,1);}
  b.flux=F;b.hot=hot;b.near=near;b.nd=nd;
  var imp=b.heatT>0;if(imp)b.heatT-=vdt;
  if((hot||imp)&&b.lava<1&&b.lavaMesh){b.lava=Math.min(1,b.lava+dt/(imp&&!hot?3:30));
    {var fa=1-b.lava;for(var gk in b.atmo0)b.atmo[gk]=b.atmo0[gk]*fa;}}
  else if(!hot&&!imp&&b.lava>0&&b.lavaMesh){b.lava=Math.max(0,b.lava-dt/50);
    {var fb=1-b.lava;for(var gk2 in b.atmo0)b.atmo[gk2]=b.atmo0[gk2]*fb;}}
  if(b.atmOn){if(near&&nd>1e-6)emitAtmo(b,vdt,(b.x-near.x)/nd,(b.z-near.z)/nd);else emitAtmo(b,vdt,0,0);}
  if(b.lava<=.002&&b.lavaMesh)b.lavaMesh.visible=false;if(b.lava>.002){b.lavaMesh.visible=true;var u=b.lavaMat.uniforms;u.uP.value=b.lava;u.uT.value=simT;if(near&&nd>1e-6)u.uL.value.set(near.x-b.x,near.y-b.y,near.z-b.z).normalize();}}
/* ---- N-тела ---- */
var G=0.3,SUNM=2000,DT=0.02,SPEED=2,PULL_K=0.5;
var bodies=[];var KM={star:SUNM,dwarf:SUNM/10,planet:4,super:10,gas:40,bh:SUNM*120000};var PP_RANGE=60,PP_MAX=12,PP_K=.35,MOON_K=3,MOON_MAX=40,CAP_NU=.5;/* спутник: масса ≤ 1/3 массы хозяина; сфера влияния = ½ радиуса Хилла *//* планета-планета: мягкое притяжение вблизи (до 60 радиусов, не дальше 12 ед.), к краю плавно сходит на ноль */
var _ax=new Float64Array(64),_az=new Float64Array(64),_ay=new Float64Array(64),_ar=[_ax,_az,_ay];
function soiUpd(bs){var n=bs.length,i,k;for(i=0;i<n;i++){if(bs[i].star)continue;var ds=1e9,Ms=0;for(k=0;k<n;k++)if(bs[k].star){var sx=bs[k].x-bs[i].x,sz=bs[k].z-bs[i].z,sy=bs[k].y-bs[i].y,sd=Math.sqrt(sx*sx+sy*sy+sz*sz);if(sd<ds){ds=sd;Ms=bs[k].m;}}bs[i]._R=Ms>0?Math.min(MOON_MAX,.5*ds*Math.cbrt(bs[i].m/(3*Ms))):PP_MAX;}}
function acc(bs){var n=bs.length,i,j;
  if(n>_ax.length){_ax=new Float64Array(n*2);_az=new Float64Array(n*2);_ay=new Float64Array(n*2);_ar=[_ax,_az,_ay];}
  var ax=_ax,az=_az,ay=_ay;
  for(i=0;i<n;i++){ax[i]=0;az[i]=0;ay[i]=0;}
  for(i=0;i<n;i++)for(j=0;j<n;j++){if(i===j||(bs[i].star&&!bs[j].star))continue;var dx=bs[j].x-bs[i].x,dz=bs[j].z-bs[i].z,dy=bs[j].y-bs[i].y,d2=dx*dx+dz*dz+dy*dy+.01+(bs[j].bh?.49*bs[j].r*bs[j].r:0);var f0=1;if(!bs[i].star&&!bs[j].star){if(bs[i].mg===bs[j]||bs[j].mg===bs[i])continue;var rr=Math.min(PP_MAX,PP_RANGE*Math.max(bs[i].r,bs[j].r)),dd=Math.sqrt(d2),fw=0;if(dd<rr){var q=dd/rr,tq=Math.max(0,Math.min(1,(q-.5)/.5));fw=PP_K*(1-tq*tq*(3-2*tq));}
    var Rh=bs[j].M>=MOON_K*bs[i].M?bs[j]._R:bs[i].M>=MOON_K*bs[j].M?bs[i]._R:0;
    if(Rh>0&&dd<Rh){var u=Math.max(0,Math.min(1,(dd/Rh-.7)/.3));u=u*u*(3-2*u);f0=1+(fw-1)*u;}else{if(fw===0)continue;f0=fw;}}var f=f0*G*bs[j].m/(d2*Math.sqrt(d2));ax[i]+=dx*f;az[i]+=dz*f;ay[i]+=dy*f;}
  return _ar;}
function lf(bs,dt){var a=acc(bs),i;
  for(i=0;i<bs.length;i++){bs[i].vx+=a[0][i]*dt/2;bs[i].vz+=a[1][i]*dt/2;bs[i].vy+=a[2][i]*dt/2;bs[i].x+=bs[i].vx*dt;bs[i].z+=bs[i].vz*dt;bs[i].y+=bs[i].vy*dt;}
  a=acc(bs);for(i=0;i<bs.length;i++){bs[i].vx+=a[0][i]*dt/2;bs[i].vz+=a[1][i]*dt/2;bs[i].vy+=a[2][i]*dt/2;}}
var Y1=1/(2-Math.cbrt(2)),Y0=-Math.cbrt(2)*Y1;
function step(bs,dt,kmax){var n=bs.length,tmin=1e9,i,j;soiUpd(bs);
  for(i=0;i<n;i++)for(j=i+1;j<n;j++){if(bs[i].mg===bs[j])continue;var dx=bs[j].x-bs[i].x,dz=bs[j].z-bs[i].z,dy=bs[j].y-bs[i].y,d=Math.sqrt(dx*dx+dz*dz+dy*dy),t=Math.sqrt(d*d*d/(G*(bs[i].m+bs[j].m)));if(t<tmin)tmin=t;}
  var k=Math.min(kmax||160,Math.max(1,Math.ceil(dt/(0.02*tmin)))),h=dt/k;
  for(var s=0;s<k;s++){lf(bs,h*Y1);lf(bs,h*Y0);lf(bs,h*Y1);}}
function zeroMomentum(bs){var px=0,pz=0,py=0,M=0,i;for(i=0;i<bs.length;i++){M+=bs[i].m;px+=bs[i].m*bs[i].vx;pz+=bs[i].m*bs[i].vz;py+=bs[i].m*bs[i].vy;}for(i=0;i<bs.length;i++){bs[i].vx-=px/M;bs[i].vz-=pz/M;bs[i].vy-=py/M;}}
var ringTex=(function(){var c=document.createElement('canvas');c.width=c.height=64;var g=c.getContext('2d');g.strokeStyle='rgba(170,220,255,.95)';g.lineWidth=5;g.beginPath();g.arc(32,32,24,0,6.283);g.stroke();return new THREE.CanvasTexture(c);})();
function makeMarker(){var s=new THREE.Sprite(new THREE.SpriteMaterial({map:ringTex,depthTest:false,transparent:true,sizeAttenuation:false}));s.scale.set(.04,.04,1);s.renderOrder=12;scene.add(s);return s;}
function markerUpd(b){var d=camera.position.distanceTo(b.mesh.position),px=b.r*window.innerHeight/(2*d*Math.tan(camera.fov*Math.PI/360)),o=Math.max(0,Math.min(1,1-(px-5)/8)),want=b.hi?px>16:px>22;if(b.kind==='planet'&&b.hi!==want){b.hi=want;b.mesh.material=want?getHigh(b.mapId|0):getLow(b.mapId|0);}b.marker.visible=showAids&&o>0;b.marker.position.copy(b.mesh.position);b.marker.material.opacity=o;}
var TN=900;
function makeTrail(){var g=new THREE.BufferGeometry(),pa=new Float32Array(TN*3),ca=new Float32Array(TN*3);
  g.setAttribute('position',new THREE.BufferAttribute(pa,3));g.setAttribute('color',new THREE.BufferAttribute(ca,3));g.setDrawRange(0,0);
  var l=new THREE.Line(g,new THREE.LineBasicMaterial({vertexColors:true,blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  l.frustumCulled=false;scene.add(l);return {pa:pa,ca:ca,n:0,line:l,g:g};}
function recTrail(b){var t=b.trail;if(t.n<TN)t.n++;else t.pa.copyWithin(0,3);var k=(t.n-1)*3;t.pa[k]=b.x;t.pa[k+1]=b.y+0.04;t.pa[k+2]=b.z;
  for(var i=0;i<t.n;i++){var f=t.n>1?i/(t.n-1):1;f=f*f*.85;var cr=b.bh?[.75,.55,1]:b.star?[1,.8,.25]:[.55,.78,1];t.ca[i*3]=cr[0]*f;t.ca[i*3+1]=cr[1]*f;t.ca[i*3+2]=cr[2]*f;}
  t.g.attributes.position.needsUpdate=true;t.g.attributes.color.needsUpdate=true;t.g.setDrawRange(0,t.n);}
function isStarT(t){return t==='star'||t==='dwarf'||t==='bh';}
function addBody(type,x,z,vx,vz){var st=isStarT(type),SU=type==='super'?{uOS:{value:0},uOc:{value:1},uDry:{value:0},uVeg:{value:1},uOcean:{value:new THREE.Color(.1,.35,.7)},uTe:{value:288},uEq:{value:50}}:null,m=new THREE.Mesh(GEO[type],type==='gas'?makeGasMat(0):SU?makeSeMat(SU):MAT[type]);scene.add(m);var aM=st?null:atmoMat.clone(),aMesh=null;if(aM){aMesh=new THREE.Mesh(type==='super'?atmoGeo:type==='gas'?atmoGeoG:atmoGeoP,aM);aMesh.renderOrder=4;m.add(aMesh);}
  var b={x:x,y:0,z:z,vx:vx,vy:0,vz:vz,m:KM[type],mesh:m,trail:makeTrail(),marker:makeMarker(),star:st,kind:type,r:KR[type]};
  if(type==='bh'){initBH(b,m);}else if(st){b.glow=makeGlow();b.light=makeLight();var zm=new THREE.Mesh(zoneGeo,zoneMat);zm.rotation.x=-Math.PI/2;zm.renderOrder=2;zm.frustumCulled=false;zm.visible=!!showZones;scene.add(zm);b.zone=zm;m.material=makeStarMat();b.T=msT(b.m/SUNM);CNT[type]=(CNT[type]||0)+1;b.defName=(type==='dwarf'?'Красный карлик ':'Солнце ')+CNT[type];b.name=b.defName;starApply(b);if(type==='dwarf')b.fT=1+Math.random()*3;}if(!st){CNT[type]=(CNT[type]||0)+1;b.defName=(type==='super'?'Супер-Земля ':type==='gas'?'Газовый гигант ':'Планета ')+CNT[type];b.name=b.defName;b.atmo0={};b.atmo={};b.water={};var srcA=ATMO[type]||{},srcW=WATER[type]||{},q;for(q in srcA)b.atmo0[q]=srcA[q];for(q in srcW)b.water[q]=srcW[q];b.atmoMat=aM;b.atmoMesh=aMesh;b.SU=SU;b.gasMat=type==='gas'?m.material:null;b.tilt=0;b.spin=.5;b.ring=0;b.lostAtm=false;m.rotation.order='ZYX';if(type==='gas'){b.bands=gasPreset(0);gasBands(b);}b.hot=false;b.pAcc=0;b.dry=0;b.veg=type==='super'?1:0;b.extinct=false;b.oc=0;b.M=MDEF[type];b.cCov=0;b.cCol=[1,1,1];b.cBand=0;b.sz=1;b.alive=type==='super';b.wq=1;b.evap=0;b.aq=1;b.lowT=0;b.losing=false;b.lossI=0;b.tAvg=NaN;b.eq=50;b.bio=0;b.vegOk=false;b.flux=0;b.mapId=0;b.lava=0;b.snow=0;if(type!=='gas'){b.lavaMat=makeLavaMat();b.lavaMesh=new THREE.Mesh(GEO[type],b.lavaMat);b.lavaMesh.scale.setScalar(1.004);b.lavaMesh.renderOrder=3;b.lavaMesh.visible=false;m.add(b.lavaMesh);b.snow=0;b.snowMat=makeSnowMat();b.snowMesh=new THREE.Mesh(GEO[type],b.snowMat);b.snowMesh.scale.setScalar(1.003);b.snowMesh.renderOrder=2;b.snowMesh.visible=false;m.add(b.snowMesh);b.cloudMat=makeCloudMat();b.cloudMesh=new THREE.Mesh(GEO[type],b.cloudMat);b.cloudMesh.scale.setScalar(1.012);b.cloudMesh.renderOrder=3.5;b.cloudMesh.visible=false;m.add(b.cloudMesh);}if(type==='planet'){b.waterMat=makeWaterMat();b.waterMesh=new THREE.Mesh(GEO[type],b.waterMat);b.waterMesh.scale.setScalar(1.002);b.waterMesh.renderOrder=1;b.waterMesh.visible=false;m.add(b.waterMesh);b.vegMat=makeVegMat();b.vegMesh=new THREE.Mesh(GEO[type],b.vegMat);b.vegMesh.scale.setScalar(1.0025);b.vegMesh.renderOrder=1.5;b.vegMesh.visible=false;m.add(b.vegMesh);}recompute(b);b.vA=b.atmOn?b.atmDens:0;b.vC=b.atmCol.slice();b.vS=b.ocShift;b.vO=b.ocCol.slice();b.oc=b.hasOcean?1:0;}bodies.push(b);}
function removeBody(b){if(b.SU){var sm=b.mesh.material,si=seMats.indexOf(sm);if(si>=0)seMats.splice(si,1);sm.dispose();}if(b.ringMesh){b.ringMesh.geometry.dispose();b.ringMat.uniforms.uTex.value.dispose();b.ringMat.dispose();}if(b.star&&!b.bh)b.mesh.material.dispose();if(b.bhMat)b.bhMat.dispose();if(b.bhMat2)b.bhMat2.dispose();if(b.gasMat)b.gasMat.dispose();if(b.waterMat)b.waterMat.dispose();if(b.vegMat)b.vegMat.dispose();if(b.cloudMat)b.cloudMat.dispose();if(b.lavaMat)b.lavaMat.dispose();if(b.atmoMat)b.atmoMat.dispose();if(b.snowMat)b.snowMat.dispose();if(b.zone)scene.remove(b.zone);scene.remove(b.mesh);scene.remove(b.marker);scene.remove(b.trail.line);b.trail.g.dispose();if(b.glow){scene.remove(b.glow);if(b.light)freeLight(b.light);}var k=bodies.indexOf(b);if(k>=0)bodies.splice(k,1);releaseMaps();}

/* ---- Орбита-превью (пурпурная) и линия натяжения ---- */
var N_PREV=4500,prevArr=new Float32Array(N_PREV*3),prevCol=new Float32Array(N_PREV*3);
var prevGeo=new THREE.BufferGeometry();prevGeo.setAttribute('position',new THREE.BufferAttribute(prevArr,3));prevGeo.setAttribute('color',new THREE.BufferAttribute(prevCol,3));prevGeo.setDrawRange(0,0);
var prevLine=new THREE.Line(prevGeo,new THREE.LineBasicMaterial({vertexColors:true,depthTest:false,transparent:true}));
prevLine.renderOrder=10;prevLine.frustumCulled=false;prevLine.visible=false;scene.add(prevLine);
var pullArr=new Float32Array(6),pullGeo=new THREE.BufferGeometry();pullGeo.setAttribute('position',new THREE.BufferAttribute(pullArr,3));
var pullLine=new THREE.Line(pullGeo,new THREE.LineBasicMaterial({color:0xe0c4ff,depthTest:false,transparent:true}));
pullLine.renderOrder=11;pullLine.frustumCulled=false;pullLine.visible=false;scene.add(pullLine);
var ghost,ghostM;/* создаются в startGame(): им нужна геометрия каменной планеты */
/* ---- Орбита: элементы относительно ближайшей звезды, правка и линия на сцене ---- */
var ZB=[78,120,186],ZNM=['выжженная','жаркая','обитаемая','холодная'],ZC=[[1,.28,.18],[1,.62,.15],[.3,1,.45],[.35,.65,1]];
function zoneOf(dn){return dn<ZB[0]?0:dn<ZB[1]?1:dn<ZB[2]?2:3;}
function zoneEm(i){var c=ZC[i];return '<em style="font-style:normal;color:rgb('+Math.round(c[0]*255)+','+Math.round(c[1]*255)+','+Math.round(c[2]*255)+')">'+ZNM[i]+'</em>';}
function orbEl(b){var s=b.near;if(!s||bodies.indexOf(s)<0)return null;
  var rx=b.x-s.x,ry=b.y-s.y,rz=b.z-s.z,vx=b.vx-s.vx,vy=b.vy-s.vy,vz=b.vz-s.vz,mu=G*s.m,r=Math.sqrt(rx*rx+ry*ry+rz*rz),v2=vx*vx+vy*vy+vz*vz;if(r<1e-6)return null;
  var hx=ry*vz-rz*vy,hy=rz*vx-rx*vz,hz=rx*vy-ry*vx,hm=Math.sqrt(hx*hx+hy*hy+hz*hz),
    cx_=vy*hz-vz*hy,cy_=vz*hx-vx*hz,cz_=vx*hy-vy*hx,ex=cx_/mu-rx/r,ey=cy_/mu-ry/r,ez=cz_/mu-rz/r,e=Math.sqrt(ex*ex+ey*ey+ez*ez),
    en=v2/2-mu/r,a=en<0?-mu/(2*en):Infinity,p=hm*hm/mu,inc=hm>1e-9?Math.acos(Math.max(-1,Math.min(1,hy/hm))):0,sg=hy<0?-1:1;
  return {s:s,mu:mu,r:r,rv:[rx,ry,rz],vv:[vx,vy,vz],h:[hx,hy,hz],hm:hm,e:e,ev:[ex,ey,ez],a:a,p:p,rp:p/(1+e),ra:e<1?p/(1-e):Infinity,
    incD:(inc>Math.PI/2?Math.PI-inc:inc)*180/Math.PI,retro:sg<0,sg:sg,T:a<Infinity?6.28319*Math.sqrt(a*a*a/mu):0,v:Math.sqrt(v2),vc:Math.sqrt(mu/r),zs:(s.gm&&s.gr?s.gr.Zs:s.zs)};}
function rotA(v,ax,th){var c=Math.cos(th),sn=Math.sin(th),d=ax[0]*v[0]+ax[1]*v[1]+ax[2]*v[2],
  cr=[ax[1]*v[2]-ax[2]*v[1],ax[2]*v[0]-ax[0]*v[2],ax[0]*v[1]-ax[1]*v[0]];
  return [v[0]*c+cr[0]*sn+ax[0]*d*(1-c),v[1]*c+cr[1]*sn+ax[1]*d*(1-c),v[2]*c+cr[2]*sn+ax[2]*d*(1-c)];}
function applyRel(b,o,r,v){var s=o.s;b.x=s.x+r[0];b.y=s.y+r[1];b.z=s.z+r[2];b.vx=s.vx+v[0];b.vy=s.vy+v[1];b.vz=s.vz+v[2];}
/* наклон: вращаем всю орбиту вокруг линии узлов — форма и размер орбиты не меняются */
function tiltTo(b,deg){var o=orbEl(b);if(!o||o.hm<1e-9)return false;deg=Math.max(0,Math.min(90,deg));var th=(deg-o.incD)*Math.PI/180;if(Math.abs(th)<1e-7)return false;
  var ys=[0,o.sg,0],hn=[o.h[0]/o.hm,o.h[1]/o.hm,o.h[2]/o.hm],ax=[ys[1]*hn[2]-ys[2]*hn[1],ys[2]*hn[0]-ys[0]*hn[2],ys[0]*hn[1]-ys[1]*hn[0]],l=Math.hypot(ax[0],ax[1],ax[2]);
  if(l<1e-6){var hl=Math.hypot(o.rv[0],o.rv[2]);ax=hl>1e-6?[o.rv[0]/hl,0,o.rv[2]/hl]:[1,0,0];}else ax=[ax[0]/l,ax[1]/l,ax[2]/l];
  applyRel(b,o,rotA(o.rv,ax,th),rotA(o.vv,ax,th));return true;}
/* расстояние: подобная орбита крупнее/мельче (форма та же) */
function distTo(b,nr){var o=orbEl(b);if(!o)return false;nr=Math.max((b.near?b.near.r:SUN_R)+b.r+.5,Math.min(1000,nr));if(Math.abs(nr-o.r)<1e-6)return false;
  var k=nr/o.r,kv=1/Math.sqrt(k);applyRel(b,o,[o.rv[0]*k,o.rv[1]*k,o.rv[2]*k],[o.vv[0]*kv,o.vv[1]*kv,o.vv[2]*kv]);return true;}
/* скорость в % от круговой на этом расстоянии: <100 — вытянутая орбита внутрь, >100 — наружу */
function speedTo(b,pct){var o=orbEl(b);if(!o||o.v<1e-9)return false;pct=Math.max(1,Math.min(300,pct));var k=pct/100*o.vc/o.v;if(Math.abs(k-1)<1e-7)return false;
  applyRel(b,o,o.rv,[o.vv[0]*k,o.vv[1]*k,o.vv[2]*k]);return true;}
function orbSet(b,key,v){if(key==='I')return tiltTo(b,v);if(key==='D')return distTo(b,v);if(key==='V')return speedTo(b,v);return false;}
function orbStep(b,key,d){var o=orbEl(b);if(!o)return false;
  if(key==='I')return tiltTo(b,Math.round(o.incD*10)/10+d);
  if(key==='D')return distTo(b,o.r*Math.pow(1.01,d));
  if(key==='V')return speedTo(b,o.v/o.vc*100+d);return false;}
function fmtO(x,dg){return String(+x.toFixed(dg)).replace('.',',');}
function orbRefresh(b,act){var o=orbEl(b);
  function sv(id,t){var e=$(id);if(e&&e._t!==t){e._t=t;e.innerHTML=t;}}
  function si(key,t){var e=infoEls[key];if(e&&e!==act&&e.value!==t)e.value=t;}
  if(!o){si('oI','—');si('oD','—');si('oV','—');sv('vOe','—');sv('vOp','—');sv('vOa','—');sv('vOt','—');sv('infoOrb','Рядом нет звезды — планета не на орбите.');return;}
  si('oI',fmtO(o.incD,1));si('oD',fmtO(o.r,1));si('oV',fmtO(o.v/o.vc*100,1));
  sv('vOe',fmtO(o.e,2));
  var zp=zoneOf(o.rp/o.zs),za=o.ra===Infinity?3:zoneOf(o.ra/o.zs);
  sv('vOp',fmtO(o.rp,1)+' · '+zoneEm(zp));
  sv('vOa',(o.ra===Infinity?'∞':fmtO(o.ra,1))+' · '+zoneEm(za));
  sv('vOt',o.T>0?fmtO(o.T/2,o.T/2<10?1:0)+' с':'—');
  var t,i;
  if(o.rp<(b.near?b.near.r:SUN_R)+b.r)t='⚠ Ближайшая точка — внутри звезды: планета упадёт на неё.';
  else{var nm=[];for(i=zp;i<=za;i++)nm.push(zoneEm(i));
    t=(zp===za?'Орбита целиком в зоне: ':'Орбита проходит через зоны: ')+nm.join(' → ')+'.';
    if(o.e>=1)t+=' Орбита незамкнутая — планета улетит из системы.';
    else if(o.retro)t+=' Обратное направление обращения.';}
  sv('infoOrb',t);}
var OB=240,orbPos=new Float32Array((OB+1)*3),orbCol=new Float32Array((OB+1)*3),orbGeo=new THREE.BufferGeometry();
orbGeo.setAttribute('position',new THREE.BufferAttribute(orbPos,3));orbGeo.setAttribute('color',new THREE.BufferAttribute(orbCol,3));orbGeo.setDrawRange(0,0);
var orbLine=new THREE.Line(orbGeo,new THREE.LineBasicMaterial({vertexColors:true,depthTest:false,transparent:true,opacity:.95}));
orbLine.renderOrder=9;orbLine.frustumCulled=false;orbLine.visible=false;scene.add(orbLine);
function orbUpd(){var b=infoBody;if(!b||b.star){orbLine.visible=false;return;}var o=orbEl(b);if(!o||o.hm<1e-9){orbLine.visible=false;return;}
  var e=o.e,H=[o.h[0]/o.hm,o.h[1]/o.hm,o.h[2]/o.hm],P,i,rl=o.r;
  if(e>1e-5)P=[o.ev[0]/e,o.ev[1]/e,o.ev[2]/e];else P=[o.rv[0]/rl,o.rv[1]/rl,o.rv[2]/rl];
  var Q=[H[1]*P[2]-H[2]*P[1],H[2]*P[0]-H[0]*P[2],H[0]*P[1]-H[1]*P[0]],a0=0,a1=6.28319;
  if(e>=1){var nl=Math.acos(Math.max(-1,Math.min(1,(o.p/500-1)/e)));a0=-nl;a1=nl;}
  for(i=0;i<=OB;i++){var nu=a0+(a1-a0)*i/OB,r=o.p/(1+e*Math.cos(nu)),cn=Math.cos(nu)*r,sn=Math.sin(nu)*r,c=ZC[zoneOf(r/o.zs)];
    orbPos[i*3]=o.s.x+P[0]*cn+Q[0]*sn;orbPos[i*3+1]=o.s.y+P[1]*cn+Q[1]*sn+.03;orbPos[i*3+2]=o.s.z+P[2]*cn+Q[2]*sn;
    orbCol[i*3]=c[0];orbCol[i*3+1]=c[1];orbCol[i*3+2]=c[2];}
  orbGeo.attributes.position.needsUpdate=true;orbGeo.attributes.color.needsUpdate=true;orbGeo.setDrawRange(0,OB+1);orbLine.visible=true;}
function hitStar(sim,me,lim){for(var j=0;j<sim.length-1;j++)if(sim[j].star&&!sim[j].bh&&Math.hypot(me.x-sim[j].x,me.z-sim[j].z)<lim-SUN_R+(sim[j].r||SUN_R))return true;return false;}
/* Масштаб оттяжки: круговая орбита у любого объекта получается при оттяжке ≈28 единиц (у обычных тел — как раньше) */
function pullK(x,z){var vc=0,i,b;for(i=0;i<bodies.length;i++){b=bodies[i];var dx=b.x-x,dy=b.y,dz=b.z-z,d=Math.sqrt(dx*dx+dy*dy+dz*dz),d2=d*d+.01+(b.bh?.49*b.r*b.r:0),a=G*b.m*d/(d2*Math.sqrt(d2)),v=Math.sqrt(a*d);if(v>vc)vc=v;}
  return PULL_K*Math.max(1,vc/14);}
function preview(x,z,vx,vz){
  var sim=bodies.map(function(b){return {x:b.x,y:b.y,z:b.z,vx:b.vx,vy:b.vy,vz:b.vz,m:b.m,M:b.M,star:b.star,bh:b.bh,r:b.r,zs:b.zs};});
  var PS_=plSpec();sim.push({x:x,y:0,z:z,vx:vx,vy:0,vz:vz,m:PS_.m,M:PS_.M,star:isStarT(placeType),bh:placeType==='bh',r:PS_.r});var me=sim[sim.length-1],n=0,ang=0,last=null,lastS=null,j,c,fl=isStarT(placeType);
  var t0=performance.now();
  for(var k=0;k<N_PREV;k++){if((k&15)===15&&performance.now()-t0>PV_BUDGET)break;/* бюджет времени: не дольше ~7 мс за кадр */
    /* шаг подстраивается под скорость динамики: медленные орбиты — до 0,4 (линия по времени в 5 раз длиннее прежней), быстрые — 0,08 */
    var td=1e9;for(j=0;j<sim.length-1;j++){var ex=me.x-sim[j].x,ey=me.y-sim[j].y,ez=me.z-sim[j].z,ed=Math.sqrt(ex*ex+ey*ey+ez*ez)+1e-6,t2=Math.sqrt(ed*ed*ed/(G*(me.m+sim[j].m)));if(t2<td)td=t2;}
    var PDT=td>.5?Math.max(.08,Math.min(.4,.04*td)):Math.max(.0004,.12*td);
    step(sim,PDT,td>.5?4:16);if(!fl)captureStep(PDT,sim);/* спутник: планета может перетянуть его на себя */
    var ns=null,nd=1e9;if(!fl)for(j=0;j<sim.length-1;j++)if(sim[j].star){var dd=Math.hypot(me.x-sim[j].x,me.y-sim[j].y,me.z-sim[j].z);if(dd<nd){nd=dd;ns=sim[j];}}
    prevArr[n*3]=me.x;prevArr[n*3+1]=me.y+0.05;prevArr[n*3+2]=me.z;
    c=fl?[.69,.31,1]:(ns&&ns.bh)?[.62,.5,1]:ZC[ns?zoneOf(nd/(ns.zs||1)):3];prevCol[n*3]=c[0];prevCol[n*3+1]=c[1];prevCol[n*3+2]=c[2];n++;
    if(hitStar(sim,me,SUN_R+KR[placeType]))break;
    if(!fl){var hp=false;for(j=0;j<sim.length-1;j++)if(!sim[j].star&&Math.hypot(me.x-sim[j].x,me.y-sim[j].y,me.z-sim[j].z)<sim[j].r+me.r){hp=true;break;}if(hp)break;}/* упал на планету */
    if(Math.hypot(me.x,me.z)>1e7)break;
    /* орбита замкнулась — один полный оборот (+3%) вокруг того, что держит тело: планеты-хозяина (если перетянула) или ближайшей звезды */
    var ref=(me.host&&sim.indexOf(me.host)>=0)?me.host:ns;
    if(ref){if(ref!==lastS){lastS=ref;last=null;ang=0;}var a=Math.atan2(me.z-ref.z,me.x-ref.x);if(last!==null){var da=a-last;if(da>Math.PI)da-=6.28319;if(da<-Math.PI)da+=6.28319;ang+=da;}last=a;if(Math.abs(ang)>6.28319*1.03)break;}}
  prevGeo.attributes.position.needsUpdate=true;prevGeo.attributes.color.needsUpdate=true;prevGeo.setDrawRange(0,n);}

var PV_BUDGET=7,pvReq=null;
function pvFlush(){if(!pvReq)return;var q=pvReq;pvReq=null;preview(q[0],q[1],q[2],q[3]);}

/* ---- UI ---- */
var mode='idle',drag=null,showAids=true,showZones=false,paused=false,placeType='star';
function $(i){return document.getElementById(i);}
var pbtn=$('pbtn'),tray=$('tray');
var POPS=['popMenu','popClock','popBook','popSet'];
function closeAll(){POPS.forEach(function(i){$(i).classList.remove('show');});tray.classList.remove('open');closeInfo();}
function togglePop(id){var on=$(id).classList.contains('show');closeAll();if(!on)$(id).classList.add('show');}
function setMode(m){if(moonSt)cancelMoon();mode=m;pbtn.classList.toggle('active',m==='placing');closeAll();}
function paintIcon(id,t){var c=$(id),g=c.getContext('2d');g.clearRect(0,0,c.width,c.height);g.drawImage(ICON[t],0,0,c.width,c.height);}
function showTab(s){var r=tray.querySelectorAll('.trow'),tb=tray.querySelectorAll('.ttab'),i;for(i=0;i<r.length;i++)r[i].classList.toggle('on',r[i].getAttribute('data-s')===s);for(i=0;i<tb.length;i++)tb[i].classList.toggle('sel',tb[i].getAttribute('data-s')===s);}
function showTab(s){var r=tray.querySelectorAll('.trow'),tb=tray.querySelectorAll('.ttab'),i;for(i=0;i<r.length;i++)r[i].classList.toggle('on',r[i].getAttribute('data-s')===s);for(i=0;i<tb.length;i++)tb[i].classList.toggle('sel',tb[i].getAttribute('data-s')===s);}
(function(){var tb=tray.querySelectorAll('.ttab');for(var i=0;i<tb.length;i++)(function(n){n.addEventListener('click',function(){showTab(n.getAttribute('data-s'));});})(tb[i]);})();
function selectType(t){placeSaved=null;placeType=t;paintIcon('pbIcon',t);var its=tray.querySelectorAll('.titem');
  for(var i=0;i<its.length;i++)its[i].classList.toggle('sel',its[i].getAttribute('data-t')===t);closeAll();}
(function(){var its=tray.querySelectorAll('.titem');for(var i=0;i<its.length;i++)(function(n){n.addEventListener('click',function(){selectType(n.getAttribute('data-t'));});})(its[i]);})();
/* ---- Сохранённые тела: настроенную планету/звезду/дыру можно сохранить и потом ставить сколько угодно раз ---- */
var SAVED=[],placeSaved=null,SV_KEY='ssb_saved_v1';
function loadSaved(){try{var s=localStorage.getItem(SV_KEY);SAVED=s?JSON.parse(s):[];if(!Array.isArray(SAVED))SAVED=[];}catch(e){SAVED=[];}
  /* планеты из папки objects/my_planets (файлы) идут первыми; в localStorage они не пишутся */
  var fl=[],i;for(i=0;i<MY_PLANETS.length;i++){var f=jclone(MY_PLANETS[i]);f.file=true;f.id=f.id||('file_'+i);fl.push(f);}
  SAVED=fl.concat(SAVED);}
function storeSaved(){try{localStorage.setItem(SV_KEY,JSON.stringify(SAVED.filter(function(s){return !s.file;})));}catch(e){}}
function jclone(o){return JSON.parse(JSON.stringify(o));}
function snapBody(b){var s={id:Date.now().toString(36)+Math.floor(Math.random()*46656).toString(36),kind:b.kind,name:(b.name&&b.name.trim())||b.defName};
  if(b.star){s.m=b.m;if(!b.bh)s.T=b.T;return s;}
  s.sz=b.sz;s.mapId=b.mapId|0;s.tilt=b.tilt;s.spin=b.spin;s.ring=b.ring|0;s.aq=b.aq;s.atmo=jclone(b.atmo0||{});s.water=jclone(b.water||{});
  if(b.rbands)s.rbands=jclone(b.rbands);if(b.kind==='gas'&&b.bands)s.bands=jclone(b.bands);return s;}
function applySnap(b,s){if(s.name)b.name=s.name;
  if(b.bh){bhSetMass(b,s.m/SUNM);return;}
  if(b.star){starSetMass(b,s.m/SUNM);if(s.T)starSetT(b,s.T);return;}
  setSize(b,s.sz);b.tilt=s.tilt;b.spin=s.spin;b.mapId=s.mapId|0;
  if(b.kind==='gas'){applyGas(b);if(s.bands){b.bands=jclone(s.bands);gasBands(b);}}else if(b.kind==='super')applySuper(b);else{b.mesh.material=getLow(b.mapId);b.hi=false;setLandSeed(b);}
  b.atmo0=jclone(s.atmo||{});b.water=jclone(s.water||{});if(s.aq!=null)b.aq=s.aq;
  if(s.rbands)b.rbands=jclone(s.rbands);ringSet(b,s.ring|0);releaseMaps();recompute(b);}
function plSpec(){var s=placeSaved,k=placeType;
  if(s&&s.sz!=null){var z3=s.sz*s.sz*s.sz;return {m:KM[k]*z3,M:MDEF[k]*z3,r:KR[k]*s.sz};}
  if(s&&s.m)return {m:s.m,M:MDEF[k],r:k==='bh'?bhRad(s.m/SUNM):KR[k]};
  return {m:KM[k],M:MDEF[k],r:KR[k]};}
function svIcon(s){var c=document.createElement('canvas');c.width=c.height=128;var g=c.getContext('2d'),src=s.kind==='gas'?gasIcon(s.mapId|0):ICON[s.kind==='super'?'super':s.kind];if(src)g.drawImage(src,0,0,128,128);return c;}
function renderSaved(){var row=tray.querySelector('.trow[data-s="saved"]');if(!row)return;row.innerHTML='';
  if(!SAVED.length){var e=document.createElement('div');e.className='tempty';e.textContent='Пусто. Настрой тело, открой его окно и нажми 💾 вверху';row.appendChild(e);return;}
  SAVED.forEach(function(s){var it=document.createElement('div');it.className='titem';it.setAttribute('data-sv',s.id);if(placeSaved&&placeSaved.id===s.id)it.classList.add('sel');
    it.appendChild(svIcon(s));var sp=document.createElement('span');sp.textContent=s.name;it.appendChild(sp);
    var x=document.createElement('button');x.className='svx';x.textContent='✕';x.setAttribute('aria-label','Удалить');it.appendChild(x);
    x.addEventListener('click',function(ev){ev.stopPropagation();delSaved(s.id);});
    it.addEventListener('click',function(){selectSaved(s.id);});row.appendChild(it);});}
function selectSaved(id){var s=null,i;for(i=0;i<SAVED.length;i++)if(SAVED[i].id===id)s=SAVED[i];if(!s)return;selectType(s.kind);placeSaved=s;renderSaved();}
function delSaved(id){SAVED=SAVED.filter(function(s){return s.id!==id;});storeSaved();if(placeSaved&&placeSaved.id===id)placeSaved=null;renderSaved();}
function saveBody(b){SAVED.push(snapBody(b));var own=SAVED.filter(function(s){return !s.file;});if(own.length>60)SAVED.splice(SAVED.indexOf(own[0]),1);storeSaved();renderSaved();}
(function(){var bt=$('infoSave');bt.addEventListener('click',function(){var b=infoBody;if(!b||bodies.indexOf(b)<0)return;saveBody(b);bt.textContent='✔';setTimeout(function(){bt.textContent='💾';},1300);});})();
/* кнопка тела: тап — ставить, удержание — выдвинуть список */
var holdT=0,holdFired=false,pbDown=false;
pbtn.addEventListener('pointerdown',function(e){e.preventDefault();try{pbtn.setPointerCapture(e.pointerId);}catch(_){}
  pbDown=true;holdFired=false;pbtn.classList.add('holding');clearTimeout(holdT);
  holdT=setTimeout(function(){holdFired=true;pbtn.classList.remove('holding');closeAll();showTab(placeSaved?'saved':placeType==='bh'?'holes':isStarT(placeType)?'stars':'planets');tray.classList.add('open');try{if(navigator.vibrate)navigator.vibrate(15);}catch(_){}},380);});
function pbEnd(e,ok){if(!pbDown)return;pbDown=false;clearTimeout(holdT);pbtn.classList.remove('holding');if(!ok)return;
  if(holdFired){var t=document.elementFromPoint(e.clientX,e.clientY),it=t&&t.closest&&t.closest('.titem');if(it){var sv_=it.getAttribute('data-sv');if(sv_)selectSaved(sv_);else selectType(it.getAttribute('data-t'));}var tbn=t&&t.closest&&t.closest('.ttab');if(tbn)showTab(tbn.getAttribute('data-s'));return;}
  var r=pbtn.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)return;
  if(tray.classList.contains('open')){closeAll();return;}
  if(mode==='placing'){endDrag();setMode('idle');}else setMode('placing');}
pbtn.addEventListener('pointerup',function(e){pbEnd(e,true);});
pbtn.addEventListener('pointercancel',function(e){pbEnd(e,false);});
pbtn.addEventListener('contextmenu',function(e){e.preventDefault();});

$('bMenu').addEventListener('click',function(){togglePop('popMenu');});
/* ---- Настройки: отображение орбит и режим фонарика ---- */
var showOrbits=true,flashOn=false,flashLight=new THREE.DirectionalLight(0xffffff,0);scene.add(flashLight);scene.add(flashLight.target);
function viewUpd(){var i,b,k,ms;
  for(i=0;i<bodies.length;i++){b=bodies[i];if(b.trail)b.trail.line.visible=showOrbits;}
  if(!showOrbits)orbLine.visible=false;
  flashLight.intensity=flashOn?1.7:0;if(!flashOn)return;
  flashLight.position.copy(camera.position);flashLight.target.position.set(cx,cy,cz);
  for(i=0;i<bodies.length;i++){b=bodies[i];if(b.star||b.bh)continue;
    var dx=camera.position.x-b.x,dy=camera.position.y-b.y,dz=camera.position.z-b.z,l=Math.sqrt(dx*dx+dy*dy+dz*dz)||1;
    ms=[b.snowMat,b.ringMat,b.gasMat,b.cloudMat,b.vegMat,b.waterMat,b.lavaMat];
    for(k=0;k<ms.length;k++){var m=ms[k];if(m&&m.uniforms&&m.uniforms.uL){m.uniforms.uL.value.set(dx/l,dy/l,dz/l);if(m.uniforms.uK)m.uniforms.uK.value=1;}}}}
function tgl(id,fn){var el=$(id);el.addEventListener('click',function(){var on=!el.classList.contains('on');el.classList.toggle('on',on);el.querySelector('i').textContent=on?'Вкл':'Выкл';fn(on);});}
tgl('setOrb',function(on){showOrbits=on;});tgl('setFlash',function(on){flashOn=on;});
$('actSet').addEventListener('click',function(){togglePop('popSet');});
$('mmSet').addEventListener('click',function(){togglePop('popSet');});
/* ---- Книжка: список всех объектов и их названий ---- */
var bookArr=[];
function bookIcon(b){var c=document.createElement('canvas'),S=64,g;c.width=c.height=S;g=c.getContext('2d');
  var src=b.kind==='bh'?ICON.bh:b.kind==='dwarf'?ICON.dwarf:b.kind==='gas'?gasIcon(b.mapId|0):ICON[b.kind==='super'?'super':b.star?'star':'planet'];g.drawImage(src,0,0,S,S);
  if(b.kind==='planet'){var t=RMAP[b.mapId|0].low;g.globalCompositeOperation='multiply';g.fillStyle='rgb('+Math.round(Math.min(1,t[0])*255)+','+Math.round(Math.min(1,t[1])*255)+','+Math.round(Math.min(1,t[2])*255)+')';g.fillRect(0,0,S,S);
    g.globalCompositeOperation='destination-in';g.drawImage(src,0,0,S,S);g.globalCompositeOperation='source-over';}
  return c;}
function buildBook(){var L=$('bookList'),i,n=0,sn=0,b;L.textContent='';bookArr=[];
  for(i=0;i<bodies.length;i++){b=bodies[i];bookArr.push(b);}
  $('bookHead').textContent='📖 Объекты · '+bookArr.length;
  if(!bookArr.length){var e=document.createElement('div');e.className='bkE';e.textContent='Пока ничего не поставлено';L.appendChild(e);return;}
  for(i=0;i<bookArr.length;i++){b=bookArr[i];
    var nm,sub;
    if(b.bh){nm=(b.name&&b.name.trim())||b.defName;sub='Чёрная дыра · масса ×'+bhMs(b)+' M☉';}
    else if(b.star){nm=(b.name&&b.name.trim())||b.defName;sub=starClass(b).name+' · '+Math.round(b.T)+' K · '+(b.m/SUNM>=1.005||b.m/SUNM<=.995?'масса ×'+String(+(b.m/SUNM).toFixed(2)).replace('.',','):'масса ×1');}
    else{nm=(b.name&&b.name.trim())||b.defName;
      sub=(b.kind==='super'?'Супер-Земля':b.kind==='gas'?'Газовый гигант':'Каменная планета')+(isNaN(b.tAvg)?'':' · '+String(Math.round(b.tAvg-273.15)).replace('-','−')+' °C')+(b.host&&bodies.indexOf(b.host)>=0?' · спутник «'+((b.host.name&&b.host.name.trim())||b.host.defName)+'»':'');}
    var btn=document.createElement('button'),ib=bookIcon(b),dv=document.createElement('div'),st=document.createElement('strong'),sm=document.createElement('small');
    btn.className='bk';btn.setAttribute('data-i',i);st.textContent=nm;sm.textContent=sub;
    dv.appendChild(st);dv.appendChild(sm);btn.appendChild(ib);btn.appendChild(dv);L.appendChild(btn);}}
$('bBook').addEventListener('click',function(){var on=$('popBook').classList.contains('show');if(!on)buildBook();togglePop('popBook');});
$('popBook').addEventListener('click',function(e){var t=e.target.closest?e.target.closest('.bk'):null;if(!t)return;var b=bookArr[+t.getAttribute('data-i')];
  if(!b||bodies.indexOf(b)<0)return;follow=b;tDist=b.star?b.r*6.7:Math.max(.3,b.r*12);closeAll();});
$('bClock').addEventListener('click',function(){togglePop('popClock');});
$('bEye').addEventListener('click',function(){showZones=!showZones;this.classList.toggle('on',showZones);});
var bLock=$('bLock');
function lockUI(){var v=!!follow;if(!v&&camLock)camLock=false;if(bLock._v!==v){bLock._v=v;bLock.classList.toggle('vis',v);}if(bLock._l!==camLock){bLock._l=camLock;bLock.classList.toggle('on',camLock);}}
bLock.addEventListener('click',function(){if(follow){camLock=!camLock;lockUI();}});
$('actCam').addEventListener('click',function(){tYaw=.35;tPitch=.6;tDist=62;tcx=tcz=0;follow=null;closeAll();});
$('actClear').addEventListener('click',function(){endDrag();bodies.slice().forEach(function(b){removeBody(b);});chClear();merges.length=0;CNT={};follow=null;setMode('idle');});
document.addEventListener('pointerdown',function(e){if(!e.target.closest('#tray,.pop,.rb,#pbtn'))closeAll();},true);

var sl=$('sl'),sv=$('sv'),pzB=$('actPause');
var TS=1;
function setSp(){var sp=parseFloat(sl.value),v=sp<=50?sp*.1:5+(sp-50)*.9;v=Math.round(v*10)/10;/* 0–5× с шагом 0,1; 5–50× быстрее */TS=v;SPEED=paused?0:v*2;sv.textContent=(v%1?v.toFixed(1):v)+'×';}
sl.addEventListener('input',setSp);
pzB.addEventListener('click',function(){paused=!paused;pzB.textContent=paused?'▶ Продолжить':'⏸ Пауза';$('bClock').classList.toggle('warn',paused);setSp();});

var menuOn=true,mm=$('mainMenu');
function setPauseTo(p){if(paused!==p)pzB.click();}
function showMenu(on){menuOn=on;mm.style.display=on?'flex':'none';}
$('mmPlay').addEventListener('click',function(){showMenu(false);setPauseTo(false);});
$('mmEdit').addEventListener('click',function(){showMenu(false);setPauseTo(true);edOpen();});
$('actMenu').addEventListener('click',function(){closeAll();showMenu(true);setPauseTo(true);});
setPauseTo(true);
setSp();setMode('idle');

/* ---- Информация о планете: двойной тап, редактирование состава ---- */
var CNT={},infoBody=null,lastTap={b:null,t:0},infoEls={};
var GASES=[['N2','N₂','Азот'],['O2','O₂','Кислород'],['Ar','Ar','Аргон'],['CO2','CO₂','Углекислый газ'],['Ne','Ne','Неон'],['He','He','Гелий'],['H2','H₂','Водород'],['CH4','CH₄','Метан'],['H2O','H₂O','Водяной пар'],['NH3','NH₃','Аммиак'],['SO2','SO₂','Диоксид серы'],['CO','CO','Угарный газ'],['H2S','H₂S','Сероводород'],['O3','O₃','Озон'],['N2O','N₂O','Закись азота'],['Kr','Kr','Криптон'],['Xe','Xe','Ксенон']];
var LIQ=[['H2O','H₂O','Вода'],['NaCl','NaCl','Хлорид натрия'],['MgCl2','MgCl₂','Хлорид магния'],['MgSO4','MgSO₄','Сульфат магния'],['CaSO4','CaSO₄','Сульфат кальция'],['KCl','KCl','Хлорид калия'],['NaHCO3','NaHCO₃','Гидрокарбонат натрия'],['CO2','CO₂','Растворённый CO₂'],['NH3','NH₃','Аммиак'],['CH4','CH₄','Метан (жидкий)'],['C2H6','C₂H₆','Этан (жидкий)'],['H2SO4','H₂SO₄','Серная кислота']];
/* каменная планета: нет атмосферы и воды — везде 0% */
var ATMO={gas:{},planet:{},super:{N2:78.077,O2:20.95,Ar:.93,CO2:.04,Ne:.0018,He:.0005,CH4:.0002,Kr:.0001}};
var WATER={gas:{},planet:{},super:{H2O:96.51,NaCl:2.72,MgCl2:.38,MgSO4:.17,CaSO4:.13,KCl:.07,NaHCO3:.02}};
/* газ: [вес/плотность, r,g,b] — задаёт цвет и густоту атмосферы */
var GINFO={N2:[1,.25,.6,1],O2:[1,.25,.6,1],Ar:[.5,.7,.55,1],CO2:[1.6,1,.6,.25],Ne:[.5,1,.45,.3],He:[.3,.9,.85,1],H2:[.5,.6,.75,1],CH4:[1.4,.1,.8,.85],H2O:[1.2,.85,.92,1],NH3:[1.3,.95,.9,.7],SO2:[1.6,1,.85,.2],CO:[.4,.7,.5,.4],H2S:[1.2,.8,.9,.2],O3:[.8,.4,.45,1],N2O:[.3,.7,.9,.8],Kr:[.3,.9,.9,.5],Xe:[.3,.6,.5,1]};
/* жидкость: [сила окраски, r,g,b] — задаёт цвет океана */
var LINFO={H2O:[0,0,0,0],NaCl:[0,0,0,0],MgCl2:[0,0,0,0],MgSO4:[0,0,0,0],CaSO4:[.12,.45,.82,.8],KCl:[0,0,0,0],NaHCO3:[.12,.4,.8,.7],CO2:[.15,.55,.8,.9],NH3:[1,.7,.85,.5],CH4:[1,.15,.1,.06],C2H6:[1,.22,.15,.08],H2SO4:[1,.85,.78,.25]};
var SOLV={H2O:1,NH3:1,CH4:1,C2H6:1,H2SO4:1};/* растворители: океан есть, если их суммарно ≥1% */
function fmtN(v){if(!v)return '0';var s=v>=1?v.toFixed(2):v>=.01?v.toFixed(3):v.toFixed(4);return s.replace(/\.?0+$/,'').replace('.',',');}
/* задать долю одного вещества: остальные пересчитываются, сумма = 100% */
function setShare(comp,list,key,v){var i,k,o=0;v=Math.max(0,Math.min(100,v));
  for(i=0;i<list.length;i++){k=list[i][0];if(k!==key)o+=comp[k]||0;}
  if(o<=1e-9){for(i=0;i<list.length;i++)comp[list[i][0]]=0;comp[key]=v>0?100:0;return;}
  var f=(100-v)/o;for(i=0;i<list.length;i++){k=list[i][0];if(k!==key)comp[k]=(comp[k]||0)*f;}comp[key]=v;}
/* из состава — в параметры внешнего вида и экосистемы */
function recompute(b){var i,k,v,w,S=0,sum=0,r=0,g=0,bl=0,liq=0,ts=0,tr=0,tg=0,tb=0,fa=1-b.lava;
  for(i=0;i<GASES.length;i++){k=GASES[i][0];v=b.atmo0[k]||0;sum+=v;var gi=GINFO[k];w=v*gi[0];S+=w;r+=w*gi[1];g+=w*gi[2];bl+=w*gi[3];b.atmo[k]=v*fa;}
  b.atmOn=sum>.0001&&b.aq>.02;
  if(b.atmOn&&S>0){b.atmCol=[r/S,g/S,bl/S];b.atmDens=Math.max(.15,Math.min(1.8,S/100));}else{b.atmCol=b.atmCol||[.25,.6,1];b.atmDens=b.atmDens||1;}
  for(i=0;i<LIQ.length;i++){k=LIQ[i][0];v=b.water[k]||0;if(SOLV[k])liq+=v;var li=LINFO[k];w=v*li[0];ts+=w;tr+=w*li[1];tg+=w*li[2];tb+=w*li[3];}
  b.h2o=b.water.H2O||0;b.hasOcean=liq>=1;b.ocShift=Math.min(1,ts/100);b.ocCol=ts>0?[tr/ts,tg/ts,tb/ts]:[.1,.35,.7];if(b.kind==='gas'&&b.atmOn)b.atmCol=GPAR[b.mapId|0].hz;}
function rows(list,data,pf){var h='';for(var i=0;i<list.length;i++){var v=data[list[i][0]]||0;h+='<div class="ir" style="--p:'+Math.min(100,v)+'%"><b>'+list[i][1]+'</b><span>'+list[i][2]+'</span><button class="sb" tabindex="-1" data-k="'+pf+list[i][0]+'" data-d="-1">−</button><input class="iv" type="text" inputmode="decimal" enterkeyhint="done" autocomplete="off" autocapitalize="off" spellcheck="false" data-k="'+pf+list[i][0]+'" value="'+fmtN(v)+'"><button class="sb" tabindex="-1" data-k="'+pf+list[i][0]+'" data-d="1">+</button></div>';}return h;}
function ecoText(b){var t='',L=function(x){t+=(t?'<br>':'')+x;};
  if((b.rad||0)>.12)L('☢ Вспышки красного карлика: радиация '+Math.round(b.rad*100)+'% — жизнь не может зародиться');
  if(b.veg>.005||b.kind==='super'){var q='🌿 Растительность '+Math.round(b.veg*100)+'%';if(b.kind==='super')q+=' · суша высохла на '+Math.round(b.dry*100)+'%';L(q);}
  if(b.oc>.005||b.hasOcean)L('🌊 Океан '+Math.round(b.oc*100)+'%');
  if(b.evap>0&&b.wq>.002)L('♨ Вода испаряется, осталось '+Math.round(b.wq*100)+'%');
  else if(b.hasOcean&&b.wq<=.02)L('🏜 Океаны полностью испарились');
  if(b.M<thM(b)){if(b.losing)L('🧲 Магнитного поля нет, атмосферу сдувает. Осталось '+Math.round(b.aq*100)+'%');else if(b.lostAtm)L('💨 Атмосфера потеряна');}
  return t;}
function setRow(el,v,locked,act){var row=el.parentNode,s=fmtN(v);if(el!==act&&el._t!==s){el._t=s;el.value=s;}
  var p=Math.min(100,v)+'%';if(row._p!==p){row._p=p;row.style.setProperty('--p',p);}if(el.readOnly!==locked)el.readOnly=locked;if(row._l!==locked){row._l=locked;row.classList.toggle('lk',locked);}}
function massRow(el,b,act){var row=el.parentNode,J=b.M>=MJ*.999999,u=J?'J':'E',m=fmtN(J?b.M/MJ:b.M);
  if(el._u!==u){el._u=u;var lb=$('mLbl');if(lb)lb.textContent=J?'Масса, M♃':'Масса, M⊕';el._t=null;}
  if(el!==act&&el._t!==m){el._t=m;el.value=m;}
  var p=Math.max(0,Math.min(100,b.kind==='gas'?Math.log(b.M/8)/Math.log(1100)*100:Math.log(b.M/.001)/Math.log(300000)*100)).toFixed(1)+'%';if(row._p!==p){row._p=p;row.style.setProperty('--p',p);}}
function refreshInfo(b){if(b.bh){bhRefresh(b);return;}if(b.star){starRefresh(b);return;}var i,k,el,act=document.activeElement,locked=b.lava>.01;
  var tE=$('vTemp'),lE=$('vLife'),mE=infoEls.mM;
  if(tE){var tx=isNaN(b.tAvg)?'…':(Math.round(b.tAvg-273.15)+' °C').replace('-','−');if(tE._t!==tx){tE._t=tx;tE.textContent=tx;}}
  if(lE){var lp=lifeProb(b)*100,lx=lp<1?(lp>0?'<1%':'0%'):Math.round(lp)+'%';if(lE._t!==lx){lE._t=lx;lE.textContent=lx;lE.parentNode.style.setProperty('--p',Math.round(lp)+'%');}}
  var rR=$('rRad');if(rR){var anyD=bodies.some(function(q){return q.kind==='dwarf';});rR.style.display=anyD?'':'none';if(anyD){var rp=Math.round((b.rad||0)*100),rx=rp+'%',vR=$('vRad');if(vR._t!==rx){vR._t=rx;vR.textContent=rx;rR.style.setProperty('--p',rp+'%');}}}
  if(mE)massRow(mE,b,act);
  orbRefresh(b,act);
  var eT=infoEls.tI,eS=infoEls.tS,s_;if(eT&&eT!==act){s_=fmtO(b.tilt,1);if(eT._t!==s_){eT._t=s_;eT.value=s_;}}if(eS&&eS!==act){s_=fmtO(b.spin*30/Math.PI,1);if(eS._t!==s_){eS._t=s_;eS.value=s_;}}
  var zE=$('szSl'),zV=$('vSize');
  if(zE&&!szDrag&&document.activeElement!==zE){var zp=Math.round(Math.log(b.sz/ZMIN)/Math.LN10*1000);if(+zE.value!==zp)zE.value=zp;}
  if(zV){var zt=String(Math.round(RKM[b.kind]*b.sz)).replace(/\B(?=(\d{3})+(?!\d))/g,' ')+' км';if(zV._t!==zt){zV._t=zt;zV.textContent=zt;}}
  for(i=0;i<GASES.length;i++){k=GASES[i][0];el=infoEls['a'+k];if(el)setRow(el,b.atmo[k]||0,locked,act);}
  for(i=0;i<LIQ.length;i++){k=LIQ[i][0];el=infoEls['w'+k];if(el)setRow(el,b.water[k]||0,false,act);}
  var e=ecoText(b),en=$('infoEco');if(en&&en._t!==e){en._t=e;en.innerHTML=e;}}
function typeText(b){var g=b.kind==='gas',L=g?GPAR:b.kind==='super'?SPAR:RMAP;return (g?'Газовый гигант':b.kind==='super'?'Супер-Земля':'Каменная планета')+' · карта: '+L[b.mapId|0].name+' ('+((b.mapId|0)+1)+'/'+L.length+')';}
var mapBusy=false;
function changeMap(b){if(mapBusy)return;mapBusy=true;var btn=$('mapBtn');if(btn){btn.disabled=true;btn.textContent='Генерация карты…';}
  setTimeout(function(){if(bodies.indexOf(b)<0){mapBusy=false;return;}
    var n=((b.mapId|0)+1)%(b.kind==='gas'?GPAR.length:b.kind==='super'?SPAR.length:RMAP.length);b.mapId=n;
    if(b.kind==='gas'){applyGas(b);recompute(b);if(infoBody===b)bandsRedo(b,'bands');}else if(b.kind==='super')applySuper(b);else{b.mesh.material=getLow(n);b.hi=false;setLandSeed(b);}
    releaseMaps();mapBusy=false;
    if(infoBody===b){var bt=$('mapBtn');if(bt){bt.disabled=false;bt.textContent='Сменить карту поверхности';}$('infoType').textContent=typeText(b);}},40);}
function openInfo(b){closeAll();infoBody=b;
  if(b.bh){openBH(b);return;}
  if(b.star){openStar(b);return;}
  $('infoName').value=b.name;$('infoType').textContent=typeText(b);
  $('infoScroll').innerHTML='<div class="ih"><span>Показатели</span></div>'+
    '<div class="ir" id="rTemp"><b>🌡</b><span>Ср. температура</span><i id="vTemp"></i></div>'+
    '<div class="ir" id="rMass"><b>⚖</b><span id="mLbl">Масса, M⊕</span><button class="sb" tabindex="-1" data-k="mM" data-d="-1">−</button><input class="iv" type="text" inputmode="decimal" enterkeyhint="done" autocomplete="off" autocapitalize="off" spellcheck="false" data-k="mM" value=""><button class="sb" tabindex="-1" data-k="mM" data-d="1">+</button></div>'+
    '<div class="ir" id="rSize" style="--p:0%"><b>📏</b><span style="flex:none">Размер</span><input id="szSl" type="range" min="0" max="1000" step="1" value="500"><i id="vSize"></i></div>'+
    ivRow('🧭','Наклон оси, °','tI')+ivRow('🌀','Вращение, об/мин','tS')+(b.kind==='gas'?'':'<div class="ir" id="rLife"><b>🧬</b><span>Вероятность жизни</span><i id="vLife"></i></div><div class="ir" id="rRad" style="display:none"><b>☢</b><span>Радиация вспышек</span><i id="vRad"></i></div>')+
    '<div class="nt" id="infoEco"></div>'+
    '<div class="ih"><span>Орбита</span></div>'+
    '<div class="ir"><b>📐</b><span>Наклон орбиты, °</span><button class="sb" tabindex="-1" data-k="oI" data-d="-1">−</button><input class="iv" type="text" inputmode="decimal" enterkeyhint="done" autocomplete="off" autocapitalize="off" spellcheck="false" data-k="oI" value=""><button class="sb" tabindex="-1" data-k="oI" data-d="1">+</button></div>'+
    '<div class="ir"><b>↔</b><span>Расстояние до звезды</span><button class="sb" tabindex="-1" data-k="oD" data-d="-1">−</button><input class="iv" type="text" inputmode="decimal" enterkeyhint="done" autocomplete="off" autocapitalize="off" spellcheck="false" data-k="oD" value=""><button class="sb" tabindex="-1" data-k="oD" data-d="1">+</button></div>'+
    '<div class="ir"><b>🚀</b><span>Скорость, % круговой</span><button class="sb" tabindex="-1" data-k="oV" data-d="-1">−</button><input class="iv" type="text" inputmode="decimal" enterkeyhint="done" autocomplete="off" autocapitalize="off" spellcheck="false" data-k="oV" value=""><button class="sb" tabindex="-1" data-k="oV" data-d="1">+</button></div>'+
    '<div class="ir"><b>⭕</b><span>Эксцентриситет</span><i id="vOe"></i></div>'+
    '<div class="ir"><b>⬇</b><span>Ближайшая точка</span><i id="vOp"></i></div>'+
    '<div class="ir"><b>⬆</b><span>Дальняя точка</span><i id="vOa"></i></div>'+
    '<div class="ir"><b>⏱</b><span>Год (при 1×)</span><i id="vOt"></i></div>'+
    '<div class="nt" id="infoOrb"></div>'+
    ringHTML(b)+(b.kind==='gas'?bandsHTML(b,'bands'):'<div class="ih"><span>Атмосфера</span><button class="zb" data-z="a">Обнулить</button></div>'+rows(GASES,b.atmo,'a'))+
    (b.kind==='gas'?'':'<div class="ih"><span>Вода</span><button class="zb" data-z="w">Обнулить</button></div>'+rows(LIQ,b.water,'w'))+'<button class="mb" id="moonBtn"'+(moonOK(b)?'':' disabled')+'>🌙 Создать спутник</button><button class="mb" id="mapBtn">Сменить карту поверхности</button>';
  infoEls={};var els=$('infoScroll').querySelectorAll('.iv');for(var i=0;i<els.length;i++)infoEls[els[i].getAttribute('data-k')]=els[i];
  var mbn=$('moonBtn');if(mbn)mbn.addEventListener('click',function(){startMoon(b);});refreshInfo(b);$('infoScroll').scrollTop=0;$('popInfo').classList.add('show');document.body.classList.add('info');}
function closeInfo(){stopHold();var ae=document.activeElement;if(ae&&ae.closest&&ae.closest('#popInfo'))ae.blur();
  if(infoBody&&!infoBody.name.trim())infoBody.name=infoBody.defName;infoBody=null;$('popInfo').classList.remove('show');document.body.classList.remove('info');}
function commitEdit(el){var b=infoBody;if(!b)return;var dk=el.getAttribute('data-k'),kind=dk.charAt(0),key=dk.slice(1),
    v=parseFloat(String(el.value).replace(',','.').replace('%','')),comp=kind==='a'?b.atmo0:b.water,list=kind==='a'?GASES:LIQ;
  if(kind==='b'){if(!isNaN(v))bhSetMass(b,v);el._t=null;refreshInfo(b);return;}
  if(kind==='s'){if(!isNaN(v)){if(key==='M')starSetMass(b,v);else starSetT(b,v);}el._t=null;refreshInfo(b);return;}
  if(kind==='t'){if(!isNaN(v)){if(key==='I')b.tilt=Math.max(0,Math.min(180,v));else b.spin=Math.max(-60,Math.min(60,v))*Math.PI/30;}el._t=null;refreshInfo(b);return;}
  if(kind==='o'){if(!isNaN(v))orbSet(b,key,v);el._t=null;refreshInfo(b);return;}
  if(kind==='m'){if(!isNaN(v))setMass(b,el._u==='J'?v*MJ:v);var s0=fmtN(el._u==='J'?b.M/MJ:b.M);el.value=s0;el._t=s0;refreshInfo(b);return;}
  if(!isNaN(v)&&!(kind==='a'&&b.lava>.01)){var we=kind==='a'&&atmoEmpty(b);setShare(comp,list,key,v);if(kind==='a'&&(we||b.aq<.02))b.aq=1;if(kind==='w'&&b.wq<.02)b.wq=1;recompute(b);}
  var s=fmtN(kind==='a'?(b.atmo[key]||0):(b.water[key]||0));el.value=s;el._t=s;refreshInfo(b);}
var infoSc=$('infoScroll');
infoSc.addEventListener('change',function(e){if(e.target.classList&&e.target.classList.contains('iv'))commitEdit(e.target);});
infoSc.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.classList&&e.target.classList.contains('iv'))e.target.blur();});
infoSc.addEventListener('focusin',function(e){var t=e.target;if(t.classList&&t.classList.contains('iv')){setTimeout(function(){try{t.scrollIntoView({block:'nearest'});}catch(_){}},350);}});
infoSc.addEventListener('click',function(e){var t=e.target;if(infoBody&&t.id==='mapBtn'){changeMap(infoBody);return;}if(!infoBody||!t.classList||!t.classList.contains('zb'))return;
  var b=infoBody,kind=t.getAttribute('data-z'),comp=kind==='a'?b.atmo0:b.water,list=kind==='a'?GASES:LIQ;
  if(kind==='a'&&b.lava>.01)return;for(var i=0;i<list.length;i++)comp[list[i][0]]=0;recompute(b);refreshInfo(b);});
/* ---- Редактор полос (полосы газового гиганта и газовые кольца): новая строка = новая полоса, газ задаёт цвет ---- */
function gasOpts(sel){var h='',k;for(k in GASB)h+='<option value="'+k+'"'+(k===sel?' selected':'')+'>'+GASB[k][0]+' · '+GASB[k][1]+'</option>';return h;}
function bandSum(b,key){var s=0,i;for(i=0;i<b[key].length;i++)s+=b[key][i].w;return s;}
function bandsHTML(b,key){var B=b[key],sum=bandSum(b,key),i,h='<div class="ih"><span>'+(key==='bands'?'Полосы':'Полосы колец')+'</span></div><div id="gbList_'+key+'">';
  for(i=0;i<B.length;i++){var p=B[i].w/sum*100;h+='<div class="ir gbr" data-s="'+key+'" data-i="'+i+'" style="--p:'+p+'%"><em class="sw" style="background:'+gcss(B[i].g)+'"></em><select class="gs">'+gasOpts(B[i].g)+'</select><button class="gx" data-a="m">−</button><input class="bw" type="text" inputmode="decimal" enterkeyhint="done" autocomplete="off" value="'+fmtN(+p.toFixed(1))+'"><button class="gx" data-a="p">+</button><button class="gx" data-a="d">✕</button></div>';}
  return h+'</div><button class="mb" data-add="'+key+'">＋ Добавить полосу</button>';}
function bandsApply(b,key){if(key==='bands')gasBands(b);else ringUpd(b);}
function bandsRedo(b,key){var l=$('gbList_'+key);if(l){var d=document.createElement('div');d.innerHTML=bandsHTML(b,key);l.innerHTML=d.querySelector('#gbList_'+key).innerHTML;}bandsApply(b,key);}
function bandShare(b,key,i,v){var rest=bandSum(b,key)-b[key][i].w;if(rest<=0)return;v=Math.max(1,Math.min(95,v));b[key][i].w=v/(100-v)*rest;}
function ringInner(b){var o='',i,N=['Нет','Ледяные','Каменные','Пылевые','Тонкие','Газовые'];for(i=0;i<6;i++)o+='<option value="'+i+'"'+(b.ring===i?' selected':'')+'>'+N[i]+'</option>';
  return '<div class="ih"><span>Кольца</span></div><div class="ir"><b>💍</b><select id="ringSel" class="gs">'+o+'</select></div>'+(b.ring===5?bandsHTML(b,'rbands'):'');}
function ringHTML(b){return '<div id="ringBox">'+ringInner(b)+'</div>';}
function ivRow(ic,lb,k){return '<div class="ir"><b>'+ic+'</b><span>'+lb+'</span><button class="sb" tabindex="-1" data-k="'+k+'" data-d="-1">−</button><input class="iv" type="text" inputmode="decimal" enterkeyhint="done" autocomplete="off" autocapitalize="off" spellcheck="false" data-k="'+k+'" value=""><button class="sb" tabindex="-1" data-k="'+k+'" data-d="1">+</button></div>';}
infoSc.addEventListener('change',function(e){var b=infoBody,t=e.target;if(!b)return;
  if(t.id==='ringSel'){ringSet(b,+t.value);$('ringBox').innerHTML=ringInner(b);return;}
  var r=t.closest?t.closest('.gbr'):null;if(!r)return;var key=r.getAttribute('data-s'),i=+r.getAttribute('data-i');
  if(t.classList.contains('gs')){b[key][i].g=t.value;bandsApply(b,key);r.querySelector('.sw').style.background=gcss(t.value);}
  else if(t.classList.contains('bw')){var v=parseFloat(String(t.value).replace(',','.'));if(!isNaN(v))bandShare(b,key,i,v);bandsRedo(b,key);}});
infoSc.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.classList&&e.target.classList.contains('bw'))e.target.blur();});
infoSc.addEventListener('click',function(e){var b=infoBody,t=e.target;if(!b||!t.getAttribute)return;var ad=t.getAttribute('data-add');
  if(ad){if(b[ad].length<24){b[ad].push({g:'NH3',w:bandSum(b,ad)/b[ad].length});bandsRedo(b,ad);}return;}
  var a=t.getAttribute('data-a'),r=t.closest?t.closest('.gbr'):null;if(!a||!r)return;var key=r.getAttribute('data-s'),i=+r.getAttribute('data-i');
  if(a==='d'){if(b[key].length>1){b[key].splice(i,1);bandsRedo(b,key);}return;}
  bandShare(b,key,i,b[key][i].w/bandSum(b,key)*100+(a==='p'?1:-1));bandsRedo(b,key);});
$('infoName').addEventListener('input',function(){if(infoBody)infoBody.name=this.value;});
$('infoX').addEventListener('click',closeInfo);
infoSc.addEventListener('input',function(e){if(e.target.id==='szSl'&&infoBody){setSize(infoBody,ZMIN*Math.pow(10,e.target.value/1000));refreshInfo(infoBody);}});
infoSc.addEventListener('pointerdown',function(e){if(e.target.id==='szSl')szDrag=true;});
window.addEventListener('pointerup',function(){szDrag=false;});window.addEventListener('pointercancel',function(){szDrag=false;});
/* кнопки + / −: шаг 1%, при удержании повторяются */
var holdT=0,holdI=0;
function stopHold(){clearTimeout(holdT);clearInterval(holdI);holdT=holdI=0;}
function stepRow(dk,d){var b=infoBody;if(!b)return false;var kind=dk.charAt(0),key=dk.slice(1);if(kind==='a'&&b.lava>.01)return false;
  if(kind==='b'){var ob=b.m;bhSetMass(b,b.m/SUNM*(d>0?1.05:1/1.05));if(ob===b.m)return false;refreshInfo(b);return true;}
  if(kind==='s'){var o0=b.m+'|'+b.T;if(key==='M')starSetMass(b,b.m/SUNM*(d>0?1.04:1/1.04));else starSetT(b,b.T*(d>0?1.015:1/1.015));if(o0===b.m+'|'+b.T)return false;refreshInfo(b);return true;}
  if(kind==='t'){if(key==='I'){var ot=b.tilt;b.tilt=Math.max(0,Math.min(180,Math.round(ot*10)/10+d));if(b.tilt===ot)return false;}else{var os=b.spin;b.spin=Math.max(-6.2832,Math.min(6.2832,os+d*.05236));if(b.spin===os)return false;}refreshInfo(b);return true;}
  if(kind==='o')return orbStep(b,key,d);
  if(kind==='m'){var om=b.M;setMass(b,d>0?b.M*1.06:b.M/1.06);if(b.M===om)return false;refreshInfo(b);return true;}
  var comp=kind==='a'?b.atmo0:b.water,list=kind==='a'?GASES:LIQ,cur=comp[key]||0,nv=Math.max(0,Math.min(100,cur+d));
  if(nv===cur)return false;var we=kind==='a'&&atmoEmpty(b);setShare(comp,list,key,nv);if(kind==='a'&&(we||b.aq<.02))b.aq=1;if(kind==='w'&&b.wq<.02)b.wq=1;recompute(b);refreshInfo(b);return true;}
infoSc.addEventListener('pointerdown',function(e){var t=e.target;if(!t.classList||!t.classList.contains('sb'))return;e.preventDefault();
  var ae=document.activeElement;if(ae&&ae.classList&&ae.classList.contains('iv'))ae.blur();
  var dk=t.getAttribute('data-k'),d=+t.getAttribute('data-d');stopHold();
  if(!stepRow(dk,d))return;
  holdT=setTimeout(function(){holdI=setInterval(function(){if(!stepRow(dk,d))stopHold();},70);},380);});
window.addEventListener('pointerup',stopHold);window.addEventListener('pointercancel',stopHold);
infoSc.addEventListener('contextmenu',function(e){if(!(e.target.classList&&e.target.classList.contains('iv')))e.preventDefault();});
function tapBody(e){var b=pick(e),now=performance.now();
  if(b&&lastTap.b===b&&now-lastTap.t<450){lastTap.b=null;openInfo(b);}
  else{lastTap.b=b;lastTap.t=now;}}

/* ---- Камера и ввод ---- */
var yaw=0.35,pitch=0.6,dist=62,tYaw=yaw,tPitch=pitch,tDist=dist,ptrs={},lastPinch=0,cx=0,cz=0,cy=0,tcx=0,tcz=0,follow=null,tap=null,camLock=false;
var ray=new THREE.Raycaster(),ndc=new THREE.Vector2(),plane=new THREE.Plane(new THREE.Vector3(0,1,0),0);
function hit(e){var r=el.getBoundingClientRect();ndc.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);
  ray.setFromCamera(ndc,camera);var p=new THREE.Vector3();return ray.ray.intersectPlane(plane,p)?p:null;}
function freeSpot(x,z){var lim=SUN_R+KR[placeType];for(var i=0;i<bodies.length;i++)if(bodies[i].star&&Math.hypot(x-bodies[i].x,z-bodies[i].z)<lim-SUN_R+bodies[i].r)return false;return true;}
function endDrag(){pvReq=null;drag=null;ghost.visible=false;ghostM.visible=false;prevLine.visible=false;pullLine.visible=false;}
var locked=false;
el.addEventListener('pointerdown',function(e){
  if(!locked){locked=true;try{screen.orientation.lock('landscape').catch(function(){});}catch(_){}}
  el.setPointerCapture(e.pointerId);ptrs[e.pointerId]={x:e.clientX,y:e.clientY};lastPinch=0;tap=Object.keys(ptrs).length===1?{x:e.clientX,y:e.clientY,t:performance.now()}:null;
  if(mode==='moon'&&moonSt&&Object.keys(ptrs).length===1&&moonStart(e)){moonDrag={id:e.pointerId};moonAim(e);}
  if(mode==='placing'&&Object.keys(ptrs).length===1){var h=hit(e);
    if(h&&freeSpot(h.x,h.z)){drag={id:e.pointerId,ax:h.x,az:h.z,k:pullK(h.x,h.z),len:0,vx:0,vz:0};ghost.geometry=GEO[placeType];ghost.material=MAT[placeType];ghost.position.set(h.x,0,h.z);ghost.visible=true;ghostM.position.set(h.x,0,h.z);ghostM.visible=true;
      prevLine.visible=true;pullLine.visible=true;prevGeo.setDrawRange(0,0);pullArr.set([h.x,.05,h.z,h.x,.05,h.z]);pullGeo.attributes.position.needsUpdate=true;}}
});
function pick(e){var r=el.getBoundingClientRect(),best=null,bd=55,v=new THREE.Vector3();
  for(var i=0;i<bodies.length;i++){var b=bodies[i];v.set(b.x,b.y,b.z).project(camera);var sx=(v.x+1)/2*r.width+r.left,sy=(1-v.y)/2*r.height+r.top,d=Math.hypot(sx-e.clientX,sy-e.clientY);if(v.z<1&&d<bd){bd=d;best=b;}}
  if(best)follow=best;return best;}
function up(e){delete ptrs[e.pointerId];lastPinch=0;if(moonDrag&&moonDrag.id===e.pointerId)moonRelease();if(tap&&mode==='idle'&&e.type==='pointerup'&&Math.hypot(e.clientX-tap.x,e.clientY-tap.y)<10&&performance.now()-tap.t<400)tapBody(e);tap=null;
  if(drag&&drag.id===e.pointerId){if(true){var big=drag.len>1.5;addBody(placeType,drag.ax,drag.az,big?drag.vx:0,big?drag.vz:0);if(placeSaved)applySnap(bodies[bodies.length-1],placeSaved);setMode('idle');}endDrag();}}
el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
el.addEventListener('pointermove',function(e){var p=ptrs[e.pointerId];if(!p)return;
  if(moonDrag&&moonDrag.id===e.pointerId){moonAim(e);p.x=e.clientX;p.y=e.clientY;return;}
  if(drag&&drag.id===e.pointerId){var h=hit(e);if(!h)return;
    var px=drag.ax-h.x,pz=drag.az-h.z,l=Math.hypot(px,pz);if(l>60){px*=60/l;pz*=60/l;l=60;}
    drag.len=l;drag.vx=px*drag.k;drag.vz=pz*drag.k;
    pullArr.set([drag.ax,.05,drag.az,drag.ax-px,.05,drag.az-pz]);pullGeo.attributes.position.needsUpdate=true;
    if(l>1.5)pvReq=[drag.ax,drag.az,drag.vx,drag.vz];else{pvReq=null;prevGeo.setDrawRange(0,0);}
    p.x=e.clientX;p.y=e.clientY;return;}
  var ids=Object.keys(ptrs);
  if(ids.length===1){tYaw-=(e.clientX-p.x)*0.006;tPitch=Math.max(0.05,Math.min(1.45,tPitch+(e.clientY-p.y)*0.006));}
  else if(ids.length===2){if(!camLock)follow=null;var a=ptrs[ids[0]],b=ptrs[ids[1]],ox=(a.x+b.x)/2,oy=(a.y+b.y)/2;p.x=e.clientX;p.y=e.clientY;var d=Math.hypot(a.x-b.x,a.y-b.y),mdx=(a.x+b.x)/2-ox,mdy=(a.y+b.y)/2-oy,sc=2*dist*Math.tan(camera.fov*Math.PI/360)/el.clientHeight,sp=Math.max(Math.sin(pitch),.25);
    if(lastPinch){tcx-=(Math.cos(yaw)*mdx+Math.sin(yaw)*mdy/sp)*sc;tcz-=(-Math.sin(yaw)*mdx+Math.cos(yaw)*mdy/sp)*sc;}
    if(lastPinch)tDist=Math.max(.15,Math.min(1500,tDist*lastPinch/d));lastPinch=d;return;}
  p.x=e.clientX;p.y=e.clientY;});
el.addEventListener('wheel',function(e){e.preventDefault();tDist=Math.max(.15,Math.min(1500,tDist*(1+e.deltaY*0.001)));},{passive:false});
function resize(){var w=window.innerWidth,h=window.innerHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
window.addEventListener('resize',resize);resize();

/* ---- Гравитационная линза: сцена рисуется в текстуру, вокруг каждой чёрной дыры (до 4) изображение искривляется по уравнению
   точечной линзы β = θ − θE²/θ; тень (радиус ≈ 1,7 горизонта, 40% прозрачности) и тонкое фотонное кольцо рисует шейдер ---- */
var lensFail=false,lensRTo=null,lensScene=new THREE.Scene(),lensCam=new THREE.OrthographicCamera(-1,1,1,-1,0,1),_lv=new THREE.Vector3();
var lensMat=new THREE.ShaderMaterial({depthTest:false,depthWrite:false,
  uniforms:{tD:{value:null},uC:{value:[new THREE.Vector2(),new THREE.Vector2(),new THREE.Vector2(),new THREE.Vector2()]},uR:{value:[0,0,0,0]},uN:{value:0},uAsp:{value:1}},
  vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',
  fragmentShader:'precision highp float;varying vec2 vUv;uniform sampler2D tD;uniform vec2 uC[4];uniform float uR[4];uniform float uN,uAsp;\n'+
    'void main(){vec2 p0=vec2(vUv.x*uAsp,vUv.y),p=p0;float dk=0.;vec3 add=vec3(0.);float K=1.1,ds=(1.+sqrt(1.+4.*K*K))*.5;\n'+
    ' for(int i=0;i<4;i++){if(float(i)>=uN)break;\n'+
    '  vec2 d0=p0-uC[i];float R=uR[i],x0=length(d0)/R;\n'+
    '  dk=max(dk,1.-smoothstep(ds-.05,ds+.06,x0));\n'+
    '  add+=vec3(1.,.82,.52)*(exp(-pow((x0-ds-.03)/.06,2.))*.6+exp(-max(x0-ds,0.)/.45)*.07*step(ds,x0));\n'+
    '  vec2 d=p-uC[i];float r=length(d)+1e-5,x=r/R,te=R*K;\n'+
    '  float w=smoothstep(.5,1.1,x)*(1.-smoothstep(6.,11.,x));\n'+
    '  p-=d/r*(te*te/r)*w;}\n'+
    ' vec2 uv=clamp(vec2(p.x/uAsp,p.y),vec2(.002),vec2(.998));\n'+
    ' vec3 col=texture2D(tD,uv).rgb;col=mix(col,vec3(0.),dk*.6);\n'+
    ' gl_FragColor=vec4(col+add,1.);}'});
lensScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2,2),lensMat));
function lensRT(){if(lensFail)return null;var sz=renderer.getDrawingBufferSize(new THREE.Vector2());
  if(!lensRTo){try{lensRTo=renderer.capabilities.isWebGL2&&THREE.WebGLMultisampleRenderTarget?new THREE.WebGLMultisampleRenderTarget(sz.x,sz.y):new THREE.WebGLRenderTarget(sz.x,sz.y);
    lensRTo.texture.minFilter=THREE.LinearFilter;lensRTo.texture.magFilter=THREE.LinearFilter;}catch(_){lensRTo=null;return null;}}
  else if(lensRTo.width!==sz.x||lensRTo.height!==sz.y)lensRTo.setSize(sz.x,sz.y);
  return lensRTo;}
function renderLens(){var i,b,n=0,th=Math.tan(camera.fov*Math.PI/360),asp=camera.aspect,has=false;
  for(i=0;i<bodies.length;i++)if(bodies[i].bh){has=true;break;}
  if(!has||lensFail){renderer.render(scene,camera);return;}
  camera.updateMatrixWorld();camera.matrixWorldInverse.copy(camera.matrixWorld).invert();
  for(i=0;i<bodies.length&&n<4;i++){b=bodies[i];if(!b.bh)continue;_lv.set(b.x,b.y,b.z).applyMatrix4(camera.matrixWorldInverse);
    var dp=-_lv.z;if(dp<.02)continue;var R=b.r/(dp*th)/2;if(R<.0012)continue;
    var cxn=(_lv.x/(dp*th*asp)*.5+.5)*asp,cyn=_lv.y/(dp*th)*.5+.5;
    if(cxn<-10*R||cxn>asp+10*R||cyn<-10*R||cyn>1+10*R)continue;
    lensMat.uniforms.uC.value[n].set(cxn,cyn);lensMat.uniforms.uR.value[n]=R;n++;}
  if(!n){renderer.render(scene,camera);return;}
  var rt=lensRT();
  if(!rt){lensFail=true;for(i=0;i<bodies.length;i++)if(bodies[i].bh){bodies[i].mesh.layers.enable(0);bodies[i].bhFront.layers.enable(0);}renderer.render(scene,camera);return;}
  lensMat.uniforms.uN.value=n;lensMat.uniforms.uAsp.value=asp;lensMat.uniforms.tD.value=rt.texture;
  camera.layers.set(0);renderer.setRenderTarget(rt);renderer.render(scene,camera);renderer.setRenderTarget(null);
  renderer.render(lensScene,lensCam);
  camera.layers.set(1);var ac=renderer.autoClear;renderer.autoClear=false;renderer.render(scene,camera);renderer.autoClear=ac;camera.layers.set(0);}
/* ---- Цикл ---- */
/* ---- Столкновения: вспышка, ударная волна, осколки ---- */
var COLL_K=1;/* ровно по радиусам тел */
var fx=[];
function makeDeb(n,size,hot,cool){var S={n:n,pos:new Float32Array(n*3),col:new Float32Array(n*3),vel:new Float32Array(n*3),life:new Float32Array(n),max:new Float32Array(n),idx:0,hot:hot,cool:cool};
  S.geo=new THREE.BufferGeometry();S.geo.setAttribute('position',new THREE.BufferAttribute(S.pos,3));S.geo.setAttribute('color',new THREE.BufferAttribute(S.col,3));
  S.pts=new THREE.Points(S.geo,new THREE.PointsMaterial({size:size,sizeAttenuation:false,map:glowTex,vertexColors:true,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));
  S.pts.frustumCulled=false;S.pts.renderOrder=9;scene.add(S.pts);return S;}
var debS=makeDeb(480,5,[1,.78,.38],[.33,.1,.04]),debC=makeDeb(70,10,[1,.6,.2],[.2,.17,.15]);
function emitDeb(S,x,y,z,vx,vy,vz,spd,life){var i=S.idx;S.idx=(S.idx+1)%S.n;
  var a=Math.random()*6.283,c=Math.random()*2-1,s=Math.sqrt(1-c*c),k=spd*(.25+Math.random()*.9);
  S.pos[i*3]=x;S.pos[i*3+1]=y;S.pos[i*3+2]=z;S.vel[i*3]=vx+s*Math.cos(a)*k;S.vel[i*3+1]=vy+c*k;S.vel[i*3+2]=vz+s*Math.sin(a)*k;
  S.life[i]=S.max[i]=life*(.5+Math.random()*.7);}
function addFx(map,x,y,z,col,ring,a,r0,r1,dur,screen){var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:map,color:col,blending:THREE.AdditiveBlending,depthWrite:false,depthTest:false,transparent:true,sizeAttenuation:!screen,opacity:a}));
  sp.position.set(x,y,z);sp.renderOrder=11;scene.add(sp);fx.push({s:sp,t:0,dur:dur,ring:ring,a:a,r0:r0,r1:r1});}
function boom(x,y,z,vx,vy,vz,r,vr,nS,nC,col){var sp=.4+vr*.15,i;
  for(i=0;i<nS;i++)emitDeb(debS,x,y,z,vx,vy,vz,sp,3+Math.random()*7);
  for(i=0;i<nC;i++)emitDeb(debC,x,y,z,vx,vy,vz,sp*.55,8+Math.random()*9);
  addFx(glowTex,x,y,z,col,false,1,r*4,r*34,1.4,false);addFx(glowTex,x,y,z,col,false,.9,.035,.16,1.1,true);
  addFx(ringTex,x,y,z,col,true,.8,r*3,Math.max(r*60,.5),2.2,false);}
function debUpd(S,vdt){if(vdt<=0)return;var i,j,st=[];for(j=0;j<bodies.length;j++)if(bodies[j].star)st.push(bodies[j]);
  for(i=0;i<S.n;i++){var L=S.life[i];if(L<=0)continue;L-=vdt;var dead=L<=0,px=S.pos[i*3],py=S.pos[i*3+1],pz=S.pos[i*3+2],ax=0,ay=0,az=0;
    for(j=0;j<st.length&&!dead;j++){var dx=st[j].x-px,dy=st[j].y-py,dz=st[j].z-pz,d2=dx*dx+dy*dy+dz*dz,d=Math.sqrt(d2);if(d<st[j].r){dead=true;break;}var f=G*st[j].m/(d2*d);ax+=dx*f;ay+=dy*f;az+=dz*f;}
    if(dead){S.life[i]=0;S.col[i*3]=S.col[i*3+1]=S.col[i*3+2]=0;continue;}
    S.life[i]=L;var v=S.vel;v[i*3]+=ax*vdt;v[i*3+1]+=ay*vdt;v[i*3+2]+=az*vdt;
    S.pos[i*3]=px+v[i*3]*vdt;S.pos[i*3+1]=py+v[i*3+1]*vdt;S.pos[i*3+2]=pz+v[i*3+2]*vdt;
    var fr=L/S.max[i],h=Math.pow(fr,1.6),fd=Math.min(1,fr*4);
    for(j=0;j<3;j++)S.col[i*3+j]=(S.cool[j]+(S.hot[j]-S.cool[j])*h)*fd;}
  S.geo.attributes.position.needsUpdate=true;S.geo.attributes.color.needsUpdate=true;}
function fxUpd(vdt){var i;for(i=fx.length-1;i>=0;i--){var e=fx[i];e.t+=vdt;var k=e.t/e.dur;
    if(k>=1){scene.remove(e.s);e.s.material.dispose();fx.splice(i,1);continue;}
    var sc=e.r0+(e.r1-e.r0)*(e.ring?1-Math.pow(1-k,2):Math.sqrt(k));e.s.scale.set(sc,sc,1);e.s.material.opacity=e.a*(e.ring?(1-k):(1-k)*(1-k));}
  debUpd(debS,vdt);debUpd(debC,vdt);}
/* ---- Физические осколки: настоящие 3D-куски (InstancedMesh) ---- */
var CH_N=120,chGeo=new THREE.IcosahedronGeometry(1,0);
(function(){var p=chGeo.attributes.position,a=p.array,i;for(i=0;i<a.length;i+=3){var h=Math.sin(a[i]*12.9898+a[i+1]*78.233+a[i+2]*37.719)*43758.5453;h-=Math.floor(h);var k=.7+.55*h;a[i]*=k;a[i+1]*=k;a[i+2]*=k;}p.needsUpdate=true;chGeo.computeVertexNormals();})();
var chMesh=new THREE.InstancedMesh(chGeo,new THREE.MeshPhongMaterial({flatShading:true,shininess:6,specular:0x181818}),CH_N),
  chP=new Float32Array(CH_N*3),chV=new Float32Array(CH_N*3),chAx=new Float32Array(CH_N*3),chAng=new Float32Array(CH_N),chW=new Float32Array(CH_N),
  chS=new Float32Array(CH_N*3),chL=new Float32Array(CH_N),chMx=new Float32Array(CH_N),chR=new Float32Array(CH_N*3),chI=0,chDirty=true,
  chM4=new THREE.Matrix4(),chQ=new THREE.Quaternion(),chVa=new THREE.Vector3(),chVb=new THREE.Vector3(),chVc=new THREE.Vector3();
chMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);chMesh.frustumCulled=false;chMesh.renderOrder=5;
chMesh.setColorAt(0,new THREE.Color(1,1,1));
(function(){chM4.makeScale(0,0,0);for(var i=0;i<CH_N;i++)chMesh.setMatrixAt(i,chM4);})();
scene.add(chMesh);
function chKill(i){chL[i]=0;chM4.makeScale(0,0,0);chMesh.setMatrixAt(i,chM4);chDirty=true;}
function chClear(){for(var i=0;i<CH_N;i++)chKill(i);}
function spawnChunk(x,y,z,vx,vy,vz,rad,col){var i=chI,k=i*3,a=Math.random()*6.283,c=Math.random()*2-1,s=Math.sqrt(1-c*c);chI=(chI+1)%CH_N;
  chP[k]=x;chP[k+1]=y;chP[k+2]=z;chV[k]=vx;chV[k+1]=vy;chV[k+2]=vz;chAx[k]=s*Math.cos(a);chAx[k+1]=c;chAx[k+2]=s*Math.sin(a);
  chAng[i]=Math.random()*6.283;chW[i]=(Math.random()-.5)*9;
  chS[k]=rad*(.6+.8*Math.random());chS[k+1]=rad*(.6+.8*Math.random());chS[k+2]=rad*(.6+.8*Math.random());
  chL[i]=chMx[i]=45+Math.random()*60;var br=.55+.55*Math.random();chR[k]=Math.min(1,col[0]*br);chR[k+1]=Math.min(1,col[1]*br);chR[k+2]=Math.min(1,col[2]*br);chDirty=true;}
var cax_=0,cay_=0,caz_=0,cfate_=0,chit_=null,cnear_=false;
function chAccel(x,y,z){var j,n=bodies.length;cax_=cay_=caz_=0;cfate_=0;chit_=null;cnear_=false;
  for(j=0;j<n;j++){var b=bodies[j],dx=b.x-x,dy=b.y-y,dz=b.z-z,d2=dx*dx+dy*dy+dz*dz,d=Math.sqrt(d2),f;
    if(b.star){if(d<b.r){cfate_=2;chit_=b;return;}f=G*b.m/(d2*d);}
    else{if(d<b.r*.97){cfate_=1;chit_=b;return;}if(d<b.r*6)cnear_=true;var e2=d2+b.r*b.r*.36;f=G*b.m/(e2*Math.sqrt(e2));}
    cax_+=dx*f;cay_+=dy*f;caz_+=dz*f;}}
function chStep(dt){var i,j,k;
  for(i=0;i<CH_N;i++){if(chL[i]<=0)continue;k=i*3;var x=chP[k],y=chP[k+1],z=chP[k+2],ns=1,h=dt,s;
    for(s=0;s<ns;s++){chAccel(x,y,z);if(cfate_)break;if(s===0&&cnear_){ns=6;h=dt/6;}
      chV[k]+=cax_*h;chV[k+1]+=cay_*h;chV[k+2]+=caz_*h;x+=chV[k]*h;y+=chV[k+1]*h;z+=chV[k+2]*h;}
    if(cfate_){for(j=0;j<(cfate_===2?5:3);j++)emitDeb(debS,x,y,z,chit_.vx,chit_.vy,chit_.vz,cfate_===2?.8:.35,2+Math.random()*3);chKill(i);continue;}
    chP[k]=x;chP[k+1]=y;chP[k+2]=z;chAng[i]+=chW[i]*dt;chL[i]-=dt;
    if(chL[i]<=0||x*x+y*y+z*z>2.2e6){chKill(i);continue;}
    if(chMx[i]-chL[i]<7&&Math.random()<.3)emitDeb(debS,x,y,z,chV[k],chV[k+1],chV[k+2],.05,1.5+Math.random()*1.5);}}
function chRender(){if(!chDirty)return;var col=chMesh.instanceColor.array,any=false,i,k;
  for(i=0;i<CH_N;i++){if(chL[i]<=0)continue;any=true;k=i*3;
    var fade=Math.min(1,chL[i]/(chMx[i]*.18)),heat=Math.max(0,1-(chMx[i]-chL[i])/7);
    chVa.set(chP[k],chP[k+1],chP[k+2]);chVb.set(chS[k]*fade,chS[k+1]*fade,chS[k+2]*fade);chVc.set(chAx[k],chAx[k+1],chAx[k+2]);chQ.setFromAxisAngle(chVc,chAng[i]);
    chM4.compose(chVa,chQ,chVb);chMesh.setMatrixAt(i,chM4);
    col[k]=chR[k]+(1-chR[k])*heat;col[k+1]=chR[k+1]+(.5-chR[k+1])*heat;col[k+2]=chR[k+2]+(.15-chR[k+2])*heat;}
  chMesh.instanceMatrix.needsUpdate=true;chMesh.instanceColor.needsUpdate=true;chDirty=any;}
function chunkCol(b){return b.kind==='gas'?[.86,.72,.52]:b.kind==='super'?[.4,.46,.3]:[.52,.47,.42];}
/* ---- Касание сфер → плавное поглощение (малое тело «тонет» в большом) ---- */
var merges=[];
function emitChunk(big,sm,u,rad){var n=[u[0]+(Math.random()-.5)*1.5,u[1]+(Math.random()-.5)*1.5,u[2]+(Math.random()-.5)*1.5],l=Math.hypot(n[0],n[1],n[2])||1;n[0]/=l;n[1]/=l;n[2]/=l;
  var vesc=Math.sqrt(2*G*big.m/big.r),sp=vesc*(.45+.9*Math.random()),t=sp*.35;
  spawnChunk(big.x+n[0]*big.r*1.03,big.y+n[1]*big.r*1.03,big.z+n[2]*big.r*1.03,big.vx+n[0]*sp+(Math.random()-.5)*t,big.vy+n[1]*sp+(Math.random()-.5)*t,big.vz+n[2]*sp+(Math.random()-.5)*t,rad*(.35+.65*Math.random()),chunkCol(sm));}
function startMerge(big,sm,vr){var dx=sm.x-big.x,dy=sm.y-big.y,dz=sm.z-big.z,d=Math.hypot(dx,dy,dz),u;
  if(d<1e-9){var an=Math.random()*6.283;u=[Math.cos(an),0,Math.sin(an)];d=big.r+sm.r;}else u=[dx/d,dy/d,dz/d];
  var col=new THREE.Color(1,big.kind==='gas'?.85:.62,big.kind==='gas'?.6:.3);
  boom(big.x+u[0]*big.r,big.y+u[1]*big.r,big.z+u[2]*big.r,big.vx,big.vy,big.vz,big.r,vr,90,12,col);
  merges.push({big:big,sm:sm,u:u,L0:d,t:0,e0:0,dur:6+8*Math.min(1,sm.r/big.r),m0:sm.m,z0:sm.mesh.scale.x,r0:sm.r,vs:[sm.vx,sm.vy,sm.vz],nCh:Math.round(14+30*Math.cbrt(sm.m/big.m)),em:0,col:col});
  big.mg=sm;sm.mg=big;big.mgBusy=sm.mgBusy=true;
  if(big.lavaMesh)big.heatT=Math.max(big.heatT||0,7+Math.min(10,vr));}
function mergeStep(){for(var i=merges.length-1;i>=0;i--){var m=merges[i],big=m.big,sm=m.sm;
    if(bodies.indexOf(big)<0||bodies.indexOf(sm)<0){big.mg=sm.mg=null;big.mgBusy=sm.mgBusy=false;merges.splice(i,1);continue;}
    m.t=Math.min(1,m.t+DT/m.dur);var e=m.t*m.t*(3-2*m.t),de=e-m.e0;m.e0=e;
    var dm=m.m0*de,mb=big.m,Mn=mb+dm;
    big.vx=(big.vx*mb+m.vs[0]*dm)/Mn;big.vy=(big.vy*mb+m.vs[1]*dm)/Mn;big.vz=(big.vz*mb+m.vs[2]*dm)/Mn;
    big.x=(big.x*mb+sm.x*dm)/Mn;big.y=(big.y*mb+sm.y*dm)/Mn;big.z=(big.z*mb+sm.z*dm)/Mn;
    setSize(big,Math.cbrt(Mn/KM[big.kind]));big.m=Mn;
    sm.m=Math.max(1e-6,m.m0*(1-e));var zs=Math.max(.002,m.z0*Math.cbrt(1-e));sm.mesh.scale.setScalar(zs);sm.r=KR[sm.kind]*zs;
    var sep=m.L0*(1-e);sm.x=big.x+m.u[0]*sep;sm.y=big.y+m.u[1]*sep;sm.z=big.z+m.u[2]*sep;sm.vx=big.vx;sm.vy=big.vy;sm.vz=big.vz;
    var px=big.x+m.u[0]*big.r,py=big.y+m.u[1]*big.r,pz=big.z+m.u[2]*big.r;
    if(Math.random()<.55)emitDeb(debS,px,py,pz,big.vx,big.vy,big.vz,.35+.9*Math.random(),3+Math.random()*5);
    if(Math.random()<.03)emitDeb(debC,px,py,pz,big.vx,big.vy,big.vz,.2,8+Math.random()*8);
    var want=Math.round(m.nCh*(1-(1-m.t)*(1-m.t)));while(m.em<want){emitChunk(big,sm,m.u,m.r0*.22);m.em++;}
    if(m.t>=1){addFx(glowTex,big.x,big.y,big.z,m.col,false,.55,big.r*3,big.r*16,1.2,false);
      if(big.lavaMesh)big.heatT=Math.max(big.heatT||0,6);
      big.mg=null;big.mgBusy=false;if(follow===sm)follow=big;merges.splice(i,1);removeBody(sm);}}}
/* ---- Захват спутников: планета ≥ в 3 раза тяжелее может удержать лёгкую внутри своей сферы влияния ---- */
function captureStep(dt,arr){arr=arr||bodies;var n=arr.length,i,j;/* только определяет хозяина (связанный спутник); искусственного захвата больше нет — спутники создаются мастером */
  for(i=0;i<n;i++){var mo=arr[i];if(mo.star||mo.mgBusy)continue;var best=null,bd=1e9;
    for(j=0;j<n;j++){if(j===i)continue;var h=arr[j];if(h.star||h.mgBusy||!(h.M>=MOON_K*mo.M)||!(h._R>0))continue;
      var x=mo.x-h.x,y=mo.y-h.y,z=mo.z-h.z,d=Math.sqrt(x*x+y*y+z*z);if(d<h._R*.85&&d<bd){best=h;bd=d;}}
    if(!best){mo.host=null;continue;}
    var vx=mo.vx-best.vx,vy=mo.vy-best.vy,vz=mo.vz-best.vz;
    mo.host=((vx*vx+vy*vy+vz*vz)/2-G*(best.m+mo.m)/bd<0)?best:null;}}
function impact(a,b,vr){var big=a.m>=b.m?a:b,sm=big===a?b:a,M=a.m+b.m,L=a.r+b.r,vesc=Math.sqrt(2*G*M/L);
  if(vr<=1.7*vesc){startMerge(big,sm,vr);return;}
  /* катастрофа: слишком быстрый удар — оба тела разлетаются в куски */
  var t=a.r/L,px=a.x+(b.x-a.x)*t,py=a.y+(b.y-a.y)*t,pz=a.z+(b.z-a.z)*t,
    nvx=(a.vx*a.m+b.vx*b.m)/M,nvy=(a.vy*a.m+b.vy*b.m)/M,nvz=(a.vz*a.m+b.vz*b.m)/M,
    col=new THREE.Color(1,big.kind==='gas'?.85:.62,big.kind==='gas'?.6:.3);
  boom(px,py,pz,nvx,nvy,nvz,big.r,vr,420,60,col);
  var i,rad=Math.min(a.r,b.r)*.2,sp0=Math.max(vr*.5,vesc*.4);
  for(i=0;i<34;i++){var an=Math.random()*6.283,c=Math.random()*2-1,sn=Math.sqrt(1-c*c),sp=sp0*(.3+Math.random()),n=[sn*Math.cos(an),c,sn*Math.sin(an)];
    spawnChunk(px+n[0]*L*.4,py+n[1]*L*.4,pz+n[2]*L*.4,nvx+n[0]*sp,nvy+n[1]*sp,nvz+n[2]*sp,rad*(.4+.9*Math.random()),chunkCol(Math.random()<.5?a:b));}
  removeBody(a);removeBody(b);}
function collide(){var n=bodies.length,i,j,a,b;
  for(i=0;i<n;i++){a=bodies[i];if(!a||a.star||a.mgBusy)continue;
    for(j=i+1;j<n;j++){b=bodies[j];if(!b||b.star||b.mgBusy)continue;
      var dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,vx=b.vx-a.vx,vy=b.vy-a.vy,vz=b.vz-a.vz,v2=vx*vx+vy*vy+vz*vz,L=(a.r+b.r)*COLL_K,
        px=dx-vx*DT,py=dy-vy*DT,pz=dz-vz*DT,s=v2>1e-12?Math.max(0,Math.min(DT,-(px*vx+py*vy+pz*vz)/v2)):0,
        qx=px+vx*s,qy=py+vy*s,qz=pz+vz*s;
      if(qx*qx+qy*qy+qz*qz<L*L||dx*dx+dy*dy+dz*dz<L*L){impact(a,b,Math.sqrt(v2));return;}}}}
function absorb(b,c){var dx=b.x-c.x,dy=b.y-c.y,dz=b.z-c.z,d=Math.hypot(dx,dy,dz)||1,x=c.x+dx/d*c.r,y=c.y+dy/d*c.r,z=c.z+dz/d*c.r;
  boom(x,y,z,c.vx,c.vy,c.vz,b.r*2,3,70,8,new THREE.Color(1,.8,.35));}
/* ---- Спутники: мастер создания (размер — ползунком, орбита — натяжением с превью по реальной физике) ---- */
var moonSt=null,moonDrag=null,MVN=900,mvArr=new Float32Array(MVN*3),mvRing=new Float32Array(97*3),mvPullA=new Float32Array(6),mvOrbit,mvHill,mvGhost,mvPull;
(function(){var g1=new THREE.BufferGeometry(),g2=new THREE.BufferGeometry(),g3=new THREE.BufferGeometry();
  g1.setAttribute('position',new THREE.BufferAttribute(mvArr,3));g1.setDrawRange(0,0);g2.setAttribute('position',new THREE.BufferAttribute(mvRing,3));g3.setAttribute('position',new THREE.BufferAttribute(mvPullA,3));
  mvOrbit=new THREE.Line(g1,new THREE.LineBasicMaterial({color:0x58d6ff,depthTest:false,transparent:true}));
  mvHill=new THREE.LineLoop(g2,new THREE.LineBasicMaterial({color:0x58d6ff,opacity:.3,depthTest:false,transparent:true}));
  mvPull=new THREE.Line(g3,new THREE.LineBasicMaterial({color:0xe0c4ff,depthTest:false,transparent:true}));
  mvGhost=new THREE.Mesh(GEO.planet,MAT.planet);
  [mvOrbit,mvHill,mvPull,mvGhost].forEach(function(o){o.renderOrder=12;o.frustumCulled=false;o.visible=false;scene.add(o);});})();
function moonOK(h){return !h.star&&h.M>=MOON_K*MDEF.planet*ZMIN*ZMIN*ZMIN*1.001;}
function hostR(h){var ds=1e9,Ms=0,k;for(k=0;k<bodies.length;k++)if(bodies[k].star){var d=Math.hypot(bodies[k].x-h.x,bodies[k].y-h.y,bodies[k].z-h.z);if(d<ds){ds=d;Ms=bodies[k].m;}}
  return Ms>0?Math.min(MOON_MAX,.5*ds*Math.cbrt(h.m/(3*Ms))):PP_MAX;}
function moonCalc(){var s=moonSt,h=s.host,i;
  s.zMax=Math.min(1,.99*Math.cbrt(h.M/(MOON_K*MDEF.planet)));s.z=ZMIN+(s.zMax-ZMIN)*s.sv;
  var rm=KR.planet*s.z,rMax=.6*hostR(h),rMin=(h.r+rm)*Math.max(COLL_K,1)*2+h.r*.3;s.warn=false;
  if(rMax<rMin*1.5){rMax=rMin*1.5;s.warn=true;}
  s.rm=rm;s.rMin=rMin;s.rMaxA=rMax;s.mu=G*(h.m+KM.planet*s.z*s.z*s.z);
  var r=.5*rMax,vc=Math.sqrt(s.mu*r*r/Math.pow(r*r+.01,1.5));s.k=vc/(.35*rMax);/* оттяжка на 35% зоны даёт круговую скорость на середине зоны */
  for(i=0;i<=96;i++){var t=i/96*6.28319;mvRing[i*3]=Math.cos(t)*rMax;mvRing[i*3+1]=0;mvRing[i*3+2]=Math.sin(t)*rMax;}}
function moonSync(){var s=moonSt;moonCalc();mvHill.geometry.attributes.position.needsUpdate=true;mvGhost.scale.setScalar(s.z);
  $('mvS').textContent=(MDEF.planet*s.z*s.z*s.z).toPrecision(2)+' M⊕';
  $('mWarn').textContent=s.warn?'⚠ Планета близко к звезде: зона устойчивости крошечная. Отодвинь её дальше.':'';}
function moonPrev(){var s=moonSt,a=s.aim,mu=s.mu,eps=.01,x=a.rx,z=a.rz,vx=a.vx,vz=a.vz,n=0,sum=0,last=Math.atan2(z,x),res='ok',maxr=0,contact=s.host.r+s.rm,k;
  mvArr[0]=x;mvArr[1]=0;mvArr[2]=z;n=1;
  for(k=0;k<6000&&n<MVN;k++){var r2=x*x+z*z+eps,rr=Math.sqrt(r2),dt=.02*Math.sqrt(rr*rr*rr/mu),f=-mu/(r2*rr);
    vx+=f*x*dt/2;vz+=f*z*dt/2;x+=vx*dt;z+=vz*dt;r2=x*x+z*z+eps;rr=Math.sqrt(r2);f=-mu/(r2*rr);vx+=f*x*dt/2;vz+=f*z*dt/2;
    mvArr[n*3]=x;mvArr[n*3+1]=0;mvArr[n*3+2]=z;n++;
    var rad=Math.hypot(x,z);if(rad<contact){res='crash';break;}if(rad>s.rMaxA*1.6){res='escape';break;}if(rad>maxr)maxr=rad;
    var th=Math.atan2(z,x),d=th-last;if(d>3.14159)d-=6.28319;if(d<-3.14159)d+=6.28319;sum+=d;last=th;if(Math.abs(sum)>6.28319*1.02)break;}
  if(res==='ok'&&maxr>s.rMaxA)res='wide';a.res=res;
  mvOrbit.material.color.setHex(res==='ok'?0x58d6ff:res==='wide'?0xffd24d:0xff5a4d);
  mvOrbit.geometry.attributes.position.needsUpdate=true;mvOrbit.geometry.setDrawRange(0,n);
  var st=$('mState');st.textContent={ok:'✔ Орбита устойчива',wide:'⚠ Выходит за устойчивую зону',crash:'✖ Упадёт на планету',escape:'✖ Улетит прочь'}[res];st.style.color=res==='ok'?'#7be3ff':res==='wide'?'#ffd24d':'#ff7a6b';}
function moonFrame(){var s=moonSt,h=s.host;if(bodies.indexOf(h)<0){cancelMoon();return;}
  mvOrbit.position.set(h.x,h.y,h.z);mvHill.position.set(h.x,h.y,h.z);mvPull.position.set(h.x,h.y,h.z);
  if(s.aim)mvGhost.position.set(h.x+s.aim.rx,h.y,h.z+s.aim.rz);}
function moonPlanePt(e){var h=moonSt.host,r=el.getBoundingClientRect(),pl=new THREE.Plane(new THREE.Vector3(0,1,0),-h.y),P=new THREE.Vector3();
  ndc.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);ray.setFromCamera(ndc,camera);return ray.ray.intersectPlane(pl,P)?P:null;}
function moonStart(e){var s=moonSt,h=s.host,P=moonPlanePt(e);if(!P)return false;var dx=P.x-h.x,dz=P.z-h.z,d=Math.hypot(dx,dz);
  if(d>s.rMaxA*1.15)return false;if(d<1e-9){dx=1;dz=0;d=1;}var c=Math.min(Math.max(d,s.rMin),s.rMaxA)/d;
  s.aim={rx:dx*c,rz:dz*c,vx:0,vz:0,l:0,res:''};mvGhost.position.set(h.x+s.aim.rx,h.y,h.z+s.aim.rz);mvGhost.visible=true;mvPull.visible=true;mvOrbit.visible=false;
  mvPullA.set([s.aim.rx,0,s.aim.rz,s.aim.rx,0,s.aim.rz]);mvPull.geometry.attributes.position.needsUpdate=true;$('mState').textContent='';return true;}
function moonAim(e){var s=moonSt,a=s&&s.aim;if(!a)return;var P=moonPlanePt(e);if(!P)return;var h=s.host,px=a.rx-(P.x-h.x),pz=a.rz-(P.z-h.z),l=Math.hypot(px,pz),lm=1.5*s.rMaxA;
  if(l>lm){px*=lm/l;pz*=lm/l;l=lm;}a.vx=px*s.k;a.vz=pz*s.k;a.l=l;
  mvPullA.set([a.rx,0,a.rz,a.rx-px,0,a.rz-pz]);mvPull.geometry.attributes.position.needsUpdate=true;
  if(l>.03*s.rMaxA){moonPrev();mvOrbit.visible=true;}else{mvOrbit.visible=false;$('mState').textContent='';}}
function moonRelease(){var s=moonSt;moonDrag=null;if(!s||!s.aim)return;
  if(s.aim.l>.03*s.rMaxA)createMoon();else{s.aim=null;mvGhost.visible=false;mvPull.visible=false;mvOrbit.visible=false;}}
function startMoon(h){if(!moonOK(h))return;closeAll();mode='moon';pbtn.classList.remove('active');
  moonSt={host:h,sv:.4,aim:null};$('mHost').textContent=h.name||h.defName;$('mS').value=40;$('mState').textContent='';
  $('moonPanel').classList.add('show');document.body.classList.add('moon');mvHill.visible=true;
  moonSync();follow=h;camLock=false;tDist=Math.max(.15,moonSt.rMaxA*3.2);}
function cancelMoon(){moonSt=null;moonDrag=null;$('moonPanel').classList.remove('show');document.body.classList.remove('moon');
  mvOrbit.visible=mvHill.visible=mvGhost.visible=mvPull.visible=false;if(mode==='moon')mode='idle';}
function createMoon(){var s=moonSt,h=s.host,a=s.aim,mm=KM.planet*s.z*s.z*s.z,M=h.m+mm,fm=mm/M,fh=h.m/M,rx=a.rx,rz=a.rz,vx=a.vx,vz=a.vz,hx=h.x,hz=h.z,hvx=h.vx,hvz=h.vz;
  addBody('planet',hx+rx*fh,hz+rz*fh,hvx+vx*fh,hvz+vz*fh);var b=bodies[bodies.length-1];
  b.y=h.y;b.vy=h.vy;setSize(b,s.z);b.host=h;b.name=b.defName=(h.name||h.defName)+' · спутник';
  h.x=hx-rx*fm;h.z=hz-rz*fm;h.vx=hvx-vx*fm;h.vz=hvz-vz*fm;
  if(typeof addFx==='function'&&typeof ringTex!=='undefined')addFx(ringTex,b.x,b.y,b.z,new THREE.Color(.45,.85,1),true,.8,b.r*3,Math.max(b.r*40,.2),1.3,false);
  cancelMoon();follow=b;tDist=Math.max(.15,h.r*10);}
(function(){$('mS').addEventListener('input',function(){moonSt.sv=parseFloat(this.value)/100;moonSync();});$('mNo').addEventListener('click',cancelMoon);})();
function cleanup(){var i,j,b,c;
  for(i=bodies.length-1;i>=0;i--){b=bodies[i];if(!b)continue;
    if(!(Math.hypot(b.x,b.y,b.z)<1e7)){removeBody(b);continue;}
    if(!b.star){for(j=0;j<bodies.length;j++){c=bodies[j];if(c.star&&!c.bh&&Math.hypot(b.x-c.x,b.y-c.y,b.z-c.z)<c.r+b.r){absorb(b,c);removeBody(b);break;}}}}
  for(i=0;i<bodies.length;i++){b=bodies[i];if(!b.star||b.bh)continue;for(j=i+1;j<bodies.length;j++){c=bodies[j];
    if(c.star&&!c.bh&&Math.hypot(b.x-c.x,b.z-c.z)<(b.r+c.r)*.6){var hv=c.m>b.m?c:b,lt=hv===b?c:b,M=hv.m+lt.m;hv.x=(hv.x*hv.m+lt.x*lt.m)/M;hv.z=(hv.z*hv.m+lt.z*lt.m)/M;hv.vx=(hv.vx*hv.m+lt.vx*lt.m)/M;hv.vz=(hv.vz*hv.m+lt.vz*lt.m)/M;hv.m=M;hv.T=msT(M/SUNM);starApply(hv);removeBody(lt);if(lt===b)break;j--;}}}}
var comTex=(function(){var c=document.createElement('canvas');c.width=c.height=32;var g=c.getContext('2d'),gr=g.createRadialGradient(16,16,2,16,16,14);gr.addColorStop(0,'rgba(255,60,60,1)');gr.addColorStop(.7,'rgba(255,30,30,1)');gr.addColorStop(1,'rgba(255,30,30,0)');g.fillStyle=gr;g.fillRect(0,0,32,32);return new THREE.CanvasTexture(c);})();
var com=new THREE.Sprite(new THREE.SpriteMaterial({map:comTex,depthTest:false,transparent:true,sizeAttenuation:false}));com.scale.set(.02,.02,1);com.renderOrder=13;com.visible=false;scene.add(com);
/* ---- Общий центр масс: звёзды образуют группу, только если гравитационно влияют друг на друга ---- */
var comTexL=(function(){var c=document.createElement('canvas');c.width=c.height=32;var g=c.getContext('2d'),gr=g.createRadialGradient(16,16,2,16,16,14);gr.addColorStop(0,'rgba(90,255,140,1)');gr.addColorStop(.7,'rgba(40,230,100,1)');gr.addColorStop(1,'rgba(40,230,100,0)');g.fillStyle=gr;g.fillRect(0,0,32,32);return new THREE.CanvasTexture(c);})();
var comPool=[com],GR=[],EM=[];
function comLink(a,b){return Math.hypot(a.x-b.x,a.z-b.z)<300*Math.sqrt((a.m+b.m)/(2*SUNM));}
function updCom(){var st=[],i,j,k;
  for(i=0;i<bodies.length;i++){bodies[i].gr=null;bodies[i].gm=false;if(bodies[i].star&&!bodies[i].bh)st.push(bodies[i]);}
  var gid=st.map(function(_,q){return q;});function fd(q){while(gid[q]!==q)q=gid[q];return q;}
  for(i=0;i<st.length;i++)for(j=i+1;j<st.length;j++)if(comLink(st[i],st[j]))gid[fd(i)]=fd(j);
  var groups={};for(i=0;i<st.length;i++){k=fd(i);(groups[k]=groups[k]||[]).push(st[i]);}
  GR.length=0;EM.length=0;
  for(k in groups){var g=groups[k];if(g.length<2){g[0].lockA=null;g[0].zmd=false;continue;}
    var M=0,sx=0,sz=0,z2=0,anc=null,was=false,ms=0;
    for(i=0;i<g.length;i++){var s=g[i],zz=s.zs;M+=s.m;sx+=s.x*s.m;sz+=s.z*s.m;z2+=zz*zz;if(s.lockA)anc=s.lockA;if(s.zmd)was=true;}
    for(i=0;i<g.length;i++)for(j=i+1;j<g.length;j++)ms=Math.max(ms,Math.hypot(g[i].x-g[j].x,g[i].z-g[j].z));
    var Gp={stars:g,x:sx/M,z:sz/M,Zs:Math.sqrt(z2),anchor:anc};
    /* близкая пара: одна общая зона вокруг центра масс, ≈√(сумма светимостей) от обычной (у двух Солнц ×1,4) */
    Gp.merged=ms<(was?46:40)*Gp.Zs;
    for(i=0;i<g.length;i++){g[i].gr=Gp;g[i].gm=Gp.merged;g[i].zmd=Gp.merged;}
    if(Gp.merged)EM.push({x:Gp.x,y:0,z:Gp.z,zs:Gp.Zs});
    GR.push(Gp);}
  for(i=0;i<GR.length;i++){var mk=comPool[i];if(!mk){mk=new THREE.Sprite(com.material.clone());mk.renderOrder=13;scene.add(mk);comPool[i]=mk;}
    var lk=!!GR[i].anchor;mk.material.map=lk?comTexL:comTex;mk.scale.set(lk?.028:.02,lk?.028:.02,1);mk.visible=showAids;mk.position.set(GR[i].x,.05,GR[i].z);}
  for(;i<comPool.length;i++)comPool[i].visible=false;}
/* фиксация: система переходит в систему отсчёта центра масс группы, он стоит на месте, звёзды не разлетаются */
function comLockStep(){for(var i=0;i<GR.length;i++){var Gp=GR[i];if(!Gp.anchor)continue;
  var M=0,sx=0,sz=0,vx=0,vz=0,s,j;for(j=0;j<Gp.stars.length;j++){s=Gp.stars[j];M+=s.m;sx+=s.x*s.m;sz+=s.z*s.m;vx+=s.vx*s.m;vz+=s.vz*s.m;}
  var dx=Gp.anchor.x-sx/M,dz=Gp.anchor.z-sz/M,ux=vx/M,uz=vz/M;
  if(Math.abs(dx)+Math.abs(dz)+Math.abs(ux)+Math.abs(uz)<1e-9)continue;
  for(j=0;j<bodies.length;j++){var b=bodies[j];b.x+=dx;b.z+=dz;b.vx-=ux;b.vz-=uz;}}}
function toggleComLock(b){var Gp=b.gr;if(!Gp)return;var on=Gp.stars.some(function(s){return s.lockA;});
  if(on)Gp.stars.forEach(function(s){s.lockA=null;});else{var an={x:Gp.x,z:Gp.z};Gp.stars.forEach(function(s){s.lockA=an;});}}
var clock=new THREE.Clock(),accT=0,stepN=0,simT=0;
function frame(){
  if(edOn){clock.getDelta();edFrame();requestAnimationFrame(frame);return;}
  var dt=Math.min(clock.getDelta(),0.05),i,sdt=(drag||moonDrag||paused)?0:dt*TS,vdt=sdt;simT+=vdt;if(menuOn)tYaw+=dt*.04;
  if(!drag&&!moonDrag){accT=Math.min(accT+dt*SPEED,3.2);var guard=0,tw0=performance.now();while(accT>=DT&&guard++<160&&(guard<6||performance.now()-tw0<14)){step(bodies,DT);accT-=DT;collide();mergeStep();captureStep(DT);chStep(DT);if(++stepN%3===0)for(i=0;i<bodies.length;i++)recTrail(bodies[i]);}if(accT>=DT*2)accT=0;/* не копим отставание — иначе лаги нарастают */
    cleanup();}
  comLockStep();pvFlush();
  for(i=0;i<bodies.length;i++){var bb=bodies[i];bb.mesh.position.set(bb.x,bb.y,bb.z);if(bb.bh)bb.bhMat.uniforms.uT.value=simT;else if(bb.star)bb.mesh.material.uniforms.uTime.value=simT;bb.mesh.rotation.y+=vdt*(bb.star?0.04:bb.spin);if(!bb.star)bb.mesh.rotation.z=bb.tilt*.0174533;if(bb.cloudMesh)bb.cloudMesh.rotation.y+=vdt*.08;if(bb.star){bb.glow.position.copy(bb.mesh.position);if(bb.light)bb.light.position.copy(bb.mesh.position);}bb.trail.line.visible=showAids;if(bb.zone){var G_=bb.gr,mg_=!!(G_&&G_.merged),zs=mg_?G_.Zs:bb.zs,sh_=showZones||!!(infoBody&&infoBody.near&&(infoBody.near===bb||(mg_&&infoBody.near.gr===G_)))||!!(drag&&!isStarT(placeType));bb.zone.visible=sh_&&(!mg_||G_.stars[0]===bb);bb.zone.position.set(mg_?G_.x:bb.x,bb.y+.03,mg_?G_.z:bb.z);bb.zone.scale.set(673.2*zs,673.2*zs,1);}lavaUpd(bb,sdt,vdt);snowUpd(bb,sdt);ecoUpd(bb,sdt,dt);markerUpd(bb);}
  if(infoBody){if(bodies.indexOf(infoBody)<0)closeInfo();else refreshInfo(infoBody);}
  lockUI();updCom();fxUpd(vdt);flareStep(vdt);if(moonSt)moonFrame();chRender();orbUpd();
  sunMat.uniforms.uTime.value=simT;dwarfMat.uniforms.uTime.value=simT;zoneMat.uniforms.uT.value=simT;
  nextP-=vdt;if(nextP<=0){spawnP();nextP=1.2+Math.random()*2.2;}
  for(i=0;i<parts.length;i++){var p=parts[i];if(p.life<=0)continue;p.life-=vdt;
    if(p.life<=0){p.s.visible=false;continue;}
    p.s.position.addScaledVector(p.v,vdt);var f=p.life/p.max;p.s.material.opacity=f*.8;p.s.scale.setScalar(p.sz*(.4+f*.8));}
  updAParts(vdt);
  yaw+=(tYaw-yaw)*0.15;pitch+=(tPitch-pitch)*0.15;dist+=(tDist-dist)*0.15;
  if(follow){if(bodies.indexOf(follow)<0)follow=null;else{tcx=cx=follow.x;tcz=cz=follow.z;cy=follow.y;}}if(!follow){cx+=(tcx-cx)*.35;cz+=(tcz-cz)*.35;cy+=(0-cy)*.35;}
  camera.position.set(cx+Math.sin(yaw)*Math.cos(pitch)*dist,cy+Math.sin(pitch)*dist,cz+Math.cos(yaw)*Math.cos(pitch)*dist);
  var nr_=Math.max(.005,dist*.001),fr_=Math.max(12000,dist*100);if(camera.near!==nr_||camera.far!==fr_){camera.near=nr_;camera.far=fr_;camera.updateProjectionMatrix();}
  viewUpd();camera.lookAt(cx,cy,cz);sky.position.copy(camera.position);updGrid();renderLens();requestAnimationFrame(frame);}

/* ---- Полноэкранный режим ---- */
/* Полноэкранный режим: браузер разрешает его только по касанию, поэтому включаем при первом касании (кнопка Play) и снова при следующем, если из него вышли */
(function(){var d=document,e=d.documentElement;
  function isFS(){return !!(d.fullscreenElement||d.webkitFullscreenElement);}
  function goFS(){if(isFS())return;var f=e.requestFullscreen||e.webkitRequestFullscreen||e.msRequestFullscreen;if(!f)return;
    try{var p=f.call(e,{navigationUI:'hide'});var lock=function(){try{screen.orientation.lock('landscape').catch(function(){});}catch(_){}};
      if(p&&p.then)p.then(lock).catch(function(){});else lock();}catch(_){}}
  ['pointerup','touchend','click','keydown'].forEach(function(ev){d.addEventListener(ev,goFS,true);});
})();

/* ==========================================================================
   ЗАПУСК. Вызывается из index.html после загрузки ВСЕХ файлов
   (карты и объекты к этому моменту уже зарегистрированы).
   ========================================================================== */
function startGame(){
  ghost=new THREE.Mesh(planetGeo,merMat);ghost.visible=false;scene.add(ghost);ghostM=makeMarker();ghostM.visible=false;
  paintIcon('tiStar','star');paintIcon('tiDwarf','dwarf');paintIcon('tiPlanet','planet');paintIcon('tiSuper','super');paintIcon('tiGas','gas');paintIcon('tiBH','bh');
  cmLoad();/* карты из редактора: файлы planet_maps/custom + сохранённые в браузере */
  loadSaved();renderSaved();
  selectType('star');showTab('stars');
  frame();
}
