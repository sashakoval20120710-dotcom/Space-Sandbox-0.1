/* Сохранить свои карты из редактора файлами.
   Открой консоль браузера и выполни  exportCustomMaps()  — скачается по одному .js на карту.
   Положи файлы в эту папку и подключи их в index.html (блок «Свои карты») — карта будет жить в папке игры. */
function exportCustomMaps(){var n=0;
  CM_LIST.forEach(function(c,i){if(c.file)return;n++;
    var slug=(c.name||'map').toLowerCase().replace(/[^a-z0-9а-яё]+/gi,'_').replace(/^_|_$/g,'')||('map_'+i);
    var txt='/* Карта из редактора: '+c.name+' */\nCM_FILES.push({name:'+JSON.stringify(c.name)+',rle:'+JSON.stringify(cmEnc(c.h))+'});\n';
    var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'text/javascript'}));a.download=slug+'.js';
    setTimeout(function(){a.click();},n*400);});
  return n+' карт(ы) к скачиванию';}
