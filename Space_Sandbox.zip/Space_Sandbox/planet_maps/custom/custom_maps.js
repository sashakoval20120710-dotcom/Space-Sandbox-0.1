/* ================= СВОИ КАРТЫ ПОВЕРХНОСТИ + РЕДАКТОР ================= */
var CM_W=1024,CM_H=512,CM_KEY='ss_custom_maps_v1',CM_LIST=[];
/* карты из редактора, сохранённые файлами (planet_maps/custom/*.js): CM_FILES.push({name:'…',rle:'…'}) */
var CM_FILES=[];
/* глубина океана: 0 у берега … 255 далеко от суши (двойное размытие маски суши) */
function cmDepth(cm){var W=CM_W,H=CM_H,N=W*H,a=new Float32Array(N),b=new Float32Array(N),i,x,y,k,p,R=16;
  for(i=0;i<N;i++)a[i]=cm.h[i]>=28?1:0;
  for(p=0;p<2;p++){
    for(y=0;y<H;y++){var row=y*W,sum=0;for(k=-R;k<=R;k++)sum+=a[row+((k%W)+W)%W];
      for(x=0;x<W;x++){b[row+x]=sum/(2*R+1);sum+=a[row+((x+R+1)%W)]-a[row+(((x-R)%W)+W)%W];}}
    for(x=0;x<W;x++){var s2=0;for(k=-R;k<=R;k++)s2+=b[Math.max(0,Math.min(H-1,k))*W+x];
      for(y=0;y<H;y++){a[y*W+x]=s2/(2*R+1);s2+=b[Math.min(H-1,y+R+1)*W+x]-b[Math.max(0,y-R)*W+x];}}}
  var d=new Uint8Array(N);for(i=0;i<N;i++)d[i]=Math.round(255*(1-Math.min(1,a[i]*1.7)));cm.d=d;}
/* текстура-маска для слоёв воды и растительности: R — высота суши, G — глубина океана */
function maskTex(cm){if(cm.mtex)return cm.mtex;var c=document.createElement('canvas');c.width=CM_W;c.height=CM_H;
  var g=c.getContext('2d'),im=g.createImageData(CM_W,CM_H),d=im.data,i,N=CM_W*CM_H;
  for(i=0;i<N;i++){d[i*4]=cm.h[i];d[i*4+1]=cm.d[i];d[i*4+2]=0;d[i*4+3]=255;}
  g.putImageData(im,0,0);var t=new THREE.CanvasTexture(c);t.wrapS=THREE.RepeatWrapping;t.anisotropy=2;cm.mtex=t;return t;}
function cmRegister(cm){cmDepth(cm);CM_LIST.push(cm);
  RMAP.push({name:cm.name,s:5,amp:70,hc:1,base:150,nc:0,cm:0,t:[1,.97,.93],low:[.74,.72,.68],fx:null,custom:cm});
  SPAR.push(mkP({name:cm.name,custom:cm,sn:.7,se:1.3,rk:.42,rkw:.5,bump:.85}));
  cm.idx=RMAP.length-1;return cm.idx;}
function cmReplace(cm,h,name){cm.h.set(h);cmDepth(cm);cm.name=name;RMAP[cm.idx].name=name;SPAR[cm.idx].name=name;
  if(cm.mtex){cm.mtex.dispose();cm.mtex=null;}
  var t=HIGHS[cm.idx];if(t){if(t.map)t.map.dispose();if(t.normalMap)t.normalMap.dispose();t.dispose();delete HIGHS[cm.idx];}
  var r=SM[cm.idx];if(r){r.dead=true;[r.map,r.spec,r.bump].forEach(function(q){if(q&&q.dispose)q.dispose();});delete SM[cm.idx];}}
function cmEnc(h){var out=[],n=h.length,i=0;while(i<n){var v=h[i],r=1;while(i+r<n&&h[i+r]===v&&r<255)r++;out.push(v,r);i+=r;}
  var u=new Uint8Array(out),s='',CH=8192;for(i=0;i<u.length;i+=CH)s+=String.fromCharCode.apply(null,u.subarray(i,i+CH));return btoa(s);}
function cmDec(b64){var s=atob(b64),h=new Uint8Array(CM_W*CM_H),i,j=0;for(i=0;i+1<s.length;i+=2){var v=s.charCodeAt(i),r=s.charCodeAt(i+1);while(r--&&j<h.length)h[j++]=v;}return h;}
function cmStore(){try{localStorage.setItem(CM_KEY,JSON.stringify(CM_LIST.filter(function(c){return !c.file;}).map(function(c){return {name:c.name,rle:cmEnc(c.h)};})));return true;}catch(e){return false;}}
function cmLoad(){try{for(var j=0;j<CM_FILES.length;j++)cmRegister({name:CM_FILES[j].name,h:cmDec(CM_FILES[j].rle),file:true});}catch(e){}
  try{var a=JSON.parse(localStorage.getItem(CM_KEY)||'[]');for(var i=0;i<a.length;i++)cmRegister({name:a[i].name,h:cmDec(a[i].rle)});}catch(e){}}
/* cmLoad() вызывается из startGame() в main.js */
