/* ---- редактор: отдельная сцена с серой планетой, рисуем кистью по сфере ---- */
var edOn=false,edInited=false,edScene=new THREE.Scene(),edCam=new THREE.PerspectiveCamera(38,1,.1,60),edMesh=null,edTex=null,edCtx=null,edImg=null,edCur=null,
  edH=new Uint8Array(CM_W*CM_H),edUndoH=null,edTool='land',edLockOn=true,edYaw=.35,edPitch=.25,edDist=3.4,edDirty=null,edPtr={},edStroke=null,edHit=null,edPinch=0,edSaved=null,edStamped=0,edToastT=0,
  edLonC=new Float32Array(CM_W),edLonS=new Float32Array(CM_W),edLatS=new Float32Array(CM_H),edLatC=new Float32Array(CM_H),
  edRay=new THREE.Raycaster(),edV2=new THREE.Vector2(),edPad=$('edPad');
function edSm(t){t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);}
function edToast(m){var t=$('edToast');t.textContent=m;t.classList.add('show');clearTimeout(edToastT);edToastT=setTimeout(function(){t.classList.remove('show');},3200);}
function edInit(){if(edInited)return;edInited=true;var i;
  edScene.background=new THREE.Color(0x040a14);
  var cv=document.createElement('canvas');cv.width=CM_W;cv.height=CM_H;edCtx=cv.getContext('2d');edImg=edCtx.createImageData(CM_W,CM_H);
  edTex=new THREE.CanvasTexture(cv);edTex.wrapS=THREE.RepeatWrapping;edTex.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());
  edMesh=new THREE.Mesh(new THREE.SphereGeometry(1,96,64),new THREE.MeshLambertMaterial({map:edTex}));edScene.add(edMesh);
  edScene.add(new THREE.AmbientLight(0xffffff,.55));var dl=new THREE.DirectionalLight(0xffffff,.85);dl.position.set(-2,2,3);edScene.add(dl);
  edCur=new THREE.Mesh(new THREE.RingGeometry(.92,1,48),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.85,depthTest:false,side:THREE.DoubleSide}));edCur.renderOrder=5;edCur.visible=false;edScene.add(edCur);
  for(i=0;i<CM_W;i++){var l=(i+.5)/CM_W*6.2831853;edLonC[i]=Math.cos(l);edLonS[i]=Math.sin(l);}
  for(i=0;i<CM_H;i++){var t=(i+.5)/CM_H*Math.PI;edLatS[i]=Math.sin(t);edLatC[i]=Math.cos(t);}}
/* цвет одного пикселя: вода — тёмно-серая, суша — светлее с высотой + тень рельефа */
function edPx(x,y){var W=CM_W,H=CM_H,i=y*W+x,hv=edH[i],o=i*4,d=edImg.data,r,g,b;
  if(hv<28){r=56;g=68;b=82;}
  else{var l=112+(hv-28)/227*130,xm=edH[y*W+((x+W-1)%W)],xp=edH[y*W+((x+1)%W)],ym=edH[Math.max(0,y-1)*W+x],yp=edH[Math.min(H-1,y+1)*W+x],
      sh=1+Math.max(-.35,Math.min(.35,((xm-xp)+(ym-yp))*.006));l*=sh;r=l;g=l*1.01;b=l*.99;}
  d[o]=r;d[o+1]=g;d[o+2]=b;d[o+3]=255;}
function edRepaint(x0,y0,x1,y1){var W=CM_W,H=CM_H,x,y;x0=Math.max(0,x0-1);y0=Math.max(0,y0-1);x1=Math.min(W-1,x1+1);y1=Math.min(H-1,y1+1);
  for(y=y0;y<=y1;y++)for(x=x0;x<=x1;x++)edPx(x,y);
  edCtx.putImageData(edImg,0,0,x0,y0,x1-x0+1,y1-y0+1);edTex.needsUpdate=true;}
function edRad(){return .015+Math.pow(+$('edSz').value/100,1.5)*.35;}
/* один мазок кисти в точке p (единичный вектор в системе планеты) */
function edBrush(p,rad,tool){var W=CM_W,H=CM_H,cx=p.x,cy=p.y,cz=p.z,thc=Math.acos(Math.max(-1,Math.min(1,cy))),hxy=Math.sqrt(cx*cx+cz*cz),lc=Math.atan2(cz,-cx),cr=Math.cos(rad),
  y0=Math.max(0,Math.floor((thc-rad)/Math.PI*H)),y1=Math.min(H-1,Math.ceil((thc+rad)/Math.PI*H)),minx=W,maxx=-1,x,y,i;
  for(y=y0;y<=y1;y++){var sT=edLatS[y],cT=edLatC[y],q,xa,xb;
    if(hxy*sT<1e-6)q=(cy*cT>=cr)?-2:2;else q=(cr-cy*cT)/(sT*hxy);
    if(q>1)continue;
    if(q<=-1){xa=0;xb=W-1;}else{var dl=Math.acos(q);xa=Math.floor((lc-dl)/6.2831853*W);xb=Math.ceil((lc+dl)/6.2831853*W);if(xb-xa>=W){xa=0;xb=W-1;}}
    for(x=xa;x<=xb;x++){var xx=((x%W)+W)%W,dot=cy*cT+sT*(-cx*edLonC[xx]+cz*edLonS[xx]);if(dot<cr)continue;
      var t=Math.acos(Math.min(1,dot))/rad,w=t<.4?1:1-edSm((t-.4)/.6);i=y*W+xx;var c=edH[i];
      if(tool==='land'){if(c<80)c+=(80-c)*w*.9;}
      else if(tool==='mount'){var nz=.75+.5*Math.sin(xx*.37+Math.sin(y*.23)*2)*Math.sin(y*.41+Math.sin(xx*.19)*2);if(c<60)c+=(60-c)*w*.5;c+=w*16*nz;}
      else if(tool==='water'){c-=w*90;}
      else{var av=(edH[y*W+((xx+1)%W)]+edH[y*W+((xx+W-1)%W)]+edH[Math.max(0,y-1)*W+xx]+edH[Math.min(H-1,y+1)*W+xx])/4;c+=(av-c)*w*.6;}
      edH[i]=Math.max(0,Math.min(255,Math.round(c)));
      if(xx<minx)minx=xx;if(xx>maxx)maxx=xx;}}
  if(maxx<0)return;
  if(!edDirty)edDirty={x0:minx,x1:maxx,y0:y0,y1:y1};else{edDirty.x0=Math.min(edDirty.x0,minx);edDirty.x1=Math.max(edDirty.x1,maxx);edDirty.y0=Math.min(edDirty.y0,y0);edDirty.y1=Math.max(edDirty.y1,y1);}}
/* мазок вдоль дуги от прошлой точки до новой — линия без разрывов */
function edStrokeTo(p){var s=edStroke,rad=edRad();edStamped=performance.now();
  if(!s.last){edBrush(p,rad,edTool);s.last=p.clone();return;}
  var d=Math.acos(Math.max(-1,Math.min(1,s.last.dot(p)))),step=rad*.3;if(d<step*.5)return;
  var n=Math.ceil(d/step),sd=Math.sin(d),i,a,b,t,v=new THREE.Vector3();
  for(i=1;i<=n;i++){t=i/n;a=Math.sin((1-t)*d)/sd;b=Math.sin(t*d)/sd;v.set(s.last.x*a+p.x*b,s.last.y*a+p.y*b,s.last.z*a+p.z*b).normalize();edBrush(v,rad,edTool);}
  s.last.copy(p);}
function edPick(e){var r=edPad.getBoundingClientRect();edV2.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);
  edMesh.updateMatrixWorld();edRay.setFromCamera(edV2,edCam);var h=edRay.intersectObject(edMesh,false)[0];if(!h)return null;return edMesh.worldToLocal(h.point.clone()).normalize();}
function edFit(){var a=window.innerWidth/window.innerHeight;edCam.aspect=a;edCam.updateProjectionMatrix();}
function edFrame(){
  edCam.position.set(0,0,edDist);edCam.lookAt(0,0,0);edMesh.rotation.set(edPitch,edYaw,0);edMesh.updateMatrixWorld();
  if(edStroke&&edHit&&edTool==='mount'&&performance.now()-edStamped>70){edBrush(edHit,edRad(),'mount');edStamped=performance.now();}
  if(edDirty){var d=edDirty;edDirty=null;edRepaint(d.x0,d.y0,d.x1,d.y1);}
  if(edHit){var rad=edRad(),n=edMesh.localToWorld(edHit.clone()).normalize();edCur.position.copy(n).multiplyScalar(Math.cos(rad)*1.004);edCur.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1),n);edCur.scale.setScalar(Math.sin(rad));edCur.visible=true;}else edCur.visible=false;
  renderer.render(edScene,edCam);}
function edHint(){$('edHint').textContent=edLockOn?'Замок закрыт — рисуйте пальцем. Два пальца — приблизить. Откройте замок, чтобы вращать планету.':'Замок открыт — тяните, чтобы вращать планету. Два пальца — приблизить.';}
function edSetLock(on){edLockOn=on;$('edLock').classList.toggle('on',on);edStroke=null;edHit=null;edHint();}
function edFull(){edRepaint(0,0,CM_W-1,CM_H-1);}
function edOpen(){edInit();edOn=true;document.body.classList.add('ed');$('edScr').classList.add('on');
  edH.fill(0);edUndoH=null;edSaved=null;edYaw=.35;edPitch=.25;edStroke=null;edHit=null;edPtr={};edDirty=null;edTool='land';
  var ts=document.querySelectorAll('#edTools .et');for(var i=0;i<ts.length;i++)ts[i].classList.toggle('on',ts[i].getAttribute('data-t')==='land');
  $('edName').value='Моя карта '+(CM_LIST.length+1);edSetLock(true);edFit();
  edDist=Math.max(3.4,1.32/(Math.tan(edCam.fov*Math.PI/360)*Math.min(1,edCam.aspect)));edFull();}
function edClose(){edOn=false;edStroke=null;edHit=null;document.body.classList.remove('ed');$('edScr').classList.remove('on');showMenu(true);setPauseTo(true);}
function edSave(){var N=CM_W*CM_H,i,c=0;for(i=0;i<N;i+=7)if(edH[i]>=28)c++;
  if(c<300){edToast('Нарисуйте хотя бы немного суши.');return;}
  var name=($('edName').value||'').trim()||('Моя карта '+(CM_LIST.length+1));
  if(edSaved)cmReplace(edSaved,edH,name);else{var cm={name:name,h:edH.slice()};cmRegister(cm);edSaved=cm;}
  var ok=cmStore();edToast('Карта «'+name+'» сохранена'+(ok?'.':' (до перезагрузки)')+' Теперь она в списке карт поверхности планеты.');}
edPad.addEventListener('pointerdown',function(e){try{edPad.setPointerCapture(e.pointerId);}catch(_){}
  edPtr[e.pointerId]={x:e.clientX,y:e.clientY};var n=Object.keys(edPtr).length;
  if(n===1&&edLockOn){var p=edPick(e);if(p){edUndoH=edH.slice();edStroke={id:e.pointerId,last:null};edStrokeTo(p);edHit=p;}}
  else if(n>=2){edStroke=null;edHit=null;edPinch=0;}});
edPad.addEventListener('pointermove',function(e){var p=edPtr[e.pointerId];if(!p)return;var ids=Object.keys(edPtr);
  if(ids.length>=2){var a=edPtr[ids[0]],b=edPtr[ids[1]];p.x=e.clientX;p.y=e.clientY;var d=Math.hypot(a.x-b.x,a.y-b.y);if(edPinch)edDist=Math.max(1.6,Math.min(7,edDist*edPinch/d));edPinch=d;return;}
  if(edLockOn){if(edStroke&&edStroke.id===e.pointerId){var q=edPick(e);if(q){edStrokeTo(q);edHit=q;}else{edStroke.last=null;edHit=null;}}}
  else{var k=.006*edDist/3.4;edYaw+=(e.clientX-p.x)*k;edPitch=Math.max(-1.5,Math.min(1.5,edPitch+(e.clientY-p.y)*k));}
  p.x=e.clientX;p.y=e.clientY;});
function edUp(e){delete edPtr[e.pointerId];edPinch=0;if(edStroke&&edStroke.id===e.pointerId){edStroke=null;edHit=null;}}
edPad.addEventListener('pointerup',edUp);edPad.addEventListener('pointercancel',edUp);
edPad.addEventListener('wheel',function(e){e.preventDefault();edDist=Math.max(1.6,Math.min(7,edDist*(1+e.deltaY*.001)));},{passive:false});
window.addEventListener('resize',function(){if(edOn)edFit();});
$('edLock').addEventListener('click',function(){edSetLock(!edLockOn);});
$('edUndo').addEventListener('click',function(){if(!edUndoH){edToast('Нечего отменять.');return;}var t=edH;edH=edUndoH;edUndoH=t;edFull();});
$('edClear').addEventListener('click',function(){edUndoH=edH.slice();edH.fill(0);edFull();});
$('edSave').addEventListener('click',edSave);$('edClose').addEventListener('click',edClose);
(function(){var ts=document.querySelectorAll('#edTools .et');for(var i=0;i<ts.length;i++)ts[i].addEventListener('click',function(){edTool=this.getAttribute('data-t');for(var j=0;j<ts.length;j++)ts[j].classList.toggle('on',ts[j]===this);});})();
