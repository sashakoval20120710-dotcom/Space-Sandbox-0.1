/* ЗВЕЗДА (Солнце): шейдер поверхности, свойства звезды (масса ↔ температура ↔ цвет ↔ класс), окно информации.
   Красный карлик (stars/red_dwarf.js) строится на этом шейдере — этот файл подключается раньше него. */
/* ---- Солнце ---- */
var sunMat=new THREE.ShaderMaterial({uniforms:{uTime:{value:0}},
  vertexShader:'varying vec3 vP;varying vec3 vN;varying vec3 vV;\n'+
    'void main(){vP=normalize(position);vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.);vV=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}',
  fragmentShader:
    'precision highp float;varying vec3 vP;varying vec3 vN;varying vec3 vV;uniform float uTime;\n'+
    'float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\n'+
    'float noise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);\n'+
    ' return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),\n'+
    '            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}\n'+
    'float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}\n'+
    'void main(){float t=uTime*.05;vec3 p=vP*2.6;\n'+
    ' vec3 q=vec3(fbm(p+vec3(0.,t,0.)),fbm(p+vec3(5.2,1.3,-t)),fbm(p+vec3(-t,8.3,2.8)));\n'+
    ' vec3 r=vec3(fbm(p+3.2*q+vec3(1.7,9.2,t)),fbm(p+3.2*q+vec3(8.3,2.8,-t)),fbm(p+3.2*q));\n'+
    ' float f=fbm(p+3.6*r);float vein=1.-smoothstep(.0,.2,abs(fbm(p*1.6+2.4*r)-.5));\n'+
    ' float dark=clamp(smoothstep(.38,.62,f)*.55+vein*.55,0.,1.);\n'+
    ' vec3 col=mix(vec3(1.,.93,.06),vec3(1.,.74,.02),smoothstep(.15,.6,dark));\n'+
    ' col=mix(col,vec3(.66,.38,0.),smoothstep(.55,.95,dark));col+=vec3(.25,.2,0.)*smoothstep(.55,.75,1.-f);\n'+
    ' float fr=1.-max(dot(normalize(vN),normalize(vV)),0.);col=mix(col,vec3(1.,.96,.35),pow(fr,2.2)*.85);\n'+
    ' gl_FragColor=vec4(col*1.12,1.);}'});
var sunGeo=new THREE.SphereGeometry(SUN_R,64,48);
/* ---- Звёзды: масса ↔ температура, цвет, класс, светимость и зоны ---- */
var MS_T=[[.08,2800],[.1,3000],[.2,3300],[.45,3800],[.7,4500],[1,5772],[1.5,6800],[2,8500],[4,14000],[8,22000]];
var ST_COL=[[2000,[.75,.08,0]],[2800,[.92,.16,.02]],[3500,[1,.36,.05]],[4300,[1,.58,.06]],[5200,[1,.77,.07]],[5772,[1,.93,.06]],[6500,[1,.97,.45]],[7500,[1,.99,.8]],[10000,[.86,.92,1]],[20000,[.66,.78,1]],[40000,[.52,.66,1]]];
var SM_MIN=.08,SM_MAX=8;
function msT(M){var a=MS_T,i,n=a.length-1;if(M<=a[0][0])return a[0][1]*Math.pow(M/a[0][0],.3);if(M>=a[n][0])return a[n][1]*Math.pow(M/a[n][0],.5);
  for(i=1;i<=n;i++)if(M<=a[i][0]){var f=Math.log(M/a[i-1][0])/Math.log(a[i][0]/a[i-1][0]);return a[i-1][1]*Math.pow(a[i][1]/a[i-1][1],f);}return 5772;}
function msR(M){return M<=1?Math.pow(M,.7):Math.pow(M,.6);}
function starTRange(M){var tm=msT(M);return [Math.max(1800,tm*.85/Math.pow(150,1/9)),Math.min(40000,Math.max(tm*2.2,4000))];}
function starRGB(T){var a=ST_COL,i;if(T<=a[0][0])return a[0][1];for(i=1;i<a.length;i++)if(T<=a[i][0]){var f=(T-a[i-1][0])/(a[i][0]-a[i-1][0]),p=a[i-1][1],q=a[i][1];return [p[0]+(q[0]-p[0])*f,p[1]+(q[1]-p[1])*f,p[2]+(q[2]-p[2])*f];}return a[a.length-1][1];}
var STAR_FS=sunMat.fragmentShader.split('vec3(1.,.93,.06)').join('uCa').split('vec3(1.,.74,.02)').join('uCb').split('vec3(.66,.38,0.)').join('uCd').split('vec3(.25,.2,0.)').join('uCa*.25').split('vec3(1.,.96,.35)').join('uCe').replace('uniform float uTime;','uniform float uTime;uniform vec3 uCa,uCb,uCd,uCe;');
function makeStarMat(){return new THREE.ShaderMaterial({vertexShader:sunMat.vertexShader,fragmentShader:STAR_FS,uniforms:{uTime:{value:0},uCa:{value:new THREE.Vector3(1,.93,.06)},uCb:{value:new THREE.Vector3()},uCd:{value:new THREE.Vector3()},uCe:{value:new THREE.Vector3()}}});}
/* радиус и светимость: на главной последовательности R~M^0.7, ниже ~85% её температуры звезда раздувается в гиганта; зоны ~ √L */
function starPhys(b){var M=b.m/SUNM,tm=msT(M),Tg=tm*.85,R=msR(M);if(b.T<Tg)R*=Math.pow(Tg/b.T,9);
  b.Rrel=R;b.L=R*R*Math.pow(b.T/5772,4);b.zs=Math.sqrt(b.L);b.r=SUN_R*R;}
function starApply(b){starPhys(b);var c=starRGB(b.T),u=b.mesh.material.uniforms,k;
  u.uCa.value.set(c[0],c[1],c[2]);u.uCb.value.set(c[0]*.82,c[1]*.82,c[2]*.82);u.uCd.value.set(c[0]*.45,c[1]*.45,c[2]*.45);u.uCe.value.set(Math.min(1,c[0]*.55+.45),Math.min(1,c[1]*.55+.45),Math.min(1,c[2]*.55+.45));
  b.mesh.scale.setScalar(b.r/KR[b.kind]);b.glow.scale.set(b.r*2.4,b.r*2.4,1);b.glow.material.color.setRGB(c[0]*.75+.25,c[1]*.75+.25,c[2]*.75+.25);
  b.light.color.setRGB(c[0]*.5+.5,c[1]*.5+.5,c[2]*.5+.5);b.light.intensity=1.2+.7*Math.min(1,Math.pow(b.L,.25));}
function starSetMass(b,Mn){Mn=Math.max(SM_MIN,Math.min(SM_MAX,Mn));b.m=Mn*SUNM;b.T=msT(Mn);starApply(b);}
function starSetT(b,T){var r=starTRange(b.m/SUNM);b.T=Math.max(r[0],Math.min(r[1],T));starApply(b);}
function starClass(b){var T=b.T,R=b.Rrel,l=T>30000?'O':T>10000?'B':T>7500?'A':T>6000?'F':T>5200?'G':T>3700?'K':'M',
  c=T<3700?'Красный':T<5200?'Оранжевый':T<6000?'Жёлтый':T<7500?'Жёлто-белый':T<10000?'Белый':T<30000?'Голубо-белый':'Голубой',n;
  if(R>=5)n=c+(R>=60?' сверхгигант':' гигант');else if(T<7500)n=c+' карлик';else n=c.replace('ый','ая').replace('ой','ая')+' звезда';
  return {name:n,letter:l,full:n+' · класс '+l};}
function openStar(b){$('infoName').value=b.name;$('infoType').textContent=starClass(b).full;var zr='',i;
  for(i=0;i<4;i++)zr+='<div class="ir"><b>●</b><span>'+zoneEm(i)+'</span><i id="vZ'+i+'"></i></div>';
  $('infoScroll').innerHTML='<div class="ih"><span>Показатели</span></div><div class="ir"><b>⭐</b><span>Класс</span><i id="vCls"></i></div>'+ivRow('⚖','Масса, M☉','sM')+ivRow('🌡','Температура, K','sT')+
    '<div class="ir"><b>📏</b><span>Радиус, R☉</span><i id="vSR"></i></div><div class="ir"><b>💡</b><span>Светимость, L☉</span><i id="vSL"></i></div><div class="ih"><span>Зоны</span></div>'+zr+'<button class="mb" id="comBtn"></button>';
  infoEls={};var els=$('infoScroll').querySelectorAll('.iv');for(i=0;i<els.length;i++)infoEls[els[i].getAttribute('data-k')]=els[i];
  $('comBtn').addEventListener('click',function(){toggleComLock(b);refreshInfo(b);});
  refreshInfo(b);$('infoScroll').scrollTop=0;$('popInfo').classList.add('show');document.body.classList.add('info');}
function starRefresh(b){var act=document.activeElement,e1=infoEls.sM,e2=infoEls.sT,s,i,z=(b.gm&&b.gr?b.gr.Zs:b.zs),cl=starClass(b);
  if(e1&&e1!==act){s=fmtN(b.m/SUNM);if(e1._t!==s){e1._t=s;e1.value=s;}}
  if(e2&&e2!==act){s=String(Math.round(b.T));if(e2._t!==s){e2._t=s;e2.value=s;}}
  function sv(id,v){var e=$(id);if(e&&e._t!==v){e._t=v;e.textContent=v;}}
  sv('vCls',cl.name+' ('+cl.letter+')');sv('vSR',fmtN(b.Rrel));sv('vSL',fmtN(b.L));
  var d=[ZB[0]*z,ZB[1]*z,ZB[2]*z],f=function(x){return String(Math.round(x));};
  sv('vZ0','до '+f(d[0]));sv('vZ1',f(d[0])+' – '+f(d[1]));sv('vZ2',f(d[1])+' – '+f(d[2]));sv('vZ3','от '+f(d[2]));
  var it=$('infoType'),tx=cl.full+' · '+Math.round(b.T)+' K';if(it&&it._t!==tx){it._t=tx;it.textContent=tx;}
  var cb=$('comBtn');if(cb){var on=!!(b.gr&&b.gr.anchor),tx2=!b.gr?'Нет общего центра масс':on?'Освободить центр масс':'Зафиксировать общий центр масс';if(cb._t!==tx2){cb._t=tx2;cb.textContent=tx2;}cb.disabled=!b.gr;cb.classList.toggle('on',on);}}
/* значок звезды */
ICON.star=(function(){
  var S=192,H=S/2,R=H*0.86;
  function mk(){var c=document.createElement('canvas');c.width=c.height=S;return c;}
  function sm(a,b,x){x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x);}
  function h3(x,y,z){var h=Math.sin(x*127.1+y*311.7+z*74.7)*43758.5453;return h-Math.floor(h);}
  function L(a,b,t){return a+(b-a)*t;}
  function vn(x,y,z){var xi=Math.floor(x),yi=Math.floor(y),zi=Math.floor(z),fx=x-xi,fy=y-yi,fz=z-zi;
    fx=fx*fx*(3-2*fx);fy=fy*fy*(3-2*fy);fz=fz*fz*(3-2*fz);
    return L(L(L(h3(xi,yi,zi),h3(xi+1,yi,zi),fx),L(h3(xi,yi+1,zi),h3(xi+1,yi+1,zi),fx),fy),
             L(L(h3(xi,yi,zi+1),h3(xi+1,yi,zi+1),fx),L(h3(xi,yi+1,zi+1),h3(xi+1,yi+1,zi+1),fx),fy),fz);}
  function fbm(x,y,z){var v=0,a=.5;for(var i=0;i<4;i++){v+=a*vn(x,y,z);x=x*2.03+1.7;y=y*2.03+9.2;z=z*2.03+3.1;a*=.5;}return v;}
  function sun(){var c=mk(),g=c.getContext('2d');
    var gl=g.createRadialGradient(H,H,R*.75,H,H,H);gl.addColorStop(0,'rgba(255,200,40,.6)');gl.addColorStop(1,'rgba(255,170,20,0)');g.fillStyle=gl;g.fillRect(0,0,S,S);
    var t=mk(),tg=t.getContext('2d'),im=tg.createImageData(S,S),d=im.data;
    for(var y=0;y<S;y++)for(var x=0;x<S;x++){
      var nx=(x+.5-H)/R,ny=-(y+.5-H)/R,rr=nx*nx+ny*ny;if(rr>1.05)continue;
      var nz=Math.sqrt(Math.max(0,1-rr)),px=nx*2.6+4,py=ny*2.6,pz=nz*2.6;
      var q=fbm(px,py,pz),r=fbm(px+3*q,py+2*q+5,pz-3*q),f=fbm(px+3.4*r,py+1.7,pz+3.4*r);
      var vein=1-Math.min(1,Math.abs(fbm(px*1.7+2*r,py*1.7,pz*1.7)-.5)/.12);
      var dk=Math.max(0,Math.min(1,sm(.38,.62,f)*.55+vein*.5));
      var cr=1,cg=.93-.19*sm(.15,.6,dk),cb=.06-.04*sm(.15,.6,dk),k=sm(.55,.95,dk);
      cr=L(cr,.66,k);cg=L(cg,.38,k);cb=L(cb,0,k);
      var fr=1-nz,rim=Math.pow(fr,2.2)*.85;cr=L(cr,1,rim);cg=L(cg,.96,rim);cb=L(cb,.4,rim);
      var o=(y*S+x)*4,al=Math.max(0,Math.min(1,(1-Math.sqrt(rr))*R));
      d[o]=Math.min(255,cr*282);d[o+1]=Math.min(255,cg*282);d[o+2]=Math.min(255,cb*282);d[o+3]=al*255;}
    tg.putImageData(im,0,0);g.drawImage(t,0,0);return c;}
  return sun();
})();
KR.star=SUN_R;GEO.star=sunGeo;MAT.star=sunMat;
