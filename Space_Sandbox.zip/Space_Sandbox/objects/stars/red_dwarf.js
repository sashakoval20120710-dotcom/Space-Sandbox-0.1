/* КРАСНЫЙ КАРЛИК: радиус ×1/5, масса ×1/10 от Солнца; вспышки, радиация. Нужен objects/stars/sun.js (его шейдер). */
/* ---- Красный карлик: радиус ×1/5, масса ×1/10 от Солнца; часто вспыхивает, радиация мешает жизни ---- */
KR.dwarf=SUN_R/5;
var dwarfMat=new THREE.ShaderMaterial({uniforms:{uTime:{value:0}},vertexShader:sunMat.vertexShader,
  fragmentShader:sunMat.fragmentShader.split('vec3(1.,.93,.06),vec3(1.,.74,.02)').join('vec3(1.,.3,.06),vec3(.86,.14,.02)').split('vec3(.66,.38,0.)').join('vec3(.42,.06,.01)').split('vec3(.25,.2,0.)').join('vec3(.3,.07,0.)').split('vec3(1.,.96,.35)').join('vec3(1.,.4,.12)')});
GEO.dwarf=new THREE.SphereGeometry(KR.dwarf,48,36);MAT.dwarf=dwarfMat;
ICON.dwarf=(function(){var S=ICON.star.width||192,c=document.createElement('canvas');c.width=c.height=S;var g=c.getContext('2d');g.drawImage(ICON.star,0,0,S,S);g.globalCompositeOperation='source-atop';g.fillStyle='rgba(235,40,20,.72)';g.fillRect(0,0,S,S);return c;})();
var fparts=[];(function(){for(var i=0;i<90;i++){var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,opacity:0,color:0xff5a22}));sp.visible=false;scene.add(sp);fparts.push({s:sp,life:0,max:1,v:new THREE.Vector3(),sz:1});}})();
function flareFx(b,dir){var r=b.r,n=0,i,p;
  for(i=0;i<fparts.length&&n<22;i++){p=fparts[i];if(p.life>0)continue;n++;
    var sx=dir.x+(Math.random()-.5)*.35,sy=dir.y+(Math.random()-.5)*.35,sz=dir.z+(Math.random()-.5)*.35,l=Math.sqrt(sx*sx+sy*sy+sz*sz)||1,sp=14+Math.random()*26;sx/=l;sy/=l;sz/=l;
    p.s.position.set(b.x+sx*r*1.02,b.y+sy*r*1.02,b.z+sz*r*1.02);p.v.set(sx*sp,sy*sp,sz*sp);
    p.max=p.life=.9+Math.random()*1.1;p.sz=r*(.7+Math.random());p.s.material.color.setRGB(1,.25+.45*Math.random(),.1+.25*Math.random());p.s.visible=true;}}
/* вспышка бьёт конусом в случайную сторону (чаще в плоскости орбит); планета в конусе получает дозу радиации, она медленно спадает */
function flareStep(vdt){var i,j,b,q,p;
  for(i=0;i<bodies.length;i++){b=bodies[i];if(b.kind!=='dwarf')continue;
    b.fT=(b.fT===undefined?1+Math.random()*3:b.fT)-vdt;
    if(b.fT<=0){b.fT=2.2+Math.random()*4.5;
      var dx=Math.random()*2-1,dz=Math.random()*2-1,dy=(Math.random()*2-1)*.35,l=Math.sqrt(dx*dx+dy*dy+dz*dz)||1,dir={x:dx/l,y:dy/l,z:dz/l};
      flareFx(b,dir);b.glow.material.opacity=.95;
      for(j=0;j<bodies.length;j++){q=bodies[j];if(q.star)continue;var ex=q.x-b.x,ey=q.y-b.y,ez=q.z-b.z,d=Math.sqrt(ex*ex+ey*ey+ez*ez)||1;
        if(d>45)continue;var cs=(ex*dir.x+ey*dir.y+ez*dir.z)/d;if(cs<.6)continue;
        q.rad=Math.min(1,(q.rad||0)+.35*(.4+.6*(cs-.6)/.4)/(1+d*d/144));}}
    b.glow.material.opacity+=(.4-b.glow.material.opacity)*Math.min(1,vdt*3);}
  for(j=0;j<bodies.length;j++){q=bodies[j];if(q.rad>0){q.rad*=Math.exp(-vdt/60);if(q.rad<.002)q.rad=0;}}
  for(i=0;i<fparts.length;i++){p=fparts[i];if(p.life<=0)continue;p.life-=vdt;if(p.life<=0){p.s.visible=false;continue;}
    p.s.position.addScaledVector(p.v,vdt);var f=p.life/p.max;p.s.material.opacity=f*.9;p.s.scale.setScalar(p.sz*(.5+f*.9));}}
