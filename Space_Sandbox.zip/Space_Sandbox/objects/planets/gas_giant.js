/* ГАЗОВЫЙ ГИГАНТ: газы-«краски», шейдер полос и штормов, значок.
   Пресеты полос (Юпитер, Сатурн, Нептун) лежат в planet_maps/gas_giant/. */
/* ---- Газовый гигант: каждая полоса = газ, газ задаёт цвет; всё рисуется в шейдере ---- */
var GAS_R=SUN_R*69911/696340;KR.gas=GAS_R;
var GASB={NH3:['NH₃','Аммиак',[.95,.91,.82]],NH4SH:['NH₄SH','Гидросульфид аммония',[.62,.4,.27]],H2O:['H₂O','Вода',[.88,.92,.97]],CH4:['CH₄','Метан',[.24,.5,.86]],
 S:['S₈','Сера',[.92,.74,.32]],P:['P','Фосфор (хромофор)',[.76,.32,.22]],C2H6:['C₂H₆','Этан',[.62,.66,.76]],H2:['H₂','Водород',[.82,.76,.66]],H2S:['H₂S','Сероводород',[.78,.8,.45]]};
function gasPreset(id){return GPAR[id|0].b.map(function(x){return {g:x[0],w:x[1]};});}
function gcss(g){var c=GASB[g][2];return 'rgb('+Math.round(c[0]*255)+','+Math.round(c[1]*255)+','+Math.round(c[2]*255)+')';}
var GAS_FS=['precision highp float;varying vec3 vP;varying vec3 vNw;varying vec3 vN;varying vec3 vV;',
'uniform float uT,uK,uTurb,uSt,uOv;uniform vec2 uStP;uniform vec3 uL,uStC,uOvC;uniform vec3 uBC[24];uniform float uBE[24];uniform int uN;',
'float hash(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}',
'float noise(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);',
' return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),',
'            mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}',
'float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}',
'float wrp(float a){return a-6.28319*floor((a+3.14159)/6.28319);}',
'float ovl(float lon,float y,vec2 c,float ax,float ay){vec2 q=vec2(wrp(lon-c.x)*max(.4,sqrt(max(0.,1.-c.y*c.y)))/ax,(y-c.y)/ay);return 1.-smoothstep(.45,1.,length(q));}',
'void main(){float t=uT*.012,y=clamp(vP.y,-1.,1.),cl=sqrt(max(0.,1.-y*y)),lon=atan(vP.z,vP.x);',
' float ang=t*(.55*sin(y*7.)+.3*sin(y*15.+1.)+.15*sin(y*31.+2.))*3.;vec2 xz=vec2(cos(ang)*vP.x-sin(ang)*vP.z,sin(ang)*vP.x+cos(ang)*vP.z);',
' vec3 q3=vec3(xz.x,y*2.6,xz.y);',
' float w1=fbm(q3*vec3(2.,1.5,2.)+vec3(t,0.,-t*.6));',
' float w2=fbm(q3*vec3(4.8,3.4,4.8)+vec3(3.7,1.3,8.2)+vec3(-t*1.3,0.,t));',
' vec2 sq=vec2(wrp(lon-uStP.x)*max(.4,sqrt(max(0.,1.-uStP.y*uStP.y)))/.42,(y-uStP.y)/.11);float sd=length(sq);',
' float yy=y+(w1-.5)*uTurb*(.12+.35*cl)+(w2-.5)*uTurb*.04+(w2-.5)*uSt*.08*exp(-sd*sd*.3);',
' float u=(1.-yy)*.5,ed=1.;',
' for(int i=1;i<24;i++){if(i>=uN)break;ed=min(ed,abs(u-uBE[i]));}',
' float ep=exp(-ed*ed/.0008);',
' yy+=ep*(sin(wrp(lon+ang)*11.+w2*7.)*.016+(w1-.5)*.03)*(.4+uTurb);',
' u=(1.-yy)*.5;vec3 col=uBC[0];float fw=.006+.03*w2;',
' for(int i=1;i<24;i++){if(i>=uN)break;col=mix(col,uBC[i],smoothstep(uBE[i]-fw,uBE[i]+fw,u));}',
' float s1=fbm(vec3(xz.x*3.,yy*46.,xz.y*3.)+vec3(t*.5,0.,0.));',
' float s2=noise(vec3(xz.x*6.,yy*130.,xz.y*6.)+vec3(2.,t*.3,5.));',
' float s3=fbm(vec3(xz.x*1.5,yy*14.,xz.y*1.5)+vec3(8.,0.,t*.2));',
' col*=(.74+.4*s1+.28*(s2-.5))*(.86+.28*s3)*(.9+.2*w2);',
' float wf=smoothstep(.58,.78,fbm(vec3(xz.x*9.,yy*28.,xz.y*9.)+vec3(t*.4,3.,1.)));',
' float dk=smoothstep(.62,.8,fbm(vec3(xz.x*7.,yy*20.,xz.y*7.)+vec3(5.,t*.3,9.)));',
' col=mix(col,min(vec3(1.),col*1.4+.06),wf*(.2+.8*ep)*.75);col=mix(col,col*.5,dk*ep*.6);',
' float body=(1.-smoothstep(.5,1.,sd))*uSt;float swl=.5+.5*sin(atan(sq.y,sq.x)*2.+sd*9.-t*2.+w2*5.);',
' float rim=smoothstep(.9,1.15,sd)*(1.-smoothstep(1.15,1.7,sd))*uSt;',
' col=mix(col,col*.72,rim*.6);col=mix(col,uStC*(.8+.35*swl),body);',
' float o=max(ovl(lon,y,vec2(2.4,.52),.2,.06),max(ovl(lon,y,vec2(-1.1,-.6),.16,.05),ovl(lon,y,vec2(.5,.2),.12,.04)))*uOv;',
' col=mix(col,uOvC*(.9+.15*w2),o);',
' col=mix(col,col*vec3(.75,.8,.95),smoothstep(.8,.98,abs(y))*.6);',
' float dn=dot(normalize(vNw),normalize(uL));float lit=uK*smoothstep(-.2,.78,dn);',
' float mu=max(dot(normalize(vN),normalize(vV)),0.);',
' col*=(.35+.65*pow(mu,.45));col*=(.06+1.08*lit);',
' gl_FragColor=vec4(col,1.);}'].join('\n');
/* толщины полос → границы в шейдер */
function gasBands(b){var u=b.gasMat.uniforms,B=b.bands,n=Math.min(24,B.length),sum=0,e=0,i,c;for(i=0;i<n;i++)sum+=B[i].w;
  for(i=0;i<24;i++){if(i<n){c=GASB[B[i].g][2];u.uBC.value[i].set(c[0],c[1],c[2]);u.uBE.value[i]=e/sum;e+=B[i].w;}else u.uBE.value[i]=2;}u.uN.value=n;}
function setGasPal(m,P){var u=m.uniforms;u.uTurb.value=P.turb;u.uSt.value=P.stK;u.uOv.value=P.ovK;u.uStP.value.set(P.stP[0],P.stP[1]);
  u.uStC.value.set(P.st[0],P.st[1],P.st[2]);u.uOvC.value.set(P.ov[0],P.ov[1],P.ov[2]);}
function makeGasMat(id){var bc=[],be=[],i;for(i=0;i<24;i++){bc.push(new THREE.Vector3());be.push(2);}
  var m=new THREE.ShaderMaterial({vertexShader:LAVA_VS,fragmentShader:GAS_FS,uniforms:{uT:{value:0},uK:{value:1},uTurb:{value:0},uSt:{value:0},uOv:{value:0},uN:{value:1},uBC:{value:bc},uBE:{value:be},
  uStP:{value:new THREE.Vector2()},uL:{value:new THREE.Vector3(1,.5,.6).normalize()},uStC:{value:new THREE.Vector3()},uOvC:{value:new THREE.Vector3()}}});
  setGasPal(m,GPAR[id|0]);gasBands({gasMat:m,bands:gasPreset(id)});return m;}
function applyGas(b){var P=GPAR[b.mapId|0];setGasPal(b.gasMat,P);b.bands=gasPreset(b.mapId);gasBands(b);}
GEO.gas=new THREE.SphereGeometry(GAS_R,64,48);MAT.gas=makeGasMat(0);
var atmoGeoG=new THREE.SphereGeometry(GAS_R*1.09,40,28);
/* иконка: полосы пресета + шторм, считается один раз на вариант */
var _gi={};
function gasIcon(id){id=id|0;if(_gi[id])return _gi[id];var P=GPAR[id],B=gasPreset(id),S=128,H=S/2,R=H*.86,c=document.createElement('canvas');c.width=c.height=S;var g=c.getContext('2d'),
  im=g.createImageData(S,S),d=im.data,lx=-.5,ly=.5,lz=.7,ln=Math.sqrt(lx*lx+ly*ly+lz*lz),x,y,k,tot=0;lx/=ln;ly/=ln;lz/=ln;
  function sm(a,b,v){v=Math.max(0,Math.min(1,(v-a)/(b-a)));return v*v*(3-2*v);}
  for(k=0;k<B.length;k++)tot+=B[k].w;
  function gc(u){var e=0,col=GASB[B[0].g][2].slice(),i,j,f,cc;for(i=1;i<B.length;i++){e+=B[i-1].w;f=sm(e/tot-.012,e/tot+.012,u);cc=GASB[B[i].g][2];for(j=0;j<3;j++)col[j]+=(cc[j]-col[j])*f;}return col;}
  var gl=g.createRadialGradient(H,H,R*.9,H,H,H);gl.addColorStop(0,'rgba('+Math.round(P.hz[0]*255)+','+Math.round(P.hz[1]*255)+','+Math.round(P.hz[2]*255)+',.5)');gl.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gl;g.fillRect(0,0,S,S);
  for(y=0;y<S;y++)for(x=0;x<S;x++){var nx=(x+.5-H)/R,ny=-(y+.5-H)/R,rr=nx*nx+ny*ny;if(rr>1.05)continue;
    var nz=Math.sqrt(Math.max(0,1-rr)),lon=Math.atan2(nz,nx),yy=ny+.04*Math.sin(nx*5+ny*3)*(1-Math.abs(ny)),col=gc((1-yy)/2);
    var sq=Math.hypot((lon-P.stP[0])*Math.max(.4,Math.sqrt(1-P.stP[1]*P.stP[1]))/.42,(ny-P.stP[1])/.11),bd=(1-sm(.5,1,sq))*P.stK;
    for(k=0;k<3;k++)col[k]=col[k]+(P.st[k]-col[k])*bd;
    var df=Math.max(0,nx*lx+ny*ly+nz*lz),sh=(.28+.9*sm(-.2,.78,df))*(.35+.65*Math.pow(nz,.45)),o=(y*S+x)*4,al=Math.max(0,Math.min(1,(1-Math.sqrt(rr))*R));
    d[o]=Math.min(255,col[0]*sh*255);d[o+1]=Math.min(255,col[1]*sh*255);d[o+2]=Math.min(255,col[2]*sh*255);d[o+3]=al*255;}
  var t=document.createElement('canvas');t.width=t.height=S;t.getContext('2d').putImageData(im,0,0);g.drawImage(t,0,0);return (_gi[id]=c);}
ICON.gas=gasIcon(0);
