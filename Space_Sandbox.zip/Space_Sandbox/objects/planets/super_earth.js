/* СУПЕР-ЗЕМЛЯ: процедурная текстура по карте, шейдер суши/океана/растительности, атмосфера, значок.
   Сами карты (Земля, Архипелаг, Пангея…) лежат в planet_maps/super_earth/. */
/* ---- Супер-Земля: процедурная текстура, атмосфера, иконка ---- */
var SE_R=SUN_R*7344/696340;
function makeSuperMap(P,delay){
  var W=512,HT=256,N=W*HT,i,x,y,SD=P.sd;
  function ih(a,b,c){var h=Math.imul(a+SD,374761393)^Math.imul(b,668265263)^Math.imul(c,1274126177);h=Math.imul(h^(h>>>13),1103515245);return((h^(h>>>16))>>>0)/4294967296;}
  function lr(a,b,t){return a+(b-a)*t;}
  function sm(a,b,v){v=Math.max(0,Math.min(1,(v-a)/(b-a)));return v*v*(3-2*v);}
  function vn(px,py,pz){var xi=Math.floor(px),yi=Math.floor(py),zi=Math.floor(pz),fx=px-xi,fy=py-yi,fz=pz-zi;fx=fx*fx*(3-2*fx);fy=fy*fy*(3-2*fy);fz=fz*fz*(3-2*fz);
    return lr(lr(lr(ih(xi,yi,zi),ih(xi+1,yi,zi),fx),lr(ih(xi,yi+1,zi),ih(xi+1,yi+1,zi),fx),fy),lr(lr(ih(xi,yi,zi+1),ih(xi+1,yi,zi+1),fx),lr(ih(xi,yi+1,zi+1),ih(xi+1,yi+1,zi+1),fx),fy),fz);}
  function fb(px,py,pz,o){var v=0,a=.5,t=0;for(var k=0;k<o;k++){v+=a*vn(px,py,pz);t+=a;px=px*2.07+3.3;py=py*2.07+1.9;pz=pz*2.07+5.1;a*=.5;}return v/t;}
  var hh=new Float32Array(N),mm=new Float32Array(N);
  for(y=0;y<HT;y++){var lat=(.5-(y+.5)/HT)*Math.PI,cl=Math.cos(lat),sl=Math.sin(lat);
    for(x=0;x<W;x++){var lon=(x+.5)/W*6.2832,px=cl*Math.cos(lon),pz=cl*Math.sin(lon),py=sl;i=y*W+x;
      var q=P.custom?0:fb(px*1.5+11,py*1.5,pz*1.5,3);
      hh[i]=P.custom?0:fb(px*P.f+q*1.4,py*P.f+q*1.4+4,pz*P.f+q*1.4,5);
      mm[i]=fb(px*3+7,py*3+2,pz*3,3);}}
  if(P.custom){var C=P.custom,CW=1024;for(y=0;y<HT;y++)for(x=0;x<W;x++){var a0=(y*2)*CW+x*2,hv=(C.h[a0]+C.h[a0+1]+C.h[a0+CW]+C.h[a0+CW+1])/1020,dv=(C.d[a0]+C.d[a0+1]+C.d[a0+CW]+C.d[a0+CW+1])/1020;
    hh[y*W+x]=hv>.11?(hv-.11)*.32:-(.006+.13*Math.pow(dv,.8));}}
  var mn=1e9,mx=-1e9;for(i=0;i<N;i++){if(hh[i]<mn)mn=hh[i];if(hh[i]>mx)mx=hh[i];}
  var bins=new Uint32Array(256);for(i=0;i<N;i++)bins[Math.min(255,((hh[i]-mn)/(mx-mn)*256)|0)]++;
  var acc=0,sea=mn,b;for(b=0;b<256;b++){acc+=bins[b];if(acc>=N*P.q){sea=mn+(b+1)/256*(mx-mn);break;}}
  if(P.custom)sea=0;
  var cr,cg,cb,csp,cbp;
  function shade(e,m,al){var r,g,bl,sp,bp;
    if(e<0){var d=sm(0,P.dw,-e);r=lr(P.sh[0],P.dp[0],d);g=lr(P.sh[1],P.dp[1],d);bl=lr(P.sh[2],P.dp[2],d);
      var co=sm(-.014,0,e)*P.co;r=lr(r,P.cs[0],co);g=lr(g,P.cs[1],co);bl=lr(bl,P.cs[2],co);sp=215;bp=60;}
    else{var t=Math.min(1,e/.15);r=lr(P.g0[0],P.g1[0],t);g=lr(P.g0[1],P.g1[1],t);bl=lr(P.g0[2],P.g1[2],t);
      var ar=sm(.56,.7,m+P.ar)*(1-sm(.35,.9,al))*(1-t*.5);r=lr(r,P.sand[0],ar*.8);g=lr(g,P.sand[1],ar*.8);bl=lr(bl,P.sand[2],ar*.8);
      var rk=sm(P.rk,1,t)*P.rkw;r=lr(r,P.rkc[0],rk);g=lr(g,P.rkc[1],rk);bl=lr(bl,P.rkc[2],rk);sp=25;bp=Math.min(255,80+e*900);}
    var sn=sm(P.sn+(m-.5)*.22-(e>0?e*P.se:0),.9,al);
    if(sn>0){r=lr(r,238,sn);g=lr(g,244,sn);bl=lr(bl,250,sn);sp=lr(sp,70,sn);bp=lr(bp,150,sn);}
    cr=r;cg=g;cb=bl;csp=sp;cbp=bp;}
  function mc(w,h){var c=document.createElement('canvas');c.width=w;c.height=h;return c;}
  function tex(c,an){var t=new THREE.CanvasTexture(c);t.anisotropy=an;return t;}
  var an=Math.min(4,renderer.capabilities.getMaxAnisotropy());
  /* быстрый низкодетальный вариант — сразу при старте */
  var cc=mc(W,HT),sc=mc(W,HT),bc=mc(W,HT),cgx=cc.getContext('2d'),sgx=sc.getContext('2d'),bgx=bc.getContext('2d'),
      ci=cgx.createImageData(W,HT),si=sgx.createImageData(W,HT),bi=bgx.createImageData(W,HT),cd=ci.data,sd=si.data,bd=bi.data;
  for(y=0;y<HT;y++){var al=Math.abs(.5-(y+.5)/HT)*2;
    for(x=0;x<W;x++){i=y*W+x;var o=i*4;shade(hh[i]-sea,mm[i],al);
      cd[o]=cr;cd[o+1]=cg;cd[o+2]=cb;cd[o+3]=255;sd[o]=sd[o+1]=sd[o+2]=csp;sd[o+3]=255;bd[o]=bd[o+1]=bd[o+2]=cbp;bd[o+3]=255;}}
  cgx.putImageData(ci,0,0);sgx.putImageData(si,0,0);bgx.putImageData(bi,0,0);
  var res={map:tex(cc,an),spec:tex(sc,an),bump:tex(bc,an),data:cd,W:W,H:HT,hi:null};
  /* четкая текстура 2048x1024: считается кусками между кадрами, потом подменяет низкую */
  var W2=2048,H2=1024,WB=1024,HB=512,wy=0,c2=new Uint8ClampedArray(W2*H2*4),s2=new Uint8ClampedArray(WB*HB*4),b2=new Uint8ClampedArray(WB*HB*4);
  function row(yy){var v=(yy+.5)/H2,lat2=(.5-v)*Math.PI,cl2=Math.cos(lat2),sl2=Math.sin(lat2),al2=Math.abs(.5-v)*2,
      fy=v*HT-.5,y0=Math.floor(fy),ty=fy-y0,y1=Math.min(HT-1,y0+1);y0=Math.max(0,y0);
    for(var xx=0;xx<W2;xx++){var fx=(xx+.5)/W2*W-.5,x0=Math.floor(fx),tx=fx-x0,xa=((x0%W)+W)%W,xb=(xa+1)%W,
        i00=y0*W+xa,i10=y0*W+xb,i01=y1*W+xa,i11=y1*W+xb,
        h=lr(lr(hh[i00],hh[i10],tx),lr(hh[i01],hh[i11],tx),ty),m=lr(lr(mm[i00],mm[i10],tx),lr(mm[i01],mm[i11],tx),ty),
        lo=(xx+.5)/W2*6.2832,ppx=cl2*Math.cos(lo),ppz=cl2*Math.sin(lo);
      var dn=fb(ppx*11+3,sl2*11,ppz*11+8,3)-.5;h+=dn*(P.custom?.03:.075);
      shade(h-sea,m,al2);if(h>sea){var kk=1+dn*1.3;cr*=kk;cg*=kk;cb*=kk;}var o=(yy*W2+xx)*4;c2[o]=cr;c2[o+1]=cg;c2[o+2]=cb;c2[o+3]=255;
      if(!(xx&1)&&!(yy&1)){var j=((yy>>1)*WB+(xx>>1))*4;s2[j]=s2[j+1]=s2[j+2]=csp;s2[j+3]=255;b2[j]=b2[j+1]=b2[j+2]=cbp;b2[j+3]=255;}}}
  function done(){if(res.dead)return;
    function mk2(w,h,arr){var c=mc(w,h),g=c.getContext('2d'),im=g.createImageData(w,h);im.data.set(arr);g.putImageData(im,0,0);return c;}
    var nm=tex(mk2(W2,H2,c2),an),ns=tex(mk2(WB,HB,s2),an),nb=tex(mk2(WB,HB,b2),an);
    var om=res.map,os=res.spec,ob=res.bump;res.map=nm;res.spec=ns;res.bump=nb;res.hi=true;
    if(res.onHi)res.onHi(nm,ns,nb);
    if(om.dispose){om.dispose();os.dispose();ob.dispose();}}
  function pass(){if(res.dead)return;var t0=performance.now();while(wy<H2&&performance.now()-t0<5){row(wy);wy++;}
    if(wy<H2)setTimeout(pass,0);else done();}
  setTimeout(pass,delay);
  return res;
}
var superTex=makeSuperMap(SPAR[0],400);
var seMat=new THREE.MeshPhongMaterial({map:superTex.map,bumpMap:superTex.bump,bumpScale:.5,specularMap:superTex.spec,specular:0x7799bb,shininess:30});
var seMats=[];
superTex.onHi=function(m,sp,bm){seMat.map=m;seMat.specularMap=sp;seMat.bumpMap=bm;seMat.needsUpdate=true;
  for(var i=0;i<bodies.length;i++){var b=bodies[i];if(b.SU&&!(b.mapId|0))applySuper(b);}};
function getSuperMap(id){if(id===0)return superTex;
  if(!SM[id]){var r=makeSuperMap(SPAR[id],150);r.onHi=function(){for(var i=0;i<bodies.length;i++){var b=bodies[i];if(b.SU&&(b.mapId|0)===id)applySuper(b);}};SM[id]=r;}
  return SM[id];}
function applySuper(b){var id=b.mapId|0,res=getSuperMap(id),m=b.mesh.material;
  m.map=res.map;m.specularMap=res.spec;m.bumpMap=res.bump;m.bumpScale=SPAR[id].bump;m.needsUpdate=true;}
var SE_MAP=[
'#include <map_fragment>',
'vec3 c0=diffuseColor.rgb;',
'float lm=dot(c0,vec3(.3,.59,.11));',
'float ocn=smoothstep(.25,.45,c0.b-c0.r);',
'float snw=smoothstep(.8,.9,min(c0.r,min(c0.g,c0.b)));',
'float gv=smoothstep(.12,.32,c0.g-c0.r)*smoothstep(.08,.2,c0.g-c0.b);',
'float lnd=(1.-ocn)*(1.-snw);',
'vec3 dead=mix(vec3(.5,.42,.2),vec3(.8,.66,.4),uDry)*(.55+lm*1.1);',
'float la=(vUv.y-.5)*3.14159;float cl=cos(la);float tl=uTe+uEq*(2.*cl*cl-1.);',
'float vg=smoothstep(245.,268.,tl)*(1.-smoothstep(330.,370.,tl));',
'float hot=smoothstep(325.,365.,tl);',
'float vv=uVeg*vg;',
'float warm=smoothstep(270.,300.,tl),dryz=smoothstep(305.,335.,tl),lush=smoothstep(.15,.5,lm);',
'vec3 cool=mix(vec3(.38,.5,.4),vec3(.12,.32,.22),smoothstep(250.,272.,tl));',
'vec3 tem=mix(vec3(.3,.55,.16),vec3(.07,.3,.09),lush);',
'vec3 sav=mix(vec3(.62,.58,.25),vec3(.45,.5,.2),lush);',
'vec3 vgc=mix(mix(cool,tem,warm),sav,dryz)*(.7+lm*.7);',
'vec3 c1=mix(c0,dead,gv*(1.-vv)*lnd);',
'c1=mix(c1,vgc,mix(.7,.5,gv)*vv*lnd);',
'vec3 sand=vec3(.86,.72,.46)*(.6+lm*.8);',
'c1=mix(c1,sand,max(uDry*.85,hot*.92)*lnd);',
'vec3 tg=uOcean*(lm*2.);',
'vec3 wetc=mix(c0,tg,uOS);',
'vec3 seab=vec3(.64,.52,.36)*(.55+lm*.9);',
'c1=mix(c1,mix(wetc,seab,1.-uOc),ocn);',
'diffuseColor.rgb=c1;'].join('\n');
function makeSeMat(U){var m=seMat.clone();
  m.onBeforeCompile=function(sh){for(var k in U)sh.uniforms[k]=U[k];
    sh.fragmentShader=sh.fragmentShader.replace('#include <common>','#include <common>\nuniform float uOS,uOc,uDry,uVeg,uTe,uEq;uniform vec3 uOcean;')
      .replace('#include <map_fragment>',SE_MAP)
      .replace('#include <specularmap_fragment>','#include <specularmap_fragment>\nspecularStrength*=1.-ocn*(1.-uOc);');};
  m.customProgramCacheKey=function(){return 'seBody3';};seMats.push(m);return m;}
var seGeo=new THREE.SphereGeometry(SE_R,48,32);
var atmoGeo=new THREE.SphereGeometry(SE_R*1.09,40,28);
ICON.super=(function(){var S=192,H=S/2,R=H*.84,c=document.createElement('canvas');c.width=c.height=S;var g=c.getContext('2d');
  var gl=g.createRadialGradient(H,H,R*.9,H,H,H);gl.addColorStop(0,'rgba(70,160,255,.6)');gl.addColorStop(1,'rgba(70,160,255,0)');g.fillStyle=gl;g.fillRect(0,0,S,S);
  var t=document.createElement('canvas');t.width=t.height=S;var tg=t.getContext('2d'),im=tg.createImageData(S,S),d=im.data,td=superTex.data,W=superTex.W,HT=superTex.H;
  function px(a,b,ch){a=((a%W)+W)%W;b=Math.max(0,Math.min(HT-1,b));return td[(b*W+a)*4+ch];}
  function smp(u,v,ch){var X=u*W-.5,Y=v*HT-.5,x0=Math.floor(X),y0=Math.floor(Y),fx=X-x0,fy=Y-y0;
    var a=px(x0,y0,ch)*(1-fx)+px(x0+1,y0,ch)*fx,b=px(x0,y0+1,ch)*(1-fx)+px(x0+1,y0+1,ch)*fx;return a*(1-fy)+b*fy;}
  var lx=-.5,ly=.5,lz=.7,ln=Math.sqrt(lx*lx+ly*ly+lz*lz);lx/=ln;ly/=ln;lz/=ln;
  for(var y=0;y<S;y++)for(var x=0;x<S;x++){
    var nx=(x+.5-H)/R,ny=-(y+.5-H)/R,rr=nx*nx+ny*ny;if(rr>1.05)continue;
    var nz=Math.sqrt(Math.max(0,1-rr)),u=(Math.atan2(nx,nz)+1.1)/6.2832+.5,v=.5-Math.asin(Math.max(-1,Math.min(1,ny)))/Math.PI;
    var df=Math.max(0,nx*lx+ny*ly+nz*lz),sh=.3+.8*df,rim=Math.pow(1-nz,2.4),o=(y*S+x)*4,al=Math.max(0,Math.min(1,(1-Math.sqrt(rr))*R));
    d[o]=Math.min(255,smp(u,v,0)*sh+rim*70);d[o+1]=Math.min(255,smp(u,v,1)*sh+rim*150);d[o+2]=Math.min(255,smp(u,v,2)*sh+rim*255);d[o+3]=al*255;}
  tg.putImageData(im,0,0);g.drawImage(t,0,0);return c;})();
KR.super=SE_R;GEO.super=seGeo;MAT.super=seMat;
