/* КАМЕННАЯ ПЛАНЕТА: текстура-заглушка, генератор детальной поверхности по карте (buildHigh), значок.
   Сами карты (Меркурий, Луна, Марс…) лежат в planet_maps/rocky/. */
/* ---- Меркурий: текстура ---- */
var merCanvas=(function(){var w=512,h=256,c=document.createElement('canvas');c.width=w;c.height=h;var g=c.getContext('2d');
  g.fillStyle='#8d8780';g.fillRect(0,0,w,h);var seed=3;function rnd(){seed=(seed*16807)%2147483647;return seed/2147483647;}
  for(var i=0;i<320;i++){var x=rnd()*w,y=rnd()*h,r=15+rnd()*50,l=rnd()<.5?60:200;
    var gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,'rgba('+l+','+l+','+(l-6)+',0.14)');gr.addColorStop(1,'rgba('+l+','+l+','+l+',0)');
    g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2);}
  for(var k=0;k<260;k++){var cx=rnd()*w,cy=rnd()*h,cr=2+Math.pow(rnd(),3)*26;
    var cg=g.createRadialGradient(cx,cy,cr*.2,cx,cy,cr);cg.addColorStop(0,'rgba(50,46,44,.5)');cg.addColorStop(.8,'rgba(70,66,62,.25)');cg.addColorStop(1,'rgba(70,66,62,0)');
    g.fillStyle=cg;g.beginPath();g.arc(cx,cy,cr,0,6.283);g.fill();
    g.strokeStyle='rgba(225,220,208,.4)';g.lineWidth=Math.max(.8,cr*.12);g.beginPath();g.arc(cx-cr*.08,cy-cr*.08,cr*.95,0,6.283);g.stroke();}
  return c;})();
var merTex=new THREE.CanvasTexture(merCanvas);
var merMat=new THREE.MeshLambertMaterial({map:(function(){var c=document.createElement('canvas');c.width=128;c.height=64;var g=c.getContext('2d');g.fillStyle='#b4b4b4';g.fillRect(0,0,128,64);var s=11;function r(){s=(s*16807)%2147483647;return s/2147483647;}
  for(var i=0;i<70;i++){var v=105+(r()*40|0);g.fillStyle='rgb('+v+','+v+','+v+')';g.beginPath();g.arc(r()*128,r()*64,.8+r()*2.2,0,6.283);g.fill();}
  var t=new THREE.CanvasTexture(c);t.magFilter=THREE.NearestFilter;return t;})()});
var merHigh=null;
function buildHigh(P){P=P||RMAP[0];var W=1024,H=512,N=W*H,s=P.s,i,x,y;
  function sm01(a,b,v){v=Math.max(0,Math.min(1,(v-a)/(b-a)));return v*v*(3-2*v);}
  function r(){s=(s*16807)%2147483647;return s/2147483647;}
  var GR=256,grid=new Float32Array(GR*GR);for(i=0;i<GR*GR;i++)grid[i]=r();
  function vn(px,py,P){var xi=Math.floor(px),yi=Math.floor(py),fx=px-xi,fy=py-yi;fx=fx*fx*(3-2*fx);fy=fy*fy*(3-2*fy);
    function Q(a,b){return grid[(((b%GR)+GR)%GR)*GR+(((a%P)+P)%P)];}
    return (Q(xi,yi)*(1-fx)+Q(xi+1,yi)*fx)*(1-fy)+(Q(xi,yi+1)*(1-fx)+Q(xi+1,yi+1)*fx)*fy;}
  var h=new Float32Array(N),nm=new Float32Array(N),cu=P.custom?P.custom.h:null;
  for(y=0;y<H;y++)for(x=0;x<W;x++){var u=x/W,v=y/H,
    wu=u+.04*(vn(u*5,v*2.5,5)-.5),wv=v+.04*(vn(u*5+9,v*2.5+9,5)-.5),
    n=.34*vn(wu*10,wv*5,10)+.28*vn(wu*20,wv*10,20)+.2*vn(wu*40,wv*20,40)+.12*vn(wu*80,wv*40,80)+.06*vn(wu*160,wv*80,160);
    h[y*W+x]=cu?(cu[y*W+x]<28?-12+(n-.5)*8:cu[y*W+x]*.43+(n-.5)*(16+cu[y*W+x]*.13)):(n-.5)*P.amp;nm[y*W+x]=vn(u*7+3,v*3.5+3,7);}
  function crater(cx,cy,rad){var lat=(cy/H-.5)*Math.PI,st=Math.min(4,1/Math.max(.25,Math.cos(lat))),ext=rad*1.4,xr=Math.ceil(ext*st),D=rad*.14;
    for(var yy=Math.max(0,Math.floor(cy-ext));yy<=Math.min(H-1,Math.ceil(cy+ext));yy++){var dy=yy-cy;
      for(var xx=Math.floor(cx-xr);xx<=cx+xr;xx++){var dx=(xx-cx)/st,t=Math.sqrt(dx*dx+dy*dy)/rad;if(t>1.4)continue;
        var z=0;if(t<1){var q=1-t*t;z=-D*q*q;}z+=rad*.025*Math.exp(-((t-1)*(t-1))/.05);
        h[yy*W+(((xx%W)+W)%W)]+=z;}}}
  for(i=0;i<P.nc;i++)crater(r()*W,H*(.05+r()*.9),3+Math.pow(r(),3)*P.cm);
  var ac=document.createElement('canvas');ac.width=W;ac.height=H;var ag=ac.getContext('2d'),ai=ag.createImageData(W,H);
  var nc=document.createElement('canvas');nc.width=W;nc.height=H;var ng=nc.getContext('2d'),ni=ng.createImageData(W,H);
  var S=1.4,ad=ai.data,nd=ni.data;
  for(y=0;y<H;y++){var ym=Math.max(0,y-1),yp=Math.min(H-1,y+1);
    for(x=0;x<W;x++){var xm=(x-1+W)%W,xp=(x+1)%W,idx=y*W+x,o=idx*4,
      gx=(h[y*W+xp]-h[y*W+xm])*.5,gy=(h[yp*W+x]-h[ym*W+x])*.5,nx=-gx*S,ny=gy*S,inv=1/Math.sqrt(nx*nx+ny*ny+1);
      nd[o]=(nx*inv*.5+.5)*255;nd[o+1]=(ny*inv*.5+.5)*255;nd[o+2]=(inv*.5+.5)*255;nd[o+3]=255;
      var l=(P.base+h[idx]*P.hc+(nm[idx]-.5)*70+(r()-.5)*8)*(cu&&cu[idx]<28?.6:1),cr=l*P.t[0],cg=l*P.t[1],cb=l*P.t[2];
      if(P.fx){var u2=x/W,v2=y/H,f1,f2,lk=l/168;
        if(P.fx==='maria'){f1=sm01(.52,.62,vn(u2*3+20,v2*1.5+20,3));cr-=f1*50;cg-=f1*50;cb-=f1*46;}
        else if(P.fx==='caps'){f1=sm01(.8,.9,Math.abs(v2-.5)*2);f2=sm01(.5,.65,vn(u2*6+9,v2*3+9,6));
          cr*=1-.28*f2;cg*=1-.28*f2;cb*=1-.22*f2;cr+=(238-cr)*f1;cg+=(240-cg)*f1;cb+=(245-cb)*f1;}
        else if(P.fx==='spots'){f1=sm01(.7,.76,vn(u2*14+5,v2*7+5,14));f2=sm01(.62,.7,vn(u2*6+1,v2*3+1,6));
          cr+=(215*lk-cr)*f2*.7;cg+=(95*lk-cg)*f2*.7;cb+=(40*lk-cb)*f2*.7;cr+=(60-cr)*f1;cg+=(32-cg)*f1;cb+=(24-cb)*f1;}
        else if(P.fx==='cracks'){f1=1-sm01(0,.022,Math.abs(vn(u2*9+3,v2*4.5+3,9)-.5));f2=1-sm01(0,.016,Math.abs(vn(u2*17+7,v2*8.5+7,17)-.5));
          var pt=sm01(.5,.7,vn(u2*5+11,v2*2.5+11,5));cr+=(170-cr)*pt*.5;cg+=(200-cg)*pt*.5;cb+=(232-cb)*pt*.5;
          var ck=Math.max(f1,f2*.8);cr+=(150-cr)*ck*.75;cg+=(100-cg)*ck*.75;cb+=(78-cb)*ck*.75;}
        else if(P.fx==='dunes'){f1=sm01(.42,.6,vn(u2*8+2,v2*16+2,8));var dk=.82+.3*f1;cr*=dk;cg*=dk;cb*=dk;}}
      ad[o]=cr;ad[o+1]=cg;ad[o+2]=cb;ad[o+3]=255;}}
  ag.putImageData(ai,0,0);ng.putImageData(ni,0,0);
  var tm=new THREE.CanvasTexture(ac),tn=new THREE.CanvasTexture(nc),an2=Math.min(4,renderer.capabilities.getMaxAnisotropy());tm.anisotropy=an2;tn.anisotropy=an2;
  return new THREE.MeshPhongMaterial({map:tm,normalMap:tn,normalScale:new THREE.Vector2(1.3,1.3),shininess:1,specular:0x050505});}
var P_R=SUN_R*2439.7/696340,planetGeo=new THREE.SphereGeometry(P_R,32,24);
/* значок каменной планеты */
ICON.planet=(function(){
  var S=192,H=S/2,R=H*0.86;
  function mk(){var c=document.createElement('canvas');c.width=c.height=S;return c;}
  function sm(a,b,x){x=Math.max(0,Math.min(1,(x-a)/(b-a)));return x*x*(3-2*x);}
  function h3(x,y,z){var h=Math.sin(x*127.1+y*311.7+z*74.7)*43758.5453;return h-Math.floor(h);}
  function L(a,b,t){return a+(b-a)*t;}
  function planet(){var c=mk(),g=c.getContext('2d'),mw=merCanvas.width,mh=merCanvas.height,td=merCanvas.getContext('2d').getImageData(0,0,mw,mh).data;
    function px(xx,yy,ch){xx=((xx%mw)+mw)%mw;yy=Math.max(0,Math.min(mh-1,yy));return td[(yy*mw+xx)*4+ch];}
    function smp(u,v,ch){var X=u*mw-.5,Y=v*mh-.5,x0=Math.floor(X),y0=Math.floor(Y),fx=X-x0,fy=Y-y0;
      return L(L(px(x0,y0,ch),px(x0+1,y0,ch),fx),L(px(x0,y0+1,ch),px(x0+1,y0+1,ch),fx),fy);}
    function lum(u,v){return smp(u,v,0)*.3+smp(u,v,1)*.59+smp(u,v,2)*.11;}
    var lx=-.55,ly=.55,lz=.63,ln=Math.sqrt(lx*lx+ly*ly+lz*lz);lx/=ln;ly/=ln;lz/=ln;
    var im=g.createImageData(S,S),d=im.data,du=1.6/mw,dv=1.6/mh;
    for(var y=0;y<S;y++)for(var x=0;x<S;x++){
      var nx=(x+.5-H)/R,ny=-(y+.5-H)/R,rr=nx*nx+ny*ny;if(rr>1.05)continue;
      var nz=Math.sqrt(Math.max(0,1-rr)),u=(Math.atan2(nx,nz)+.9)/6.2832+.5,v=.5-Math.asin(Math.max(-1,Math.min(1,ny)))/Math.PI;
      var hx=lum(u+du,v)-lum(u-du,v),hy=lum(u,v+dv)-lum(u,v-dv);
      var bx=nx-hx*.009,by=ny+hy*.009,bz=nz,bl=Math.sqrt(bx*bx+by*by+bz*bz);bx/=bl;by/=bl;bz/=bl;
      var df=Math.max(0,bx*lx+by*ly+bz*lz),sh=.07+1.05*sm(0,.55,df)*.55+.5*df;
      var o=(y*S+x)*4,al=Math.max(0,Math.min(1,(1-Math.sqrt(rr))*R)),k=sh*(.7+.3*nz);
      for(var ch=0;ch<3;ch++){var tv=(smp(u,v,ch)-128)*1.4+128;d[o+ch]=Math.max(0,Math.min(255,tv*k*1.05));}
      d[o+3]=al*255;}
    g.putImageData(im,0,0);return c;}
  return planet();
})();
function getHigh(id){return HIGHS[id]||(HIGHS[id]=buildHigh(RMAP[id]));}
function getLow(id){if(id===0)return merMat;if(!RLOW[id]){var m=merMat.clone(),c=RMAP[id].low;m.color.setRGB(c[0],c[1],c[2]);RLOW[id]=m;}return RLOW[id];}
var atmoGeoP=new THREE.SphereGeometry(P_R*1.09,32,22);
KR.planet=P_R;GEO.planet=planetGeo;MAT.planet=merMat;
