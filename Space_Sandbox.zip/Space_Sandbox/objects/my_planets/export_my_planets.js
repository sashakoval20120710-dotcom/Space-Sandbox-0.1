/* Скачать сохранённые тела файлами для папки my_planets: в консоли браузера выполни  exportMyPlanets() */
function exportMyPlanets(){var n=0;
  SAVED.forEach(function(s,i){if(s.file)return;n++;
    var o=JSON.parse(JSON.stringify(s));delete o.id;delete o.file;
    var slug=(s.name||'planet').toLowerCase().replace(/[^a-z0-9а-яё]+/gi,'_').replace(/^_|_$/g,'')||('planet_'+i);
    var txt='/* Моя планета: '+s.name+' */\nMY_PLANETS.push('+JSON.stringify(o)+');\n';
    var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'text/javascript'}));a.download=slug+'.js';
    setTimeout(function(){a.click();},n*400);});
  return n+' файл(ов) к скачиванию';}
