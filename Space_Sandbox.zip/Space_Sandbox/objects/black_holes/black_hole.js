/* ЧЁРНАЯ ДЫРА: тело, аккреционный диск (шейдер), значок, масса/радиус, окно информации. */
/* ---- Чёрная дыра (по умолчанию 120 000 M☉, масса меняется в настройках; радиус растёт с массой (∝ √M)): только гравитация — без света, зон, нагрева и поглощения ---- */
KR.bh=2.2;GEO.bh=new THREE.SphereGeometry(KR.bh,40,30);MAT.bh=new THREE.ShaderMaterial({transparent:true,depthWrite:false,
  vertexShader:'varying vec3 vN;varying vec3 vV;void main(){vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.);vV=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}',
  fragmentShader:'varying vec3 vN;varying vec3 vV;void main(){float f=pow(1.-max(dot(normalize(vN),normalize(vV)),0.),3.);gl_FragColor=vec4(vec3(.95,.5,.18)*f*.5,.6);}'});
var bhDiskGeo=new THREE.RingGeometry(KR.bh*1.5,KR.bh*6.2,128,3);
/* Диск: профиль температуры T∝r^-0.85, кеплеровское вращение (внутри быстрее), эффект Доплера (приближающийся край ярче и голубее),
   гравитационное красное смещение у внутреннего края, тонкие кольцевые полосы. uSide: 0 — задняя половина (линзируется), 1 — передняя (рисуется поверх без искажения) */
function makeBhMat(side,ut){return new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,uniforms:{uT:ut,uSide:{value:side}},
  vertexShader:'varying vec2 vP;varying vec3 vW;varying vec3 vC;void main(){vP=position.xy;vec4 w=modelMatrix*vec4(position,1.);vW=w.xyz;vC=(modelMatrix*vec4(0.,0.,0.,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*w;}',
  fragmentShader:
    'precision highp float;varying vec2 vP;varying vec3 vW;varying vec3 vC;uniform float uT,uSide;\n'+
    'float hs(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}\n'+
    'float nz(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);\n'+
    ' return mix(mix(mix(hs(i),hs(i+vec3(1,0,0)),f.x),mix(hs(i+vec3(0,1,0)),hs(i+vec3(1,1,0)),f.x),f.y),\n'+
    '            mix(mix(hs(i+vec3(0,0,1)),hs(i+vec3(1,0,1)),f.x),mix(hs(i+vec3(0,1,1)),hs(i+vec3(1,1,1)),f.x),f.y),f.z);}\n'+
    'float fb(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*nz(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return v;}\n'+
    'void main(){float rr=length(vP)/2.2,a=atan(vP.y,vP.x),rin=1.5,rout=6.2;\n'+
    ' vec3 vd=normalize(cameraPosition-vC);float fr=dot(vW-vC,vd);\n'+
    ' if(uSide>.5){if(fr<0.)discard;}else{if(fr>=0.)discard;}\n'+
    ' float t=clamp((rr-rin)/(rout-rin),0.,1.);\n'+
    ' float ph=a-uT*.9*pow(rin/rr,1.5);\n'+
    ' vec3 q=vec3(cos(ph),sin(ph),0.);\n'+
    ' float n1=fb(q*vec3(2.2,2.2,0.)+vec3(0.,0.,rr*26.));float n2=fb(q*vec3(5.,5.,0.)+vec3(3.,1.,rr*70.+5.));\n'+
    ' float dens=clamp(.35+1.1*n1+.55*(n2-.5),.12,1.7);dens*=.78+.22*sin(rr*38.+n1*7.);\n'+
    ' float T=pow(rin/rr,.85);\n'+
    ' vec3 rv=vW-vC;rv.y=0.;vec3 tg=normalize(cross(vec3(0.,1.,0.),rv)+1e-5);\n'+
    ' float beta=.5*pow(rin/rr,.5);float D=1./(1.-beta*dot(tg,vd));\n'+
    ' float g=sqrt(max(1.-1./rr,.04));\n'+
    ' float Tc=clamp(T*pow(D,.7)*(.55+.45*g),0.,1.25);\n'+
    ' vec3 c=mix(vec3(.45,.05,.01),vec3(1.,.4,.07),smoothstep(0.,.35,Tc));c=mix(c,vec3(1.,.78,.42),smoothstep(.3,.62,Tc));\n'+
    ' c=mix(c,vec3(1.,.96,.9),smoothstep(.58,.92,Tc));c=mix(c,vec3(.78,.88,1.),smoothstep(.95,1.25,Tc));\n'+
    ' float I=pow(T,2.2)*dens*pow(D,1.6)*g*g*3.2;\n'+
    ' I+=.7*exp(-pow((rr-rin)/.1,2.))*pow(D,1.5);\n'+
    ' float edge=smoothstep(0.,.05,t)*exp(-2.6*pow(t,1.4));\n'+
    ' gl_FragColor=vec4(c*I*edge,1.);}'});}
function initBH(b,m){b.bh=true;b.zs=1;CNT.bh=(CNT.bh||0)+1;b.defName='Чёрная дыра '+CNT.bh;b.name=b.defName;
  b.glow=makeGlow();b.glow.scale.set(KR.bh*7,KR.bh*7,1);b.glow.material.color.setRGB(1,.55,.2);b.glow.material.opacity=.3;
  var ut={value:0};b.bhMat=makeBhMat(1,ut);b.bhMat2=makeBhMat(0,ut);
  var df=new THREE.Mesh(bhDiskGeo,b.bhMat),db=new THREE.Mesh(bhDiskGeo,b.bhMat2);
  df.rotation.x=db.rotation.x=-Math.PI/2;df.frustumCulled=db.frustumCulled=false;db.renderOrder=1;df.renderOrder=3;
  /* слои: 0 — основная сцена (линзируется), 1 — передняя половина диска (поверх), 2 — само тело (тень рисует линза) */
  df.layers.set(lensFail?0:1);m.layers.set(lensFail?0:2);m.add(db);m.add(df);b.bhFront=df;bhApply(b);}
ICON.bh=(function(){var S=192,H=96,c=document.createElement('canvas');c.width=c.height=S;var g=c.getContext('2d');
  var gl=g.createRadialGradient(H,H,28,H,H,H*.95);gl.addColorStop(0,'rgba(255,150,40,.55)');gl.addColorStop(1,'rgba(255,120,20,0)');g.fillStyle=gl;g.fillRect(0,0,S,S);
  function ring(front){var a0=front?0:Math.PI,a1=front?Math.PI:Math.PI*2;g.save();g.translate(H,H);g.scale(1,.3);g.beginPath();g.arc(0,0,80,a0,a1,false);g.arc(0,0,42,a1,a0,true);g.closePath();
    var rg=g.createRadialGradient(0,0,42,0,0,80);rg.addColorStop(0,'rgba(255,245,210,1)');rg.addColorStop(.35,'rgba(255,170,60,.95)');rg.addColorStop(1,'rgba(150,30,10,.15)');g.fillStyle=rg;g.fill();g.restore();}
  ring(false);g.fillStyle='#000';g.beginPath();g.arc(H,H,36,0,6.2832);g.fill();
  g.strokeStyle='rgba(255,210,140,.9)';g.lineWidth=3;g.beginPath();g.arc(H,H,37,0,6.2832);g.stroke();ring(true);return c;})();
/* масса чёрной дыры: от 3 до 1 000 000 M☉; радиус растёт с массой (∝ √M) */
function bhMs(b){var M=b.m/SUNM;return M>=100?String(Math.round(M)).replace(/\B(?=(\d{3})+(?!\d))/g,'\u00a0'):fmtN(M);}
function bhIn(b){var M=b.m/SUNM;return M>=100?String(Math.round(M)):fmtN(M);}
function bhKm(b){return String(Math.round(2.95325*b.m/SUNM)).replace(/\B(?=(\d{3})+(?!\d))/g,'\u00a0')+' км';}
function bhRad(M){return Math.max(.011,KR.bh*Math.sqrt(M/120000));}/* радиус ∝ √M: 120 000 M☉ → 2,2; 3 M☉ → 0,011; 1 000 000 M☉ → 6,4 */
function bhApply(b){var r=bhRad(b.m/SUNM);b.r=r;b.mesh.scale.setScalar(r/KR.bh);if(b.glow)b.glow.scale.set(r*7,r*7,1);}
function bhSetMass(b,Mn){Mn=Math.max(3,Math.min(1e6,Mn));b.m=Mn*SUNM;bhApply(b);}
function bhRefresh(b){var e=infoEls.bM,act=document.activeElement,s,v=$('vBR'),it=$('infoType'),t='Чёрная дыра · '+bhMs(b)+' M☉';
  if(e&&e!==act){s=bhIn(b);if(e._t!==s){e._t=s;e.value=s;}}
  if(v){s=bhKm(b);if(v._t!==s){v._t=s;v.textContent=s;}}
  var vs=$('vBS');if(vs){s=fmtN(b.r);if(vs._t!==s){vs._t=s;vs.textContent=s;}}
  if(it._bt!==t){it._bt=t;it.textContent=t;}}
function openBH(b){$('infoName').value=b.name;
  $('infoScroll').innerHTML='<div class="ih"><span>Показатели</span></div>'+ivRow('⚖','Масса, M☉','bM')+'<div class="ir"><b>⚫</b><span>Горизонт событий</span><i id="vBR"></i></div><div class="ir"><b>📏</b><span>Радиус на экране (условный)</span><i id="vBS">'+fmtN(b.r)+'</i></div><div class="ir"><b>🌀</b><span>Влияние на объекты</span><i>только гравитация</i></div>';
  infoEls={};var els=$('infoScroll').querySelectorAll('.iv'),k;for(k=0;k<els.length;k++)infoEls[els[k].getAttribute('data-k')]=els[k];
  $('infoType')._bt=null;bhRefresh(b);$('infoScroll').scrollTop=0;$('popInfo').classList.add('show');document.body.classList.add('info');}
