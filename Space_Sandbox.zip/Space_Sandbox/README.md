# Space Sandbox — структура проекта

Открывать: **двойной клик по `index.html`** (сервер не нужен). Как и раньше, three.js подгружается из интернета (CDN).

```
index.html            разметка + порядок подключения всех файлов
style.css             стили
main.js               ОСНОВНОЙ файл: физика, частицы, столкновения, линза, настройки,
                      интерфейс, камера, общие слои планет (атмосфера, лава, снег, океан,
                      растительность, облака, кольца), игровой цикл, startGame()
objects/
  planets/            rocky_planet.js · super_earth.js · gas_giant.js
  stars/              sun.js · red_dwarf.js
  black_holes/        black_hole.js
  my_planets/         твои сохранённые тела (см. README.txt внутри)
planet_maps/
  _registry.js        списки карт RMAP / SPAR / GPAR
  rocky/              01_mercury … 07_desert      (по файлу на карту)
  super_earth/        00_base + 01_earth … 07_mountains
  gas_giant/          01_jupiter · 02_saturn · 03_neptune
  custom/             карты из редактора: custom_maps.js, map_editor.js, export_maps.js
```

## Правила
* **Порядок `<script>` в index.html важен.** Номер карты (`mapId`) = её место в списке, поэтому новые карты добавляй в *конец* своей группы, иначе у сохранённых планет «съедут» карты.
* `stars/sun.js` должен идти раньше `stars/red_dwarf.js` (карлик использует шейдер звезды).
* **Новая карта** — один файл с одной строкой `RMAP.push({...})` / `SPAR.push(mkP({...}))` / `GPAR.push({...})` + тег `<script>` в index.html.
* **Свои планеты и карты из редактора** игра хранит в браузере (localStorage), записать файл в папку она не может. Чтобы они жили в папке проекта: в консоли браузера выполни `exportMyPlanets()` или `exportCustomMaps()`, положи скачанные файлы в `objects/my_planets/` или `planet_maps/custom/` и подключи их в index.html (там есть подсказки-комментарии).
